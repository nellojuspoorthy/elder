/**
 * Seed the ElderCare database with a rich, believable demo dataset.
 * Run with: npx tsx src/db/seed.ts
 */
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import {
  activities,
  appointments,
  caregivers,
  careTasks,
  doctors,
  elders,
  emergencyAlerts,
  healthRecords,
  medicationLogs,
  medications,
  profiles,
  serviceRequests,
} from "./schema";

const pool = new Pool({
  connectionString:
    process.env.DATABASE_URL ??
    "postgresql://postgres:postgres@127.0.0.1:5432/app_db",
});
const db = drizzle(pool);

/** dayOffset from today at h:mm local */
const at = (dayOffset: number, h: number, m = 0) => {
  const d = new Date();
  d.setDate(d.getDate() + dayOffset);
  d.setHours(h, m, 0, 0);
  return d;
};

async function main() {
  console.log("Clearing existing data…");
  await db.delete(medicationLogs);
  await db.delete(healthRecords);
  await db.delete(medications);
  await db.delete(careTasks);
  await db.delete(serviceRequests);
  await db.delete(emergencyAlerts);
  await db.delete(appointments);
  await db.delete(activities);
  await db.delete(profiles);
  await db.delete(doctors);
  await db.delete(caregivers);
  await db.delete(elders);

  console.log("Seeding elders…");
  const elderRows = await db
    .insert(elders)
    .values([
      {
        name: "Margaret Ellis",
        age: 82,
        gender: "female",
        address: "14 Willow Lane, Maplewood",
        conditions: "Hypertension, Early-stage Alzheimer's, Arthritis",
        allergies: "Penicillin",
        bloodType: "O+",
        mobility: "walking aid",
        emergencyContactName: "Renata Ellis",
        emergencyContactPhone: "+1 (555) 014-2288",
        notes:
          "Loves gardening and Earl Grey tea. Mornings are her best time. Keep instructions short and warm; she responds well to routine.",
        accent: "pine",
      },
      {
        name: "Arthur Bennett",
        age: 78,
        gender: "male",
        address: "302 Harbor View Rd, Maplewood",
        conditions: "Type 2 diabetes, Mild COPD",
        allergies: "Sulfa drugs",
        bloodType: "A+",
        mobility: "independent",
        emergencyContactName: "Grace Bennett",
        emergencyContactPhone: "+1 (555) 778-4410",
        notes:
          "Former ship engineer. Checks his own glucose but needs reminders after lunch. Enjoys walks by the marina.",
        accent: "honey",
      },
      {
        name: "Rosa Delgado",
        age: 86,
        gender: "female",
        address: "57 Citrus Grove Ave, Maplewood",
        conditions: "Osteoporosis, Post-hip replacement (2024)",
        allergies: "None known",
        bloodType: "B+",
        mobility: "wheelchair",
        emergencyContactName: "Miguel Delgado",
        emergencyContactPhone: "+1 (555) 663-9027",
        notes:
          "Speaks Spanish and English. Afternoon naps are sacred — schedule visits before 15:00. Falls risk: high.",
        accent: "clay",
      },
      {
        name: "Henry Whitfield",
        age: 74,
        gender: "male",
        address: "8 Chestnut Court, Maplewood",
        conditions: "Atrial fibrillation, Recovery from knee surgery",
        allergies: "Ibuprofen",
        bloodType: "AB−",
        mobility: "walking aid",
        emergencyContactName: "Sarah Whitfield",
        emergencyContactPhone: "+1 (555) 229-8374",
        notes: "Retired teacher. New to the service — building confidence with daily routines.",
        accent: "sky",
      },
    ])
    .returning();

  const [E1, E2, E3, E4] = elderRows;

  console.log("Seeding caregivers…");
  const caregiverRows = await db
    .insert(caregivers)
    .values([
      {
        name: "Priya Raman",
        specialty: "Dementia & memory care",
        bio: "Certified dementia practitioner with a gentle, routine-first approach. Margaret's primary caregiver for two years.",
        phone: "+1 (555) 201-8845",
        yearsExperience: 9,
        rating: "4.9",
        status: "on_shift",
      },
      {
        name: "Daniel Mensah",
        specialty: "Post-surgical mobility",
        bio: "Physiotherapy background; specializes in rebuilding strength and confidence after surgery.",
        phone: "+1 (555) 344-1207",
        yearsExperience: 7,
        rating: "4.8",
        status: "available",
      },
      {
        name: "Lucia Fernandez",
        specialty: "Diabetes care & nutrition",
        bio: "Bilingual (EN/ES). Plans and prepares diabetic-friendly meals and supervises glucose routines.",
        phone: "+1 (555) 512-7660",
        yearsExperience: 6,
        rating: "4.9",
        status: "available",
      },
      {
        name: "Tom Becker",
        specialty: "Overnight & respite care",
        bio: "Calm overnight presence for families needing rest. Trained in fall prevention and night disorientation.",
        phone: "+1 (555) 908-3341",
        yearsExperience: 5,
        rating: "4.7",
        status: "off_duty",
      },
      {
        name: "Amara Sy",
        specialty: "Companionship & wellbeing",
        bio: "Focuses on joyful daily structure — music, gentle exercise, and community outings.",
        phone: "+1 (555) 671-0092",
        yearsExperience: 4,
        rating: "4.8",
        status: "on_shift",
      },
      {
        name: "Jonas Petersen",
        specialty: "Palliative comfort care",
        bio: "Hospice-trained nurse assistant providing dignified comfort-focused support.",
        phone: "+1 (555) 830-4455",
        yearsExperience: 11,
        rating: "5.0",
        status: "available",
      },
    ])
    .returning();
  const [C1, C2, C3, C4, C5] = caregiverRows;
  void C4;

  console.log("Seeding doctors…");
  const doctorRows = await db
    .insert(doctors)
    .values([
      { name: "Amara Okafor", specialty: "Cardiology", clinic: "Riverside Heart Center", phone: "+1 (555) 010-7788" },
      { name: "Julian Meyer", specialty: "Geriatric medicine", clinic: "Maplewood Senior Health", phone: "+1 (555) 010-2233" },
      { name: "Sofia Lindqvist", specialty: "Neurology", clinic: "Northgate Memory Clinic", phone: "+1 (555) 010-9871" },
      { name: "Rajiv Patel", specialty: "Endocrinology", clinic: "Riverside Diabetes Center", phone: "+1 (555) 010-5540" },
      { name: "Elena Moretti", specialty: "Ophthalmology", clinic: "Clearview Eye Institute", phone: "+1 (555) 010-6612" },
      { name: "Marcus Hale", specialty: "General practice", clinic: "Willow Lane Family Practice", phone: "+1 (555) 010-3309" },
    ])
    .returning();
  const [D1, D2, D3, D4, D5, D6] = doctorRows;
  void D2;

  console.log("Seeding profiles…");
  await db.insert(profiles).values([
    { name: "Margaret Ellis", role: "elder", email: "margaret@family.example", phone: "+1 (555) 014-0001" },
    { name: "Renata Ellis", role: "family", email: "renata@family.example", phone: "+1 (555) 014-2288" },
    { name: "Priya Raman", role: "caregiver", email: "priya@eldercare.example", phone: "+1 (555) 201-8845" },
    { name: "Oliver Grant", role: "admin", email: "oliver@eldercare.example", phone: "+1 (555) 900-1122" },
  ]);

  console.log("Seeding appointments…");
  await db.insert(appointments).values([
    {
      elderId: E1.id,
      doctorId: D1.id,
      scheduledAt: at(-9, 11, 0),
      type: "Checkup",
      location: "Riverside Heart Center, Room 4",
      reason: "Blood pressure review — readings improved",
      status: "completed",
    },
    {
      elderId: E2.id,
      doctorId: D4.id,
      scheduledAt: at(-6, 9, 30),
      type: "Lab work",
      location: "Riverside Diabetes Center",
      reason: "Quarterly HbA1c panel",
      status: "completed",
    },
    {
      elderId: E1.id,
      doctorId: D3.id,
      scheduledAt: at(0, 15, 30) > new Date() ? at(0, 15, 30) : at(1, 15, 30),
      type: "Follow-up",
      location: "Northgate Memory Clinic",
      reason: "Memory care plan review with Renata",
      status: "scheduled",
    },
    {
      elderId: E1.id,
      doctorId: D1.id,
      scheduledAt: at(1, 10, 30),
      type: "Checkup",
      location: "Riverside Heart Center",
      reason: "Annual cardiology review",
      status: "scheduled",
    },
    {
      elderId: E2.id,
      doctorId: D6.id,
      scheduledAt: at(3, 9, 0),
      type: "Checkup",
      location: "Willow Lane Family Practice",
      reason: "Seasonal health check + flu shot",
      status: "scheduled",
    },
    {
      elderId: E3.id,
      doctorId: D5.id,
      scheduledAt: at(5, 13, 0),
      type: "Vision",
      location: "Clearview Eye Institute",
      reason: "Cataract screening — transport arranged",
      status: "scheduled",
    },
    {
      elderId: E4.id,
      doctorId: D1.id,
      scheduledAt: at(7, 14, 15),
      type: "Specialist",
      location: "Riverside Heart Center",
      reason: "AFib medication adjustment",
      status: "scheduled",
    },
    {
      elderId: E3.id,
      doctorId: D6.id,
      scheduledAt: at(-21, 10, 0),
      type: "Follow-up",
      location: "Willow Lane Family Practice",
      reason: "Post-op hip check",
      status: "completed",
    },
  ]);

  console.log("Seeding medications…");
  const medRows = await db
    .insert(medications)
    .values([
      {
        elderId: E1.id,
        name: "Donepezil",
        dosage: "10 mg · 1 tablet",
        instructions: "Take with breakfast and a full glass of water.",
        times: ["08:00"],
        accent: "honey",
        prescriber: "Dr. Lindqvist",
      },
      {
        elderId: E1.id,
        name: "Amlodipine",
        dosage: "5 mg · 1 tablet",
        instructions: "For blood pressure. Take at the same time each morning.",
        times: ["08:00"],
        accent: "pine",
        prescriber: "Dr. Okafor",
      },
      {
        elderId: E1.id,
        name: "Vitamin D3",
        dosage: "1000 IU · 1 capsule",
        instructions: "Take with the evening meal.",
        times: ["18:30"],
        accent: "sky",
        prescriber: "Dr. Meyer",
      },
      {
        elderId: E2.id,
        name: "Metformin",
        dosage: "500 mg · 1 tablet",
        instructions: "Twice daily with food — breakfast and dinner.",
        times: ["08:00", "18:30"],
        accent: "honey",
        prescriber: "Dr. Patel",
      },
      {
        elderId: E2.id,
        name: "Tiotropium inhaler",
        dosage: "18 mcg · 2 puffs",
        instructions: "Once daily, mid-morning. Rinse mouth after use.",
        times: ["10:00"],
        accent: "sky",
        prescriber: "Dr. Hale",
      },
      {
        elderId: E3.id,
        name: "Calcium + D3",
        dosage: "600 mg · 1 tablet",
        instructions: "With lunch. Support bone strength after hip surgery.",
        times: ["12:30"],
        accent: "clay",
        prescriber: "Dr. Hale",
      },
      {
        elderId: E3.id,
        name: "Acetaminophen",
        dosage: "500 mg · 1–2 tablets",
        instructions: "Only as needed for pain, max 3 times daily.",
        times: ["09:00", "15:00", "21:00"],
        accent: "rose",
        prescriber: "Dr. Hale",
        active: false,
      },
      {
        elderId: E4.id,
        name: "Apixaban",
        dosage: "5 mg · 1 tablet",
        instructions: "Blood thinner — never skip a dose. Morning and evening.",
        times: ["08:30", "20:30"],
        accent: "clay",
        prescriber: "Dr. Okafor",
      },
    ])
    .returning();

  const margaretMorning = medRows.filter((m) => m.elderId === E1.id && (m.times as string[]).includes("08:00"));
  const arthurMorning = medRows.find((m) => m.elderId === E2.id && (m.times as string[]).includes("08:00"));
  const henryMorning = medRows.find((m) => m.elderId === E4.id && (m.times as string[]).includes("08:30"));

  console.log("Seeding medication logs…");
  const logValues = [
    ...margaretMorning.map((m, i) => ({
      medicationId: m.id,
      elderId: E1.id,
      scheduledFor: at(0, 8, 0),
      status: "taken" as const,
      loggedAt: at(0, 8, 12 + i * 3),
    })),
    ...(arthurMorning
      ? [
          {
            medicationId: arthurMorning.id,
            elderId: E2.id,
            scheduledFor: at(0, 8, 0),
            status: "taken" as const,
            loggedAt: at(0, 8, 25),
          },
        ]
      : []),
    ...(henryMorning
      ? [
          {
            medicationId: henryMorning.id,
            elderId: E4.id,
            scheduledFor: at(0, 8, 30),
            status: "taken" as const,
            loggedAt: at(0, 8, 41),
          },
        ]
      : []),
    ...margaretMorning.map((m, i) => ({
      medicationId: m.id,
      elderId: E1.id,
      scheduledFor: at(-1, 8, 0),
      status: "taken" as const,
      loggedAt: at(-1, 8, 9 + i * 4),
    })),
  ];
  if (logValues.length) await db.insert(medicationLogs).values(logValues);

  console.log("Seeding health records…");
  const healthValues: (typeof healthRecords.$inferInsert)[] = [];
  const bpSeries = [138, 134, 136, 131, 129, 133, 128, 130, 127, 129, 126, 128];
  const diaSeries = [85, 84, 86, 82, 81, 83, 80, 82, 79, 81, 78, 80];
  const hrSeries = [78, 76, 79, 74, 75, 73, 74, 72, 73, 71, 72, 71];
  bpSeries.forEach((sys, i) => {
    healthValues.push({
      elderId: E1.id,
      type: "blood_pressure",
      value: `${sys}/${diaSeries[i]}`,
      unit: "mmHg",
      notes: i === bpSeries.length - 1 ? "Morning reading, resting" : "",
      recordedAt: at(-(bpSeries.length - 1 - i), 8, 30),
    });
    healthValues.push({
      elderId: E1.id,
      type: "heart_rate",
      value: String(hrSeries[i]),
      unit: "bpm",
      recordedAt: at(-(hrSeries.length - 1 - i), 8, 32),
    });
  });
  const glucoseSeries = [122, 118, 125, 119, 112, 115, 109, 111, 107, 108, 104, 105];
  glucoseSeries.forEach((g, i) => {
    healthValues.push({
      elderId: E2.id,
      type: "glucose",
      value: String(g),
      unit: "mg/dL",
      notes: i === glucoseSeries.length - 1 ? "Fasting, before breakfast" : "",
      recordedAt: at(-(glucoseSeries.length - 1 - i), 7, 45),
    });
  });
  const weightSeries = [79.8, 79.6, 79.7, 79.4, 79.3, 79.1, 79.2, 78.9];
  weightSeries.forEach((w, i) => {
    healthValues.push({
      elderId: E2.id,
      type: "weight",
      value: String(w),
      unit: "kg",
      recordedAt: at(-((weightSeries.length - 1 - i) * 2), 9, 0),
    });
  });
  const oxygenSeries = [95, 96, 95, 97, 96, 97];
  oxygenSeries.forEach((o, i) => {
    healthValues.push({
      elderId: E3.id,
      type: "oxygen",
      value: String(o),
      unit: "%",
      recordedAt: at(-(oxygenSeries.length - 1 - i), 11, 0),
    });
  });
  healthValues.push({
    elderId: E4.id,
    type: "heart_rate",
    value: "82",
    unit: "bpm",
    notes: "Slightly elevated after physio",
    recordedAt: at(0, 10, 5),
  });
  await db.insert(healthRecords).values(healthValues);

  console.log("Seeding care tasks…");
  await db.insert(careTasks).values([
    {
      caregiverId: C1.id,
      elderId: E1.id,
      title: "Morning routine assistance",
      category: "Daily care",
      scheduledFor: at(0, 7, 30),
      window: "morning",
      status: "done",
      notes: "Help with washing, dressing, and breakfast setup.",
    },
    {
      caregiverId: C1.id,
      elderId: E1.id,
      title: "Garden walk — 20 minutes",
      category: "Mobility & exercise",
      scheduledFor: at(0, 10, 30),
      window: "morning",
      priority: "high",
      status: "in_progress",
      notes: "Bring the walker. She loves checking the roses.",
    },
    {
      caregiverId: C3.id,
      elderId: E2.id,
      title: "Lunch prep — diabetic friendly",
      category: "Meals & nutrition",
      scheduledFor: at(0, 12, 0),
      window: "midday",
      status: "pending",
      notes: "Log post-lunch glucose around 13:30.",
    },
    {
      caregiverId: C5.id,
      elderId: E3.id,
      title: "Transfer practice & stretching",
      category: "Mobility & exercise",
      scheduledFor: at(0, 14, 0),
      window: "afternoon",
      status: "pending",
      priority: "high",
      notes: "Wheelchair-to-chair transfers, supervised. Stop if fatigued.",
    },
    {
      caregiverId: C1.id,
      elderId: E1.id,
      title: "Memory games & photo album",
      category: "Companionship",
      scheduledFor: at(0, 16, 0),
      window: "afternoon",
      status: "pending",
    },
    {
      caregiverId: C2.id,
      elderId: E4.id,
      title: "Knee physiotherapy exercises",
      category: "Mobility & exercise",
      scheduledFor: at(0, 9, 0),
      window: "morning",
      status: "done",
      notes: "Week 3 protocol — flexion improving.",
    },
    {
      caregiverId: C1.id,
      elderId: E1.id,
      title: "Accompany to cardiology",
      category: "Health check",
      scheduledFor: at(1, 9, 45),
      window: "morning",
      status: "pending",
      notes: "Car leaves at 09:45. Bring medication list.",
    },
    {
      caregiverId: C3.id,
      elderId: E2.id,
      title: "Weekly meal plan review",
      category: "Meals & nutrition",
      scheduledFor: at(1, 15, 0),
      window: "afternoon",
      status: "pending",
    },
    {
      caregiverId: C5.id,
      elderId: E3.id,
      title: "Light housekeeping & laundry",
      category: "Household",
      scheduledFor: at(1, 10, 0),
      window: "morning",
      status: "pending",
    },
    {
      caregiverId: C2.id,
      elderId: E4.id,
      title: "Marina walk with Arthur — joint outing",
      category: "Companionship",
      scheduledFor: at(2, 10, 0),
      window: "morning",
      status: "pending",
    },
  ]);

  console.log("Seeding service requests…");
  await db.insert(serviceRequests).values([
    {
      elderId: E3.id,
      serviceType: "Transport to appointment",
      details: "Eye institute visit on Friday — needs wheelchair-accessible vehicle and escort to the door.",
      preferredAt: at(5, 12, 15),
      status: "open",
    },
    {
      elderId: E2.id,
      caregiverId: C3.id,
      serviceType: "Meal preparation",
      details: "Three diabetic-friendly dinners to cover the weekend.",
      preferredAt: at(2, 16, 0),
      status: "assigned",
    },
    {
      elderId: E1.id,
      caregiverId: C5.id,
      serviceType: "Companionship visit",
      details: "Sunday afternoon company — music and a short drive if the weather is kind.",
      preferredAt: at(4, 14, 0),
      status: "in_progress",
    },
    {
      elderId: E1.id,
      caregiverId: C4.id,
      serviceType: "Overnight care",
      details: "Covered while Renata traveled for work.",
      preferredAt: at(-12, 20, 0),
      status: "completed",
    },
  ]);

  console.log("Seeding alerts…");
  await db.insert(emergencyAlerts).values([
    {
      elderId: E1.id,
      type: "fall",
      note: "Bathroom sensor triggered. Minor bruise, no fracture. Protocol reviewed.",
      status: "resolved",
      createdAt: at(-4, 6, 41),
      acknowledgedAt: at(-4, 6, 43),
      resolvedAt: at(-4, 8, 5),
    },
  ]);

  console.log("Seeding activity feed…");
  await db.insert(activities).values([
    { actor: "Priya Raman", summary: "Margaret took Donepezil 10 mg · 1 tablet", kind: "medication", createdAt: at(0, 8, 12) },
    { actor: "Priya Raman", summary: "Recorded blood pressure 128/80 mmHg for Margaret", kind: "health", createdAt: at(0, 8, 32) },
    { actor: "Lucia Fernandez", summary: "Arthur took Metformin 500 mg", kind: "medication", createdAt: at(0, 8, 25) },
    { actor: "Daniel Mensah", summary: "Completed task \"Knee physiotherapy exercises\"", kind: "task", createdAt: at(0, 9, 40) },
    { actor: "Renata Ellis", summary: "Booked a follow-up for Margaret with Dr. Lindqvist", kind: "appointment", createdAt: at(0, 9, 55) },
    { actor: "System", summary: "Transport to appointment requested for Rosa", kind: "request", createdAt: at(0, 10, 5) },
    { actor: "Priya Raman", summary: "Started task \"Garden walk — 20 minutes\"", kind: "task", createdAt: at(0, 10, 30) },
    { actor: "Grace Bennett", summary: "Booked a checkup for Arthur with Dr. Hale", kind: "appointment", createdAt: at(-1, 16, 20) },
    { actor: "Caregiver", summary: "Margaret took Amlodipine 5 mg · 1 tablet", kind: "medication", createdAt: at(-1, 8, 13) },
    { actor: "Amara Sy", summary: "Completed task \"Light housekeeping & laundry\"", kind: "task", createdAt: at(-1, 12, 5) },
    { actor: "Oliver Grant", summary: "Assigned Lucia Fernandez to a meal preparation request", kind: "request", createdAt: at(-2, 11, 30) },
    { actor: "Caregiver", summary: "Resolved an emergency alert for Margaret", kind: "alert", createdAt: at(-4, 8, 5) },
  ]);

  console.log("Seed complete ✔");
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
