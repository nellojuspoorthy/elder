import {
  pgTable,
  pgEnum,
  uuid,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  numeric,
} from "drizzle-orm/pg-core";

/* ---------------------------------- enums ---------------------------------- */

export const roleEnum = pgEnum("role", ["elder", "family", "caregiver", "admin"]);

export const appointmentStatusEnum = pgEnum("appointment_status", [
  "scheduled",
  "completed",
  "cancelled",
]);

export const medLogStatusEnum = pgEnum("med_log_status", [
  "taken",
  "missed",
  "skipped",
]);

export const taskStatusEnum = pgEnum("task_status", [
  "pending",
  "in_progress",
  "done",
  "skipped",
]);

export const requestStatusEnum = pgEnum("request_status", [
  "open",
  "assigned",
  "in_progress",
  "completed",
  "cancelled",
]);

export const alertStatusEnum = pgEnum("alert_status", [
  "active",
  "acknowledged",
  "resolved",
]);

/* ---------------------------------- tables --------------------------------- */

export const profiles = pgTable("profiles", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  role: roleEnum("role").notNull(),
  email: text("email"),
  phone: text("phone"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const elders = pgTable("elders", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  age: integer("age").notNull(),
  gender: text("gender").notNull().default("female"),
  address: text("address"),
  conditions: text("conditions").default(""),
  allergies: text("allergies").default(""),
  bloodType: text("blood_type").default(""),
  mobility: text("mobility").default("independent"),
  emergencyContactName: text("emergency_contact_name"),
  emergencyContactPhone: text("emergency_contact_phone"),
  notes: text("notes").default(""),
  accent: text("accent").default("teal"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const caregivers = pgTable("caregivers", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  specialty: text("specialty").notNull(),
  bio: text("bio").default(""),
  phone: text("phone"),
  yearsExperience: integer("years_experience").default(3).notNull(),
  rating: numeric("rating", { precision: 2, scale: 1 }).default("4.8").notNull(),
  // available | on_shift | off_duty
  status: text("status").default("available").notNull(),
  verified: boolean("verified").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const doctors = pgTable("doctors", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  specialty: text("specialty").notNull(),
  clinic: text("clinic").notNull(),
  phone: text("phone"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const appointments = pgTable("appointments", {
  id: uuid("id").defaultRandom().primaryKey(),
  elderId: uuid("elder_id")
    .references(() => elders.id, { onDelete: "cascade" })
    .notNull(),
  doctorId: uuid("doctor_id")
    .references(() => doctors.id, { onDelete: "cascade" })
    .notNull(),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }).notNull(),
  type: text("type").notNull().default("Checkup"),
  location: text("location").default(""),
  reason: text("reason").default(""),
  status: appointmentStatusEnum("status").default("scheduled").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const medications = pgTable("medications", {
  id: uuid("id").defaultRandom().primaryKey(),
  elderId: uuid("elder_id")
    .references(() => elders.id, { onDelete: "cascade" })
    .notNull(),
  name: text("name").notNull(),
  dosage: text("dosage").notNull(),
  instructions: text("instructions").default(""),
  // array of "HH:MM" strings, e.g. ["08:00","20:00"]
  times: jsonb("times").$type<string[]>().notNull(),
  active: boolean("active").default(true).notNull(),
  accent: text("accent").default("teal"),
  prescriber: text("prescriber").default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const medicationLogs = pgTable("medication_logs", {
  id: uuid("id").defaultRandom().primaryKey(),
  medicationId: uuid("medication_id")
    .references(() => medications.id, { onDelete: "cascade" })
    .notNull(),
  elderId: uuid("elder_id")
    .references(() => elders.id, { onDelete: "cascade" })
    .notNull(),
  scheduledFor: timestamp("scheduled_for", { withTimezone: true }).notNull(),
  status: medLogStatusEnum("status").notNull(),
  loggedAt: timestamp("logged_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const healthRecords = pgTable("health_records", {
  id: uuid("id").defaultRandom().primaryKey(),
  elderId: uuid("elder_id")
    .references(() => elders.id, { onDelete: "cascade" })
    .notNull(),
  // blood_pressure | heart_rate | glucose | weight | oxygen | temperature
  type: text("type").notNull(),
  value: text("value").notNull(),
  unit: text("unit").notNull(),
  notes: text("notes").default(""),
  recordedAt: timestamp("recorded_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const careTasks = pgTable("care_tasks", {
  id: uuid("id").defaultRandom().primaryKey(),
  caregiverId: uuid("caregiver_id").references(() => caregivers.id, {
    onDelete: "set null",
  }),
  elderId: uuid("elder_id")
    .references(() => elders.id, { onDelete: "cascade" })
    .notNull(),
  title: text("title").notNull(),
  category: text("category").default("Daily care"),
  scheduledFor: timestamp("scheduled_for", { withTimezone: true }).notNull(),
  window: text("window").default("morning"),
  priority: text("priority").default("normal"),
  status: taskStatusEnum("status").default("pending").notNull(),
  notes: text("notes").default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const serviceRequests = pgTable("service_requests", {
  id: uuid("id").defaultRandom().primaryKey(),
  elderId: uuid("elder_id")
    .references(() => elders.id, { onDelete: "cascade" })
    .notNull(),
  caregiverId: uuid("caregiver_id").references(() => caregivers.id, {
    onDelete: "set null",
  }),
  serviceType: text("service_type").notNull(),
  details: text("details").default(""),
  preferredAt: timestamp("preferred_at", { withTimezone: true }),
  status: requestStatusEnum("status").default("open").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const emergencyAlerts = pgTable("emergency_alerts", {
  id: uuid("id").defaultRandom().primaryKey(),
  elderId: uuid("elder_id")
    .references(() => elders.id, { onDelete: "cascade" })
    .notNull(),
  type: text("type").notNull().default("medical"),
  note: text("note").default(""),
  status: alertStatusEnum("status").default("active").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  acknowledgedAt: timestamp("acknowledged_at", { withTimezone: true }),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
});

export const activities = pgTable("activities", {
  id: uuid("id").defaultRandom().primaryKey(),
  actor: text("actor").notNull(),
  summary: text("summary").notNull(),
  // info | medication | appointment | alert | task | request | health
  kind: text("kind").default("info").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ----------------------------------- types --------------------------------- */

export type Elder = typeof elders.$inferSelect;
export type Caregiver = typeof caregivers.$inferSelect;
export type Doctor = typeof doctors.$inferSelect;
export type Appointment = typeof appointments.$inferSelect;
export type Medication = typeof medications.$inferSelect;
export type MedicationLog = typeof medicationLogs.$inferSelect;
export type HealthRecord = typeof healthRecords.$inferSelect;
export type CareTask = typeof careTasks.$inferSelect;
export type ServiceRequest = typeof serviceRequests.$inferSelect;
export type EmergencyAlert = typeof emergencyAlerts.$inferSelect;
export type Activity = typeof activities.$inferSelect;
export type Profile = typeof profiles.$inferSelect;
