import { z } from "zod";

/* Shared validation schemas (imported by server actions and client forms) */

export const idSchema = z.string().uuid("Invalid record");
export const hhmmSchema = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Use HH:MM");

export const appointmentSchema = z.object({
  elderId: idSchema,
  doctorId: idSchema,
  date: z.string().min(1, "Pick a date"),
  time: hhmmSchema,
  type: z.string().min(2, "Pick a type"),
  location: z.string().optional(),
  reason: z.string().optional(),
});

export const medicationSchema = z.object({
  elderId: idSchema,
  name: z.string().min(2, "Medication name is required"),
  dosage: z.string().min(1, "Dosage is required"),
  instructions: z.string().optional(),
  times: z.array(hhmmSchema).min(1, "Add at least one time"),
  prescriber: z.string().optional(),
  accent: z.string().optional(),
});

export const elderSchema = z.object({
  name: z.string().min(2, "Name is required"),
  age: z.coerce.number().int().min(50, "Age must be 50+").max(120),
  gender: z.string().default("female"),
  address: z.string().optional(),
  conditions: z.string().optional(),
  allergies: z.string().optional(),
  bloodType: z.string().optional(),
  mobility: z.string().default("independent"),
  emergencyContactName: z.string().optional(),
  emergencyContactPhone: z.string().optional(),
  notes: z.string().optional(),
  accent: z.string().optional(),
});

export const vitalSchema = z.object({
  elderId: idSchema,
  type: z.enum(["blood_pressure", "heart_rate", "glucose", "weight", "oxygen", "temperature"]),
  value: z.string().min(1, "Enter a reading"),
  unit: z.string().min(1),
  notes: z.string().optional(),
});

export const requestSchema = z.object({
  elderId: idSchema,
  serviceType: z.string().min(2, "Choose a service"),
  details: z.string().optional(),
  preferredAt: z.string().optional(),
});

export const caregiverSchema = z.object({
  name: z.string().min(2, "Name is required"),
  specialty: z.string().min(2, "Specialty is required"),
  bio: z.string().optional(),
  phone: z.string().optional(),
  yearsExperience: z.coerce.number().int().min(0).max(60),
  status: z.enum(["available", "on_shift", "off_duty"]).default("available"),
});

export const doctorSchema = z.object({
  name: z.string().min(2, "Name is required"),
  specialty: z.string().min(2, "Specialty is required"),
  clinic: z.string().min(2, "Clinic is required"),
  phone: z.string().optional(),
});

export const taskSchema = z.object({
  elderId: idSchema,
  caregiverId: z.string().uuid().optional().or(z.literal("")),
  title: z.string().min(3, "Task title is required"),
  category: z.string().default("Daily care"),
  date: z.string().min(1, "Pick a date"),
  time: hhmmSchema,
  window: z.string().default("morning"),
  priority: z.string().default("normal"),
  notes: z.string().optional(),
});
