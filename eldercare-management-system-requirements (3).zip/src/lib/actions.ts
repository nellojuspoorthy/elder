"use server";

import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { db } from "@/db";
import {
  activities,
  appointments,
  caregivers,
  careTasks,
  doctors,
  elders,
  emergencyAlerts,
  healthRecords,
  medicationLogs,
  medications,
  serviceRequests,
} from "@/db/schema";
import {
  appointmentSchema,
  caregiverSchema,
  doctorSchema,
  elderSchema,
  idSchema,
  medicationSchema,
  requestSchema,
  taskSchema,
  vitalSchema,
} from "@/lib/schemas";

/* --------------------------------- helpers --------------------------------- */

async function logActivity(actor: string, summary: string, kind: string) {
  await db.insert(activities).values({ actor, summary, kind });
}

const REVALIDATE = [
  "/dashboard",
  "/dashboard/appointments",
  "/dashboard/medications",
  "/dashboard/elders",
  "/dashboard/caregivers",
  "/dashboard/tasks",
  "/dashboard/admin",
];

function revalidateAll(paths: string[] = REVALIDATE) {
  for (const p of paths) revalidatePath(p);
}

/* ------------------------------- appointments ------------------------------ */

export async function bookAppointment(input: z.infer<typeof appointmentSchema>) {
  const data = appointmentSchema.parse(input);
  const scheduledAt = new Date(`${data.date}T${data.time}:00`);
  if (Number.isNaN(scheduledAt.getTime())) throw new Error("Invalid date");
  if (scheduledAt.getTime() < Date.now() - 5 * 60 * 1000)
    throw new Error("Please choose a future time");

  await db.insert(appointments).values({
    elderId: data.elderId,
    doctorId: data.doctorId,
    scheduledAt,
    type: data.type,
    location: data.location ?? "",
    reason: data.reason ?? "",
  });

  const [elder] = await db.select().from(elders).where(eq(elders.id, data.elderId));
  const [doctor] = await db.select().from(doctors).where(eq(doctors.id, data.doctorId));
  await logActivity(
    "Family",
    `Booked a ${data.type.toLowerCase()} for ${elder?.name ?? "an elder"} with Dr. ${doctor?.name ?? "the doctor"}`,
    "appointment",
  );
  revalidateAll();
  return { ok: true as const };
}

export async function setAppointmentStatus(
  appointmentId: string,
  status: "scheduled" | "completed" | "cancelled",
) {
  idSchema.parse(appointmentId);
  await db
    .update(appointments)
    .set({ status })
    .where(eq(appointments.id, appointmentId));
  await logActivity("Admin", `Marked an appointment as ${status}`, "appointment");
  revalidateAll();
}

/* ------------------------------- medications ------------------------------- */

export async function addMedication(input: z.infer<typeof medicationSchema>) {
  const data = medicationSchema.parse(input);
  await db.insert(medications).values({
    elderId: data.elderId,
    name: data.name,
    dosage: data.dosage,
    instructions: data.instructions ?? "",
    times: [...data.times].sort(),
    prescriber: data.prescriber ?? "",
    accent: data.accent ?? "pine",
  });
  const [elder] = await db.select().from(elders).where(eq(elders.id, data.elderId));
  await logActivity(
    "Family",
    `Added ${data.name} (${data.dosage}) to ${elder?.name ?? "an elder"}'s schedule`,
    "medication",
  );
  revalidateAll();
  return { ok: true as const };
}

export async function toggleMedication(medicationId: string, active: boolean) {
  idSchema.parse(medicationId);
  await db.update(medications).set({ active }).where(eq(medications.id, medicationId));
  revalidateAll();
}

export async function logDose(
  medicationId: string,
  scheduledForISO: string,
  status: "taken" | "missed" | "skipped",
) {
  idSchema.parse(medicationId);
  const [med] = await db
    .select()
    .from(medications)
    .where(eq(medications.id, medicationId));
  if (!med) throw new Error("Medication not found");
  const scheduledFor = new Date(scheduledForISO);

  // upsert-ish: update the log for the same slot if it exists
  const existing = await db
    .select()
    .from(medicationLogs)
    .where(eq(medicationLogs.medicationId, medicationId));
  const dupe = existing.find(
    (l) => Math.abs(l.scheduledFor.getTime() - scheduledFor.getTime()) < 1000,
  );
  if (dupe) {
    await db
      .update(medicationLogs)
      .set({ status, loggedAt: new Date() })
      .where(eq(medicationLogs.id, dupe.id));
  } else {
    await db.insert(medicationLogs).values({
      medicationId,
      elderId: med.elderId,
      scheduledFor,
      status,
    });
  }
  const [elder] = await db.select().from(elders).where(eq(elders.id, med.elderId));
  await logActivity(
    "Caregiver",
    `${elder?.name ?? "An elder"} ${status === "taken" ? "took" : status} ${med.name} ${med.dosage}`,
    "medication",
  );
  revalidateAll();
}

/* ---------------------------------- elders --------------------------------- */

export async function addElder(input: z.infer<typeof elderSchema>) {
  const data = elderSchema.parse(input);
  await db.insert(elders).values({
    name: data.name,
    age: data.age,
    gender: data.gender,
    address: data.address ?? "",
    conditions: data.conditions ?? "",
    allergies: data.allergies ?? "",
    bloodType: data.bloodType ?? "",
    mobility: data.mobility,
    emergencyContactName: data.emergencyContactName ?? "",
    emergencyContactPhone: data.emergencyContactPhone ?? "",
    notes: data.notes ?? "",
    accent: data.accent ?? "pine",
  });
  await logActivity("Admin", `Created a care profile for ${data.name}`, "info");
  revalidateAll();
  return { ok: true as const };
}

export async function addVital(input: z.infer<typeof vitalSchema>) {
  const data = vitalSchema.parse(input);
  await db.insert(healthRecords).values({
    elderId: data.elderId,
    type: data.type,
    value: data.value,
    unit: data.unit,
    notes: data.notes ?? "",
  });
  const [elder] = await db.select().from(elders).where(eq(elders.id, data.elderId));
  await logActivity(
    "Caregiver",
    `Recorded ${data.type.replace("_", " ")} ${data.value} ${data.unit} for ${elder?.name ?? "an elder"}`,
    "health",
  );
  revalidateAll();
  return { ok: true as const };
}

/* ---------------------------- service requests ----------------------------- */

export async function requestCare(input: z.infer<typeof requestSchema>) {
  const data = requestSchema.parse(input);
  const preferredAt = data.preferredAt ? new Date(data.preferredAt) : null;
  await db.insert(serviceRequests).values({
    elderId: data.elderId,
    serviceType: data.serviceType,
    details: data.details ?? "",
    preferredAt: preferredAt && !Number.isNaN(preferredAt.getTime()) ? preferredAt : null,
  });
  const [elder] = await db.select().from(elders).where(eq(elders.id, data.elderId));
  await logActivity(
    "Family",
    `Requested ${data.serviceType.toLowerCase()} for ${elder?.name ?? "an elder"}`,
    "request",
  );
  revalidateAll();
  return { ok: true as const };
}

export async function assignRequest(requestId: string, caregiverId: string) {
  idSchema.parse(requestId);
  idSchema.parse(caregiverId);
  await db
    .update(serviceRequests)
    .set({ caregiverId, status: "assigned" })
    .where(eq(serviceRequests.id, requestId));
  const [cg] = await db.select().from(caregivers).where(eq(caregivers.id, caregiverId));
  await logActivity("Admin", `Assigned ${cg?.name ?? "a caregiver"} to a service request`, "request");
  revalidateAll();
}

export async function setRequestStatus(
  requestId: string,
  status: "open" | "assigned" | "in_progress" | "completed" | "cancelled",
) {
  idSchema.parse(requestId);
  await db.update(serviceRequests).set({ status }).where(eq(serviceRequests.id, requestId));
  await logActivity("Admin", `Updated a service request to ${status.replace("_", " ")}`, "request");
  revalidateAll();
}

export async function setCaregiverStatus(
  caregiverId: string,
  status: "available" | "on_shift" | "off_duty",
) {
  idSchema.parse(caregiverId);
  await db.update(caregivers).set({ status }).where(eq(caregivers.id, caregiverId));
  revalidateAll();
}

export async function addCaregiver(input: z.infer<typeof caregiverSchema>) {
  const data = caregiverSchema.parse(input);
  await db.insert(caregivers).values({
    name: data.name,
    specialty: data.specialty,
    bio: data.bio ?? "",
    phone: data.phone ?? "",
    yearsExperience: data.yearsExperience,
    status: data.status,
  });
  await logActivity("Admin", `Onboarded caregiver ${data.name}`, "info");
  revalidateAll();
  return { ok: true as const };
}

export async function addDoctor(input: z.infer<typeof doctorSchema>) {
  const data = doctorSchema.parse(input);
  await db.insert(doctors).values({
    name: data.name,
    specialty: data.specialty,
    clinic: data.clinic,
    phone: data.phone ?? "",
  });
  await logActivity("Admin", `Added Dr. ${data.name} (${data.specialty})`, "info");
  revalidateAll();
  return { ok: true as const };
}

/* ---------------------------------- tasks ---------------------------------- */

export async function addCareTask(input: z.infer<typeof taskSchema>) {
  const data = taskSchema.parse(input);
  const scheduledFor = new Date(`${data.date}T${data.time}:00`);
  await db.insert(careTasks).values({
    elderId: data.elderId,
    caregiverId: data.caregiverId || null,
    title: data.title,
    category: data.category,
    scheduledFor,
    window: data.window,
    priority: data.priority,
    notes: data.notes ?? "",
  });
  await logActivity("Family", `Scheduled task "${data.title}"`, "task");
  revalidateAll();
  return { ok: true as const };
}

export async function setTaskStatus(
  taskId: string,
  status: "pending" | "in_progress" | "done" | "skipped",
) {
  idSchema.parse(taskId);
  const [task] = await db.select().from(careTasks).where(eq(careTasks.id, taskId));
  await db.update(careTasks).set({ status }).where(eq(careTasks.id, taskId));
  if (task && status === "done") {
    await logActivity("Caregiver", `Completed task "${task.title}"`, "task");
  }
  revalidateAll();
}

/* --------------------------------- alerts ---------------------------------- */

export async function triggerAlert(elderId: string, type: string, note?: string) {
  idSchema.parse(elderId);
  const [elder] = await db.select().from(elders).where(eq(elders.id, elderId));
  await db.insert(emergencyAlerts).values({
    elderId,
    type,
    note: note ?? "",
  });
  await logActivity(
    "System",
    `Emergency assistance requested for ${elder?.name ?? "an elder"}`,
    "alert",
  );
  revalidateAll();
  return { ok: true as const };
}

export async function acknowledgeAlert(alertId: string) {
  idSchema.parse(alertId);
  await db
    .update(emergencyAlerts)
    .set({ status: "acknowledged", acknowledgedAt: new Date() })
    .where(eq(emergencyAlerts.id, alertId));
  await logActivity("Caregiver", "Acknowledged an emergency alert and is responding", "alert");
  revalidateAll();
}

export async function resolveAlert(alertId: string) {
  idSchema.parse(alertId);
  await db
    .update(emergencyAlerts)
    .set({ status: "resolved", resolvedAt: new Date() })
    .where(eq(emergencyAlerts.id, alertId));
  await logActivity("Caregiver", "Resolved an emergency alert", "alert");
  revalidateAll();
}
