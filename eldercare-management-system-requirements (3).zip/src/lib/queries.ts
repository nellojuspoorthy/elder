import { and, asc, desc, eq, gte, lt, ne, count, inArray } from "drizzle-orm";
import { db } from "@/db";
import {
  activities,
  appointments,
  caregivers,
  careTasks,
  doctors,
  elders,
  emergencyAlerts,
  healthRecords,
  medicationLogs,
  medications,
  profiles,
  serviceRequests,
  type Elder,
  type Medication,
  type MedicationLog,
} from "@/db/schema";
import { atToday } from "@/lib/utils";

export const startOfDay = (d = new Date()) => {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
};
export const endOfDay = (d = new Date()) => {
  const x = new Date(d);
  x.setHours(23, 59, 59, 999);
  return x;
};

/* ------------------------------- base lists -------------------------------- */

export const getElders = () =>
  db.select().from(elders).orderBy(asc(elders.name));

export const getElder = (id: string) =>
  db.select().from(elders).where(eq(elders.id, id)).then((r) => r[0] ?? null);

export const getCaregivers = () =>
  db.select().from(caregivers).orderBy(desc(caregivers.rating));

export const getDoctors = () =>
  db.select().from(doctors).orderBy(asc(doctors.name));

export const getProfiles = () =>
  db.select().from(profiles).orderBy(asc(profiles.role), asc(profiles.name));

/* ----------------------------- joined listings ----------------------------- */

export const getAppointments = () =>
  db
    .select({
      id: appointments.id,
      scheduledAt: appointments.scheduledAt,
      type: appointments.type,
      location: appointments.location,
      reason: appointments.reason,
      status: appointments.status,
      elderId: elders.id,
      elderName: elders.name,
      elderAccent: elders.accent,
      doctorId: doctors.id,
      doctorName: doctors.name,
      doctorSpecialty: doctors.specialty,
      clinic: doctors.clinic,
    })
    .from(appointments)
    .innerJoin(elders, eq(appointments.elderId, elders.id))
    .innerJoin(doctors, eq(appointments.doctorId, doctors.id))
    .orderBy(asc(appointments.scheduledAt));

export const getServiceRequests = () =>
  db
    .select({
      id: serviceRequests.id,
      serviceType: serviceRequests.serviceType,
      details: serviceRequests.details,
      preferredAt: serviceRequests.preferredAt,
      status: serviceRequests.status,
      createdAt: serviceRequests.createdAt,
      elderId: elders.id,
      elderName: elders.name,
      elderAccent: elders.accent,
      caregiverId: caregivers.id,
      caregiverName: caregivers.name,
    })
    .from(serviceRequests)
    .innerJoin(elders, eq(serviceRequests.elderId, elders.id))
    .leftJoin(caregivers, eq(serviceRequests.caregiverId, caregivers.id))
    .orderBy(desc(serviceRequests.createdAt));

export const getCareTasks = () =>
  db
    .select({
      id: careTasks.id,
      title: careTasks.title,
      category: careTasks.category,
      scheduledFor: careTasks.scheduledFor,
      window: careTasks.window,
      priority: careTasks.priority,
      status: careTasks.status,
      notes: careTasks.notes,
      elderId: elders.id,
      elderName: elders.name,
      elderAccent: elders.accent,
      caregiverId: caregivers.id,
      caregiverName: caregivers.name,
    })
    .from(careTasks)
    .innerJoin(elders, eq(careTasks.elderId, elders.id))
    .leftJoin(caregivers, eq(careTasks.caregiverId, caregivers.id))
    .orderBy(asc(careTasks.scheduledFor));

export const getAlerts = () =>
  db
    .select({
      id: emergencyAlerts.id,
      type: emergencyAlerts.type,
      note: emergencyAlerts.note,
      status: emergencyAlerts.status,
      createdAt: emergencyAlerts.createdAt,
      acknowledgedAt: emergencyAlerts.acknowledgedAt,
      resolvedAt: emergencyAlerts.resolvedAt,
      elderId: elders.id,
      elderName: elders.name,
      elderAccent: elders.accent,
      emergencyContactName: elders.emergencyContactName,
      emergencyContactPhone: elders.emergencyContactPhone,
    })
    .from(emergencyAlerts)
    .innerJoin(elders, eq(emergencyAlerts.elderId, elders.id))
    .orderBy(desc(emergencyAlerts.createdAt));

export const getRecentActivity = (limit = 12) =>
  db.select().from(activities).orderBy(desc(activities.createdAt)).limit(limit);

/* ------------------------- medications + today doses ------------------------ */

export type TodayDose = {
  key: string;
  medication: Medication;
  time: string;
  scheduledFor: Date;
  state: "taken" | "missed" | "skipped" | "due" | "upcoming";
  log?: MedicationLog;
};

export function buildTodayDoses(
  meds: (Medication & { elderName?: string; elderAccent?: string | null })[],
  logs: MedicationLog[],
  now = new Date(),
): (TodayDose & { elderName?: string; elderAccent?: string | null })[] {
  const byKey = new Map<string, MedicationLog>();
  for (const l of logs) {
    byKey.set(`${l.medicationId}|${l.scheduledFor.getTime()}`, l);
  }
  const out: (TodayDose & { elderName?: string; elderAccent?: string | null })[] = [];
  for (const med of meds) {
    if (!med.active) continue;
    for (const time of [...(med.times as string[])].sort()) {
      const scheduledFor = atToday(time, now);
      const log = byKey.get(`${med.id}|${scheduledFor.getTime()}`);
      let state: TodayDose["state"] = "upcoming";
      if (log) state = log.status;
      else if (scheduledFor.getTime() < now.getTime() - 15 * 60 * 1000)
        state = "due";
      out.push({
        key: `${med.id}|${time}`,
        medication: med,
        time,
        scheduledFor,
        state,
        log,
        elderName: (med as { elderName?: string }).elderName,
        elderAccent: (med as { elderAccent?: string }).elderAccent,
      });
    }
  }
  return out.sort((a, b) => a.time.localeCompare(b.time));
}

export const getMedications = () =>
  db
    .select({
      medication: medications,
      elderName: elders.name,
      elderAccent: elders.accent,
    })
    .from(medications)
    .innerJoin(elders, eq(medications.elderId, elders.id))
    .orderBy(asc(elders.name), asc(medications.name));

export const getMedicationsForElder = (elderId: string) =>
  db
    .select()
    .from(medications)
    .where(eq(medications.elderId, elderId))
    .orderBy(asc(medications.name));

export const getTodayLogs = () =>
  db
    .select()
    .from(medicationLogs)
    .where(
      and(
        gte(medicationLogs.scheduledFor, startOfDay()),
        lt(medicationLogs.scheduledFor, endOfDay()),
      ),
    );

export const getRecentLogs = (days = 3) =>
  db
    .select()
    .from(medicationLogs)
    .where(gte(medicationLogs.scheduledFor, new Date(Date.now() - days * 864e5)))
    .orderBy(desc(medicationLogs.scheduledFor));

/* ------------------------------- elder detail ------------------------------ */

export async function getElderDetail(elderId: string) {
  const elder = await getElder(elderId);
  if (!elder) return null;

  const todayStart = startOfDay();
  const dayEnd = endOfDay();

  const [meds, appts, tasks, records, logs, alertsForElder] = await Promise.all([
    getMedicationsForElder(elderId),
    getAppointments().then((all) => all.filter((a) => a.elderId === elderId)),
    getCareTasks().then((all) => all.filter((t) => t.elderId === elderId)),
    db
      .select()
      .from(healthRecords)
      .where(eq(healthRecords.elderId, elderId))
      .orderBy(desc(healthRecords.recordedAt))
      .limit(120),
    db
      .select()
      .from(medicationLogs)
      .where(
        and(
          eq(medicationLogs.elderId, elderId),
          gte(medicationLogs.scheduledFor, todayStart),
          lt(medicationLogs.scheduledFor, dayEnd),
        ),
      ),
    getAlerts().then((all) => all.filter((a) => a.elderId === elderId)),
  ]);

  return {
    elder: elder as Elder,
    meds,
    appts,
    tasks,
    records,
    todayDoses: buildTodayDoses(meds, logs),
    alerts: alertsForElder,
  };
}

export function vitalsSeries(records: { type: string; value: string; unit: string; recordedAt: Date }[]) {
  const pick = (type: string) =>
    records
      .filter((r) => r.type === type)
      .map((r) => ({ ...r, num: Number(r.value.split("/")[0]) }))
      .filter((r) => Number.isFinite(r.num))
      .sort((a, b) => a.recordedAt.getTime() - b.recordedAt.getTime());
  return {
    heartRate: pick("heart_rate"),
    glucose: pick("glucose"),
    weight: pick("weight"),
    oxygen: pick("oxygen"),
    systolic: records
      .filter((r) => r.type === "blood_pressure")
      .map((r) => ({ ...r, num: Number(r.value.split("/")[0]) }))
      .filter((r) => Number.isFinite(r.num))
      .sort((a, b) => a.recordedAt.getTime() - b.recordedAt.getTime()),
    diastolic: records
      .filter((r) => r.type === "blood_pressure")
      .map((r) => ({ ...r, num: Number(r.value.split("/")[1]) }))
      .filter((r) => Number.isFinite(r.num))
      .sort((a, b) => a.recordedAt.getTime() - b.recordedAt.getTime()),
  };
}

/* ------------------------------- dashboard --------------------------------- */

export async function getDashboardData() {
  const [
    elderList,
    appts,
    medRows,
    todayLogs,
    tasks,
    alerts,
    feed,
    caregiverList,
    requests,
  ] = await Promise.all([
    getElders(),
    getAppointments(),
    getMedications(),
    getTodayLogs(),
    getCareTasks(),
    getAlerts(),
    getRecentActivity(10),
    getCaregivers(),
    getServiceRequests(),
  ]);

  const medsWithElder = medRows.map((r) => ({
    ...r.medication,
    elderName: r.elderName,
    elderAccent: r.elderAccent,
  }));

  const todayDoses = buildTodayDoses(medsWithElder, todayLogs);
  const now = new Date();
  const dayEnd = endOfDay();

  return {
    elders: elderList,
    todayDoses,
    upcomingAppointments: appts.filter(
      (a) => a.status === "scheduled" && a.scheduledAt >= now,
    ),
    todaysAppointments: appts.filter(
      (a) => a.scheduledAt >= startOfDay() && a.scheduledAt <= dayEnd,
    ),
    todaysTasks: tasks.filter(
      (t) => t.scheduledFor >= startOfDay() && t.scheduledFor <= dayEnd,
    ),
    activeAlerts: alerts.filter((a) => a.status !== "resolved"),
    feed,
    caregivers: caregiverList,
    openRequests: requests.filter(
      (r) => r.status === "open" || r.status === "assigned" || r.status === "in_progress",
    ),
  };
}

/* ---------------------------------- admin ---------------------------------- */

export async function getAdminData() {
  const [counts] = await Promise.all([
    Promise.all([
      db.select({ n: count() }).from(elders),
      db.select({ n: count() }).from(caregivers),
      db.select({ n: count() }).from(doctors),
      db
        .select({ n: count() })
        .from(appointments)
        .where(eq(appointments.status, "scheduled")),
      db.select({ n: count() }).from(medications).where(eq(medications.active, true)),
      db
        .select({ n: count() })
        .from(serviceRequests)
        .where(ne(serviceRequests.status, "completed")),
      db
        .select({ n: count() })
        .from(emergencyAlerts)
        .where(ne(emergencyAlerts.status, "resolved")),
      db
        .select({ n: count() })
        .from(careTasks)
        .where(inArray(careTasks.status, ["pending", "in_progress"])),
    ]),
  ]);

  const [e, c, d, a, m, r, al, t] = counts;
  return {
    elders: e[0].n,
    caregivers: c[0].n,
    doctors: d[0].n,
    scheduledAppointments: a[0].n,
    activeMedications: m[0].n,
    openRequests: r[0].n,
    activeAlerts: al[0].n,
    openTasks: t[0].n,
  };
}
