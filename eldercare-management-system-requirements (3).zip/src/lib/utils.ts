import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Initials for avatar monograms, "Margaret Ellis" -> "ME" */
export function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("");
}

export type AccentKey =
  | "pine"
  | "honey"
  | "clay"
  | "sky"
  | "rose"
  | "plum";

export const ACCENTS: Record<
  string,
  { bg: string; text: string; ring: string; soft: string; dot: string }
> = {
  pine: {
    bg: "bg-pine-700",
    text: "text-pine-700",
    ring: "ring-pine-200",
    soft: "bg-pine-50",
    dot: "bg-pine-500",
  },
  honey: {
    bg: "bg-honey-500",
    text: "text-honey-600",
    ring: "ring-honey-200",
    soft: "bg-honey-50",
    dot: "bg-honey-400",
  },
  clay: {
    bg: "bg-clay-500",
    text: "text-clay-500",
    ring: "ring-clay-100",
    soft: "bg-clay-50",
    dot: "bg-clay-500",
  },
  sky: {
    bg: "bg-sky-500",
    text: "text-sky-700",
    ring: "ring-sky-100",
    soft: "bg-sky-100/50",
    dot: "bg-sky-500",
  },
  rose: {
    bg: "bg-rose-500",
    text: "text-rose-600",
    ring: "ring-rose-100",
    soft: "bg-rose-50",
    dot: "bg-rose-400",
  },
  plum: {
    bg: "bg-purple-600",
    text: "text-purple-700",
    ring: "ring-purple-200",
    soft: "bg-purple-50",
    dot: "bg-purple-400",
  },
};

export function accent(key: string | null | undefined) {
  return ACCENTS[key ?? "pine"] ?? ACCENTS.pine;
}

/** "08:00" -> today at 08:00 local */
export function atToday(time: string, base: Date = new Date()): Date {
  const [h, m] = time.split(":").map(Number);
  const d = new Date(base);
  d.setHours(h || 0, m || 0, 0, 0);
  return d;
}

export function timeOfDayLabel(time: string) {
  const h = Number(time.split(":")[0]);
  if (h < 11) return "Morning";
  if (h < 14) return "Midday";
  if (h < 18) return "Afternoon";
  return "Evening";
}
