import { getDashboardData } from "@/lib/queries";
import { OverviewClient } from "@/components/dashboard/overview-client";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const data = await getDashboardData();
  return (
    <OverviewClient
      data={{
        elders: data.elders,
        todayDoses: data.todayDoses,
        upcomingAppointments: data.upcomingAppointments,
        todaysTasks: data.todaysTasks,
        activeAlerts: data.activeAlerts,
        feed: data.feed,
        caregivers: data.caregivers,
        openRequestsCount: data.openRequests.length,
      }}
    />
  );
}
