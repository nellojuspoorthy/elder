import { format } from "date-fns";
import {
  BadgeCheck,
  CalendarClock,
  HandHeart,
  Phone,
  Star,
} from "lucide-react";
import { Avatar, Badge, Card, SectionTitle } from "@/components/ui";
import { RequestCareDialog } from "@/components/dashboard/caregivers-client";
import {
  AssignCaregiver,
  CaregiverStatusButton,
  RequestStatusButtons,
} from "@/components/dashboard/widgets";
import { getCaregivers, getElders, getServiceRequests } from "@/lib/queries";
import { setCaregiverStatus } from "@/lib/actions";
import { cn } from "@/lib/utils";

export const metadata = { title: "Caregivers" };
export const dynamic = "force-dynamic";

const STATUS_META: Record<string, { label: string; tone: "green" | "honey" | "neutral" }> = {
  available: { label: "Available", tone: "green" },
  on_shift: { label: "On shift", tone: "honey" },
  off_duty: { label: "Off duty", tone: "neutral" },
};

const REQUEST_TONE: Record<string, "honey" | "sky" | "pine" | "green" | "neutral"> = {
  open: "honey",
  assigned: "sky",
  in_progress: "pine",
  completed: "green",
  cancelled: "neutral",
};

export default async function CaregiversPage() {
  const [caregiverList, elderList, requests] = await Promise.all([
    getCaregivers(),
    getElders(),
    getServiceRequests(),
  ]);

  const active = requests.filter((r) => r.status !== "completed" && r.status !== "cancelled");
  const done = requests.filter((r) => r.status === "completed" || r.status === "cancelled");
  const elders = elderList.map((e) => ({ id: e.id, name: e.name }));

  return (
    <div className="mx-auto max-w-6xl space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-semibold text-ink-soft">
            {caregiverList.filter((c) => c.status === "available").length} of{" "}
            {caregiverList.length} caregivers available now
          </p>
          <h2 className="mt-1 font-display text-3xl font-semibold tracking-tight text-pine-900 sm:text-4xl">
            Caregivers &amp; services
          </h2>
        </div>
        <RequestCareDialog elders={elders} />
      </div>

      {/* ------------------------- service requests ------------------------- */}
      <section>
        <div className="mb-4 flex items-center justify-between">
          <SectionTitle kicker="Pipeline" title="Service requests" />
          <Badge tone="honey" dot>
            {active.length} open
          </Badge>
        </div>
        {active.length === 0 ? (
          <p className="rounded-2xl bg-pine-50 px-5 py-6 text-center text-sm font-semibold text-pine-700">
            <HandHeart className="mr-2 inline h-4 w-4" />
            No open requests — request care whenever you need a hand.
          </p>
        ) : (
          <div className="grid gap-4 lg:grid-cols-2">
            {active.map((r) => (
              <Card key={r.id} className="p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3.5">
                    <Avatar name={r.elderName} accentKey={r.elderAccent} />
                    <div>
                      <h4 className="font-display text-lg leading-tight font-semibold text-pine-900">
                        {r.serviceType}
                      </h4>
                      <p className="text-xs font-semibold text-ink-soft">for {r.elderName}</p>
                    </div>
                  </div>
                  <Badge tone={REQUEST_TONE[r.status]} dot>
                    {r.status.replace("_", " ")}
                  </Badge>
                </div>
                {r.details && (
                  <p className="mt-3 rounded-2xl bg-paper px-4 py-3 text-sm leading-relaxed text-ink-soft">
                    “{r.details}”
                  </p>
                )}
                <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-ink-soft">
                  {r.preferredAt && (
                    <span className="inline-flex items-center gap-1.5 font-semibold">
                      <CalendarClock className="h-3.5 w-3.5" />
                      {format(new Date(r.preferredAt), "EEE, MMM d · h:mm a")}
                    </span>
                  )}
                  <span>Requested {format(new Date(r.createdAt), "MMM d")}</span>
                </div>
                <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-line/60 pt-3.5">
                  <AssignCaregiver
                    requestId={r.id}
                    currentId={r.caregiverId}
                    caregivers={caregiverList.map((c) => ({ id: c.id, name: c.name }))}
                  />
                  <RequestStatusButtons requestId={r.id} status={r.status} />
                </div>
              </Card>
            ))}
          </div>
        )}
        {done.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2">
            {done.slice(0, 6).map((r) => (
              <Badge key={r.id} tone="neutral">
                {r.serviceType} · {r.elderName.split(" ")[0]} · {r.status}
              </Badge>
            ))}
          </div>
        )}
      </section>

      {/* ---------------------------- directory ----------------------------- */}
      <section>
        <div className="mb-4">
          <SectionTitle kicker="Directory" title="Your caregiving team" />
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {caregiverList.map((c) => {
            const meta = STATUS_META[c.status] ?? STATUS_META.available;
            return (
              <Card key={c.id} className="group flex flex-col p-6 transition-all hover:-translate-y-1 hover:shadow-lift">
                <div className="flex items-start justify-between">
                  <Avatar name={c.name} accentKey={c.status === "available" ? "pine" : c.status === "on_shift" ? "honey" : "plum"} size="lg" />
                  <Badge tone={meta.tone} dot>
                    {meta.label}
                  </Badge>
                </div>
                <h3 className="mt-4 flex items-center gap-1.5 font-display text-xl font-semibold text-pine-900">
                  {c.name}
                  {c.verified && <BadgeCheck className="h-4.5 w-4.5 text-sky-500" />}
                </h3>
                <p className="text-sm font-semibold text-pine-600">{c.specialty}</p>
                <div className="mt-2 flex items-center gap-3 text-xs font-bold text-ink-soft">
                  <span className="inline-flex items-center gap-1 rounded-full bg-honey-100 px-2.5 py-1 text-honey-700">
                    <Star className="h-3 w-3 fill-current" />
                    {c.rating}
                  </span>
                  <span>{c.yearsExperience} yrs experience</span>
                </div>
                {c.bio && (
                  <p className="mt-3 line-clamp-3 text-sm leading-relaxed text-ink-soft">{c.bio}</p>
                )}
                <div className="mt-auto space-y-3 pt-5">
                  <CaregiverStatusButton
                    caregiverId={c.id}
                    status={c.status}
                    onChange={setCaregiverStatus}
                  />
                  {c.phone && (
                    <p className="flex items-center gap-2 text-xs font-semibold text-ink-soft">
                      <Phone className="h-3.5 w-3.5" />
                      {c.phone}
                    </p>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      </section>
    </div>
  );
}
