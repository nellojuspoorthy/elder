import { format, isToday, isTomorrow } from "date-fns";
import { CalendarCheck2, Clock3, MapPin, Stethoscope } from "lucide-react";
import { Avatar, Badge, Card } from "@/components/ui";
import { AppointmentControls } from "@/components/dashboard/widgets";
import { BookAppointmentDialog } from "@/components/dashboard/appointments-client";
import { getAppointments, getDoctors, getElders } from "@/lib/queries";
import { cn } from "@/lib/utils";

export const metadata = { title: "Appointments" };
export const dynamic = "force-dynamic";

function dayLabel(d: Date) {
  if (isToday(d)) return "Today";
  if (isTomorrow(d)) return "Tomorrow";
  return format(d, "EEEE");
}

export default async function AppointmentsPage() {
  const [appts, elderList, doctorList] = await Promise.all([
    getAppointments(),
    getElders(),
    getDoctors(),
  ]);

  const now = new Date();
  const upcoming = appts.filter((a) => a.status === "scheduled" && a.scheduledAt >= now);
  const history = appts
    .filter((a) => !(a.status === "scheduled" && a.scheduledAt >= now))
    .sort((a, b) => b.scheduledAt.getTime() - a.scheduledAt.getTime());

  // group upcoming by day
  const groups = new Map<string, typeof upcoming>();
  for (const a of upcoming) {
    const key = format(a.scheduledAt, "yyyy-MM-dd");
    groups.set(key, [...(groups.get(key) ?? []), a]);
  }

  return (
    <div className="mx-auto max-w-6xl space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-semibold text-ink-soft">
            {upcoming.length} upcoming visit{upcoming.length === 1 ? "" : "s"} in the circle
          </p>
          <h2 className="mt-1 font-display text-3xl font-semibold tracking-tight text-pine-900 sm:text-4xl">
            Doctor appointments
          </h2>
        </div>
        <BookAppointmentDialog
          elders={elderList.map((e) => ({ id: e.id, name: e.name }))}
          doctors={doctorList.map((d) => ({
            id: d.id,
            name: d.name,
            specialty: d.specialty,
            clinic: d.clinic,
          }))}
        />
      </div>

      {upcoming.length === 0 && (
        <Card className="flex flex-col items-center gap-3 p-12 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-full bg-sky-100 text-sky-700">
            <CalendarCheck2 className="h-7 w-7" />
          </span>
          <p className="font-display text-2xl font-semibold text-pine-900">Nothing scheduled yet</p>
          <p className="max-w-sm text-sm text-ink-soft">
            Book the first appointment and it will show up here for the whole care circle.
          </p>
        </Card>
      )}

      {[...groups.entries()].map(([day, list]) => (
        <section key={day}>
          <div className="mb-4 flex items-center gap-3">
            <h3 className="font-display text-xl font-semibold text-pine-900">
              {dayLabel(new Date(`${day}T12:00:00`))}
            </h3>
            <span className="text-sm font-semibold text-ink-faint">
              {format(new Date(`${day}T12:00:00`), "MMMM d")}
            </span>
            <div className="h-px flex-1 bg-line" />
            <Badge tone="sky">{list.length}</Badge>
          </div>
          <div className="grid gap-4 lg:grid-cols-2">
            {list.map((a) => (
              <Card key={a.id} className="p-5 transition-all hover:shadow-lift">
                <div className="flex items-start gap-4">
                  <div className="flex h-16 w-16 shrink-0 flex-col items-center justify-center rounded-2xl bg-sky-100 font-bold text-sky-700">
                    <span className="text-xl leading-none">{format(a.scheduledAt, "h:mm")}</span>
                    <span className="text-[10px] tracking-wide uppercase">
                      {format(a.scheduledAt, "a")}
                    </span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="font-display text-lg font-semibold text-pine-900">
                        {a.doctorName}
                      </h4>
                      <Badge tone="pine">{a.type}</Badge>
                    </div>
                    <p className="mt-0.5 flex items-center gap-1.5 text-sm font-semibold text-sky-700">
                      <Stethoscope className="h-3.5 w-3.5" />
                      {a.doctorSpecialty} · {a.clinic}
                    </p>
                    <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-ink-soft">
                      <span className="inline-flex items-center gap-1.5 font-semibold text-pine-700">
                        <Avatar name={a.elderName} accentKey={a.elderAccent} size="sm" className="h-5 w-5 text-[8px] ring-2" />
                        {a.elderName}
                      </span>
                      {a.location && (
                        <span className="inline-flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {a.location}
                        </span>
                      )}
                      {a.reason && (
                        <span className="inline-flex items-center gap-1">
                          <Clock3 className="h-3 w-3" />
                          {a.reason}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="mt-4 flex justify-end border-t border-line/60 pt-3">
                  <AppointmentControls appointmentId={a.id} status={a.status} />
                </div>
              </Card>
            ))}
          </div>
        </section>
      ))}

      {history.length > 0 && (
        <section>
          <div className="mb-4 flex items-center gap-3">
            <h3 className="font-display text-xl font-semibold text-pine-900">History</h3>
            <div className="h-px flex-1 bg-line" />
          </div>
          <Card className="divide-y divide-line/60">
            {history.map((a) => (
              <div key={a.id} className="flex items-center gap-4 p-4">
                <Avatar name={a.elderName} accentKey={a.elderAccent} size="sm" />
                <div className="min-w-0 flex-1">
                  <p className={cn("truncate text-sm font-bold text-pine-900", a.status === "cancelled" && "line-through opacity-60")}>
                    {a.doctorName}
                    <span className="ml-2 font-semibold text-ink-soft">{a.type}</span>
                  </p>
                  <p className="text-xs text-ink-soft">
                    for {a.elderName} · {format(a.scheduledAt, "MMM d, yyyy · h:mm a")}
                  </p>
                </div>
                <Badge tone={a.status === "completed" ? "green" : "neutral"}>{a.status}</Badge>
              </div>
            ))}
          </Card>
        </section>
      )}
    </div>
  );
}
