import Link from "next/link";
import {
  ArrowUpRight,
  Droplets,
  HeartPulse,
  MapPin,
  PhoneCall,
  PersonStanding,
} from "lucide-react";
import { Avatar, Badge, Card } from "@/components/ui";
import { AddElderDialog } from "@/components/dashboard/elders-client";
import { getElders } from "@/lib/queries";

export const metadata = { title: "Care profiles" };
export const dynamic = "force-dynamic";

export default async function EldersPage() {
  const elders = await getElders();

  return (
    <div className="mx-auto max-w-6xl space-y-7">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-semibold text-ink-soft">
            {elders.length} {elders.length === 1 ? "person" : "people"} in the care circle
          </p>
          <h2 className="mt-1 font-display text-3xl font-semibold tracking-tight text-pine-900 sm:text-4xl">
            Care profiles
          </h2>
        </div>
        <AddElderDialog />
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        {elders.map((e) => {
          const conditions = (e.conditions ?? "")
            .split(",")
            .map((c) => c.trim())
            .filter(Boolean);
          return (
            <Link key={e.id} href={`/dashboard/elders/${e.id}`} className="group block">
              <Card className="h-full p-6 transition-all duration-300 group-hover:-translate-y-1 group-hover:shadow-lift">
                <div className="flex items-start gap-4">
                  <Avatar name={e.name} accentKey={e.accent} size="xl" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="truncate font-display text-2xl font-semibold text-pine-900">
                        {e.name}
                      </h3>
                      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-paper-deep text-ink-soft transition-all group-hover:bg-pine-700 group-hover:text-white">
                        <ArrowUpRight className="h-4.5 w-4.5" />
                      </span>
                    </div>
                    <p className="mt-0.5 text-sm font-semibold text-ink-soft">
                      {e.age} years · <span className="capitalize">{e.gender}</span>
                    </p>
                    <div className="mt-2.5 flex flex-wrap gap-1.5">
                      {conditions.length > 0 ? (
                        conditions.slice(0, 3).map((c) => (
                          <Badge key={c} tone="pine">
                            {c}
                          </Badge>
                        ))
                      ) : (
                        <Badge tone="green">No chronic conditions</Badge>
                      )}
                    </div>
                  </div>
                </div>

                <div className="mt-5 grid grid-cols-2 gap-3 border-t border-line/60 pt-4 text-xs sm:grid-cols-4">
                  <div>
                    <p className="flex items-center gap-1 font-bold tracking-wide text-ink-faint uppercase">
                      <Droplets className="h-3 w-3" /> Blood
                    </p>
                    <p className="mt-1 font-bold text-pine-900">{e.bloodType || "—"}</p>
                  </div>
                  <div>
                    <p className="flex items-center gap-1 font-bold tracking-wide text-ink-faint uppercase">
                      <PersonStanding className="h-3 w-3" /> Mobility
                    </p>
                    <p className="mt-1 font-bold text-pine-900 capitalize">{e.mobility}</p>
                  </div>
                  <div>
                    <p className="flex items-center gap-1 font-bold tracking-wide text-ink-faint uppercase">
                      <HeartPulse className="h-3 w-3" /> Allergies
                    </p>
                    <p className="mt-1 truncate font-bold text-pine-900">{e.allergies || "None"}</p>
                  </div>
                  <div>
                    <p className="flex items-center gap-1 font-bold tracking-wide text-ink-faint uppercase">
                      <PhoneCall className="h-3 w-3" /> Emergency
                    </p>
                    <p className="mt-1 truncate font-bold text-pine-900">
                      {e.emergencyContactName?.split(" ")[0] || "—"}
                    </p>
                  </div>
                </div>

                {e.address && (
                  <p className="mt-4 flex items-center gap-1.5 text-xs text-ink-soft">
                    <MapPin className="h-3.5 w-3.5 shrink-0" />
                    <span className="truncate">{e.address}</span>
                  </p>
                )}
              </Card>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
