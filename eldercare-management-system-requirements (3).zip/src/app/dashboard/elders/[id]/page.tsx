import Link from "next/link";
import { notFound } from "next/navigation";
import type { ReactNode } from "react";
import { format } from "date-fns";
import {
  ArrowLeft,
  CalendarCheck2,
  ClipboardList,
  Droplets,
  HeartPulse,
  PhoneCall,
  Pill,
  Scale,
  Thermometer,
  Wind,
} from "lucide-react";
import { Avatar, Badge, Card, SectionTitle } from "@/components/ui";
import { AddVitalDialog } from "@/components/dashboard/elders-client";
import { AppointmentCards, DoseList } from "@/components/dashboard/overview-client";
import { TaskStatusControl } from "@/components/dashboard/widgets";
import { Sparkline } from "@/components/dashboard/sparkline";
import { getElderDetail, vitalsSeries } from "@/lib/queries";

export const dynamic = "force-dynamic";

const VITAL_META: Record<string, { label: string; icon: ReactNode; stroke: string; fill: string }> = {
  blood_pressure: {
    label: "Blood pressure",
    icon: <HeartPulse className="h-4.5 w-4.5" />,
    stroke: "#c4553f",
    fill: "#f6ddd7",
  },
  heart_rate: {
    label: "Heart rate",
    icon: <HeartPulse className="h-4.5 w-4.5" />,
    stroke: "#2c6651",
    fill: "#dbe9e1",
  },
  glucose: {
    label: "Glucose",
    icon: <Droplets className="h-4.5 w-4.5" />,
    stroke: "#c07817",
    fill: "#faeccb",
  },
  weight: {
    label: "Weight",
    icon: <Scale className="h-4.5 w-4.5" />,
    stroke: "#4a7fb5",
    fill: "#dfeaf4",
  },
  oxygen: {
    label: "Oxygen",
    icon: <Wind className="h-4.5 w-4.5" />,
    stroke: "#4a7fb5",
    fill: "#dfeaf4",
  },
  temperature: {
    label: "Temperature",
    icon: <Thermometer className="h-4.5 w-4.5" />,
    stroke: "#c4553f",
    fill: "#f6ddd7",
  },
};

export default async function ElderDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const detail = await getElderDetail(id);
  if (!detail) notFound();

  const { elder, meds, appts, tasks, records, todayDoses, alerts } = detail;
  const series = vitalsSeries(records);

  const conditions = (elder.conditions ?? "").split(",").map((c) => c.trim()).filter(Boolean);
  const upcoming = appts.filter((a) => a.status === "scheduled" && a.scheduledAt >= new Date());
  const openTasks = tasks.filter((t) => t.status === "pending" || t.status === "in_progress").slice(0, 6);

  const vitalCards: { type: string; latest: string; unit: string; points: number[] }[] = [
    {
      type: "blood_pressure",
      latest: series.systolic.length
        ? `${series.systolic.at(-1)!.value.split("/")[0]}/${records.find((r) => r.type === "blood_pressure")?.value.split("/")[1] ?? ""}`
        : "—",
      unit: "mmHg",
      points: series.systolic.map((s) => s.num),
    },
    {
      type: "heart_rate",
      latest: series.heartRate.length ? series.heartRate.at(-1)!.value : "—",
      unit: "bpm",
      points: series.heartRate.map((s) => s.num),
    },
    {
      type: "glucose",
      latest: series.glucose.length ? series.glucose.at(-1)!.value : "—",
      unit: "mg/dL",
      points: series.glucose.map((s) => s.num),
    },
    {
      type: "weight",
      latest: series.weight.length ? series.weight.at(-1)!.value : "—",
      unit: "kg",
      points: series.weight.map((s) => s.num),
    },
  ];

  return (
    <div className="mx-auto max-w-6xl space-y-7">
      <Link
        href="/dashboard/elders"
        className="inline-flex items-center gap-2 text-sm font-bold text-pine-700 transition-colors hover:text-pine-900"
      >
        <ArrowLeft className="h-4 w-4" />
        All care profiles
      </Link>

      {/* ------------------------------- header ------------------------------ */}
      <Card className="relative overflow-hidden p-6 sm:p-8">
        <div aria-hidden className="absolute -top-20 -right-20 h-56 w-56 rounded-full bg-pine-100/70 blur-3xl" />
        <div className="relative flex flex-col gap-6 sm:flex-row sm:items-start">
          <Avatar name={elder.name} accentKey={elder.accent} size="xl" className="h-24 w-24 text-3xl" />
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-3">
              <h2 className="font-display text-4xl font-semibold tracking-tight text-pine-900">
                {elder.name}
              </h2>
              {alerts.length > 0 && <Badge tone="clay" dot>Alert history</Badge>}
            </div>
            <p className="mt-1 text-[15px] font-semibold text-ink-soft">
              {elder.age} years · <span className="capitalize">{elder.gender}</span>
              {elder.address ? ` · ${elder.address}` : ""}
            </p>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {conditions.map((c) => (
                <Badge key={c} tone="pine">{c}</Badge>
              ))}
              {conditions.length === 0 && <Badge tone="green">No chronic conditions</Badge>}
              {elder.allergies && <Badge tone="clay">Allergic: {elder.allergies}</Badge>}
            </div>
          </div>
          <div className="grid shrink-0 grid-cols-3 gap-3 sm:grid-cols-1">
            <div className="rounded-2xl bg-paper px-4 py-3">
              <p className="flex items-center gap-1 text-[10px] font-bold tracking-wider text-ink-faint uppercase">
                <Droplets className="h-3 w-3" /> Blood
              </p>
              <p className="font-display text-lg font-semibold text-pine-900">{elder.bloodType || "—"}</p>
            </div>
            <div className="rounded-2xl bg-paper px-4 py-3">
              <p className="text-[10px] font-bold tracking-wider text-ink-faint uppercase">Mobility</p>
              <p className="font-display text-lg font-semibold text-pine-900 capitalize">{elder.mobility}</p>
            </div>
            <div className="rounded-2xl bg-clay-50 px-4 py-3">
              <p className="flex items-center gap-1 text-[10px] font-bold tracking-wider text-clay-500 uppercase">
                <PhoneCall className="h-3 w-3" /> SOS
              </p>
              <p className="font-display text-lg leading-tight font-semibold text-pine-900">
                {elder.emergencyContactName?.split(" ")[0] ?? "—"}
              </p>
            </div>
          </div>
        </div>
        {elder.notes && (
          <p className="relative mt-5 rounded-2xl bg-paper px-5 py-4 text-sm leading-relaxed text-ink-soft">
            <span className="font-bold text-pine-800">Care notes: </span>
            {elder.notes}
          </p>
        )}
      </Card>

      {/* -------------------------------- vitals ------------------------------ */}
      <section>
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <SectionTitle kicker="Health record" title="Vitals & trends" />
          <AddVitalDialog elderId={elder.id} elderName={elder.name} />
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {vitalCards.map((v) => {
            const meta = VITAL_META[v.type];
            return (
              <Card key={v.type} className="p-5">
                <div className="flex items-center justify-between">
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl" style={{ background: meta.fill, color: meta.stroke }}>
                    {meta.icon}
                  </span>
                  <span className="text-[10px] font-bold tracking-wider text-ink-faint uppercase">
                    Last {series.systolic.length || series.heartRate.length ? format(records[0]?.recordedAt ?? new Date(), "MMM d") : ""}
                  </span>
                </div>
                <p className="mt-3 font-display text-3xl font-semibold text-pine-900">
                  {v.latest}
                  <span className="ml-1.5 text-sm font-bold text-ink-faint">{v.unit}</span>
                </p>
                <p className="text-xs font-bold text-ink-soft">{meta.label}</p>
                <div className="mt-3">
                  <Sparkline points={v.points} width={220} height={52} stroke={meta.stroke} fill={meta.fill} className="w-full" />
                </div>
              </Card>
            );
          })}
        </div>
      </section>

      {/* --------------------- meds + appointments + tasks -------------------- */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="p-5 sm:p-6">
          <div className="mb-4 flex items-center justify-between">
            <SectionTitle kicker="Today" title="Doses" />
            <Badge tone="honey">
              <Pill className="h-3 w-3" />
              {meds.filter((m) => m.active).length} active
            </Badge>
          </div>
          <DoseList doses={todayDoses} showElder={false} />
        </Card>

        <div className="space-y-6">
          <Card className="p-5 sm:p-6">
            <div className="mb-4 flex items-center justify-between">
              <SectionTitle kicker="Coming up" title="Appointments" />
              <Badge tone="sky">
                <CalendarCheck2 className="h-3 w-3" />
                {upcoming.length}
              </Badge>
            </div>
            <AppointmentCards appts={upcoming} limit={3} />
          </Card>

          <Card className="p-5 sm:p-6">
            <div className="mb-4 flex items-center justify-between">
              <SectionTitle kicker="Open" title="Care tasks" />
              <Badge tone="pine">
                <ClipboardList className="h-3 w-3" />
                {openTasks.length}
              </Badge>
            </div>
            {openTasks.length === 0 ? (
              <p className="rounded-2xl bg-pine-50 px-5 py-6 text-center text-sm font-semibold text-pine-700">
                No open tasks for {elder.name.split(" ")[0]}.
              </p>
            ) : (
              <ul className="space-y-3">
                {openTasks.map((t) => (
                  <li key={t.id} className="flex items-center gap-3 rounded-2xl border-2 border-line/60 bg-white p-3.5">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold text-pine-900">{t.title}</p>
                      <p className="text-xs text-ink-soft">
                        {format(new Date(t.scheduledFor), "EEE · h:mm a")}
                        {t.caregiverName ? ` · ${t.caregiverName}` : " · Unassigned"}
                      </p>
                    </div>
                    <TaskStatusControl taskId={t.id} status={t.status} compact />
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>

      {/* ----------------------------- readings log --------------------------- */}
      {records.length > 0 && (
        <Card className="p-5 sm:p-6">
          <div className="mb-4">
            <SectionTitle kicker="History" title="Recent readings" />
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[620px] text-left text-sm">
              <thead>
                <tr className="border-b border-line text-[11px] font-bold tracking-wider text-ink-faint uppercase">
                  <th className="pb-3 pr-4">Reading</th>
                  <th className="pb-3 pr-4">Value</th>
                  <th className="pb-3 pr-4">Notes</th>
                  <th className="pb-3">Recorded</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line/60">
                {records.slice(0, 10).map((r) => {
                  const meta = VITAL_META[r.type] ?? VITAL_META.heart_rate;
                  return (
                    <tr key={r.id}>
                      <td className="py-3 pr-4">
                        <span
                          className="inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-bold"
                          style={{ background: meta.fill, color: meta.stroke }}
                        >
                          {meta.icon}
                          {meta.label}
                        </span>
                      </td>
                      <td className="py-3 pr-4 font-display text-lg font-semibold text-pine-900">
                        {r.value}
                        <span className="ml-1 text-xs font-bold text-ink-faint">{r.unit}</span>
                      </td>
                      <td className="max-w-56 truncate py-3 pr-4 text-ink-soft">{r.notes || "—"}</td>
                      <td className="py-3 text-ink-soft">{format(r.recordedAt, "MMM d · h:mm a")}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
