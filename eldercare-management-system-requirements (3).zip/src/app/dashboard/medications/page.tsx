import { SectionTitle } from "@/components/ui";
import { DoseList } from "@/components/dashboard/overview-client";
import {
  MedicationCard,
  MedicationsHeader,
} from "@/components/dashboard/medications-client";
import { buildTodayDoses, getElders, getMedications, getTodayLogs } from "@/lib/queries";

export const metadata = { title: "Medications" };
export const dynamic = "force-dynamic";

export default async function MedicationsPage() {
  const [elderList, medRows, logs] = await Promise.all([
    getElders(),
    getMedications(),
    getTodayLogs(),
  ]);

  const meds = medRows.map((r) => ({
    ...r.medication,
    elderName: r.elderName,
    elderAccent: r.elderAccent,
  }));
  const todayDoses = buildTodayDoses(meds, logs);
  const taken = todayDoses.filter((d) => d.state === "taken").length;

  return (
    <div className="mx-auto max-w-6xl space-y-7">
      <MedicationsHeader
        elders={elderList.map((e) => ({ id: e.id, name: e.name }))}
        activeCount={meds.filter((m) => m.active).length}
      />

      <div className="grid gap-6 lg:grid-cols-[1fr_1.15fr]">
        <section className="rounded-3xl border border-line/70 bg-card p-5 shadow-soft sm:p-6">
          <div className="mb-4 flex items-center justify-between">
            <SectionTitle kicker="Today" title="Dose schedule" />
            <span className="rounded-full bg-pine-100 px-3 py-1 text-xs font-bold text-pine-700">
              {taken}/{todayDoses.length} taken
            </span>
          </div>
          <DoseList doses={todayDoses} />
        </section>

        <section>
          <div className="mb-4">
            <SectionTitle kicker="Circle-wide" title="All medications" />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {meds.map((m) => (
              <MedicationCard key={m.id} med={m} />
            ))}
          </div>
          {meds.length === 0 && (
            <p className="rounded-2xl bg-pine-50 px-5 py-6 text-center text-sm font-semibold text-pine-700">
              No medications yet — add the first one above.
            </p>
          )}
        </section>
      </div>
    </div>
  );
}
