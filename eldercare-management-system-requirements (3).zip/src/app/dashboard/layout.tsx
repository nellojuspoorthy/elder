import type { ReactNode } from "react";
import { DashboardShell } from "@/components/dashboard/shell";
import { getElders, getAlerts } from "@/lib/queries";

export const metadata = { title: "Dashboard" };

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const [elderList, alerts] = await Promise.all([getElders(), getAlerts()]);
  const elders = elderList.map((e) => ({ id: e.id, name: e.name, accent: e.accent }));
  const activeAlerts = alerts.filter((a) => a.status !== "resolved").length;

  return (
    <DashboardShell elders={elders} activeAlerts={activeAlerts}>
      {children}
    </DashboardShell>
  );
}
