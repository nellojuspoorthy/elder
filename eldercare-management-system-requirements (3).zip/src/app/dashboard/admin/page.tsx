import Link from "next/link";
import { format } from "date-fns";
import {
  BadgeCheck,
  CalendarCheck2,
  ClipboardList,
  Database,
  HandHeart,
  Pill,
  Server,
  ShieldCheck,
  Siren,
  Stethoscope,
  Users,
} from "lucide-react";
import { Avatar, Badge, Card, SectionTitle } from "@/components/ui";
import { AlertActions, AssignCaregiver, RequestStatusButtons } from "@/components/dashboard/widgets";
import { AddCaregiverDialog, AddDoctorDialog } from "@/components/dashboard/admin-client";
import {
  getAdminData,
  getAlerts,
  getCaregivers,
  getDoctors,
  getProfiles,
  getServiceRequests,
} from "@/lib/queries";
import { cn } from "@/lib/utils";

export const metadata = { title: "Administration" };
export const dynamic = "force-dynamic";

const ROLE_TONE: Record<string, "pine" | "honey" | "sky" | "clay"> = {
  elder: "pine",
  family: "sky",
  caregiver: "honey",
  admin: "clay",
};

export default async function AdminPage() {
  const [stats, requests, alerts, caregivers, doctors, profiles] = await Promise.all([
    getAdminData(),
    getServiceRequests(),
    getAlerts(),
    getCaregivers(),
    getDoctors(),
    getProfiles(),
  ]);

  const openRequests = requests.filter((r) => r.status !== "completed" && r.status !== "cancelled");
  const activeAlerts = alerts.filter((a) => a.status !== "resolved");

  const statCards = [
    { label: "Care profiles", value: stats.elders, icon: <Users className="h-5 w-5" />, tone: "bg-pine-100 text-pine-700" },
    { label: "Caregivers", value: stats.caregivers, icon: <Stethoscope className="h-5 w-5" />, tone: "bg-honey-100 text-honey-600" },
    { label: "Doctors", value: stats.doctors, icon: <BadgeCheck className="h-5 w-5" />, tone: "bg-sky-100 text-sky-700" },
    { label: "Scheduled visits", value: stats.scheduledAppointments, icon: <CalendarCheck2 className="h-5 w-5" />, tone: "bg-sky-100 text-sky-700" },
    { label: "Active meds", value: stats.activeMedications, icon: <Pill className="h-5 w-5" />, tone: "bg-honey-100 text-honey-600" },
    { label: "Open requests", value: stats.openRequests, icon: <HandHeart className="h-5 w-5" />, tone: "bg-emerald-100 text-emerald-700" },
    { label: "Active alerts", value: stats.activeAlerts, icon: <Siren className="h-5 w-5" />, tone: stats.activeAlerts > 0 ? "bg-clay-100 text-clay-500" : "bg-emerald-100 text-emerald-700" },
    { label: "Open tasks", value: stats.openTasks, icon: <ClipboardList className="h-5 w-5" />, tone: "bg-pine-100 text-pine-700" },
  ];

  return (
    <div className="mx-auto max-w-6xl space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="flex items-center gap-2 text-sm font-semibold text-ink-soft">
            <ShieldCheck className="h-4 w-4 text-pine-600" />
            Centralized operational control
          </p>
          <h2 className="mt-1 font-display text-3xl font-semibold tracking-tight text-pine-900 sm:text-4xl">
            Administration
          </h2>
        </div>
        <div className="flex gap-3">
          <AddDoctorDialog />
          <AddCaregiverDialog />
        </div>
      </div>

      {/* -------------------------------- stats ------------------------------- */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {statCards.map((s) => (
          <Card key={s.label} className="flex items-center gap-4 p-5">
            <span className={cn("flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl", s.tone)}>
              {s.icon}
            </span>
            <div>
              <p className="font-display text-2xl leading-none font-semibold text-pine-900">{s.value}</p>
              <p className="mt-1 text-xs font-bold tracking-wide text-ink-soft uppercase">{s.label}</p>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <div className="space-y-6">
          {/* ------------------------- alert operations ------------------------ */}
          <Card className="p-5 sm:p-6">
            <div className="mb-4 flex items-center justify-between">
              <SectionTitle kicker="Safety" title="Alert operations" />
              <Badge tone={activeAlerts.length ? "clay" : "green"} dot>
                {activeAlerts.length ? `${activeAlerts.length} active` : "All resolved"}
              </Badge>
            </div>
            {alerts.length === 0 ? (
              <p className="rounded-2xl bg-emerald-50 px-5 py-6 text-center text-sm font-semibold text-emerald-700">
                No alerts on record — a quiet, safe day.
              </p>
            ) : (
              <ul className="space-y-3">
                {alerts.slice(0, 5).map((a) => (
                  <li
                    key={a.id}
                    className={cn(
                      "flex flex-col gap-3 rounded-2xl border-2 p-4 sm:flex-row sm:items-center",
                      a.status === "active"
                        ? "border-clay-200 bg-clay-50"
                        : a.status === "acknowledged"
                          ? "border-honey-200 bg-honey-50"
                          : "border-line/60 bg-white opacity-70",
                    )}
                  >
                    <div className="min-w-0 flex-1">
                      <p className="font-bold text-pine-900">
                        {a.elderName}
                        <span className="ml-2 text-xs font-semibold text-ink-soft capitalize">
                          {a.type} · {format(new Date(a.createdAt), "MMM d, h:mm a")}
                        </span>
                      </p>
                      <p className="mt-0.5 text-xs text-ink-soft">
                        Status: <span className="font-bold capitalize">{a.status}</span>
                        {a.emergencyContactName && ` · ${a.emergencyContactName} notified`}
                      </p>
                    </div>
                    <Badge tone={a.status === "resolved" ? "green" : a.status === "acknowledged" ? "honey" : "clay"} dot>
                      {a.status}
                    </Badge>
                    <AlertActions alertId={a.id} status={a.status} />
                  </li>
                ))}
              </ul>
            )}
          </Card>

          {/* --------------------------- request queue -------------------------- */}
          <Card className="p-5 sm:p-6">
            <div className="mb-4">
              <SectionTitle kicker="Dispatch" title="Service request queue" />
            </div>
            {openRequests.length === 0 ? (
              <p className="rounded-2xl bg-pine-50 px-5 py-6 text-center text-sm font-semibold text-pine-700">
                Queue is clear — every request has a caregiver.
              </p>
            ) : (
              <ul className="space-y-3">
                {openRequests.map((r) => (
                  <li key={r.id} className="rounded-2xl border-2 border-line/60 bg-white p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <Avatar name={r.elderName} accentKey={r.elderAccent} size="sm" />
                        <div>
                          <p className="text-sm font-bold text-pine-900">{r.serviceType}</p>
                          <p className="text-xs text-ink-soft">
                            for {r.elderName} ·{" "}
                            {r.preferredAt ? format(new Date(r.preferredAt), "EEE, MMM d · h:mm a") : "Flexible"}
                          </p>
                        </div>
                      </div>
                      <Badge tone={r.status === "open" ? "honey" : r.status === "in_progress" ? "pine" : "sky"} dot>
                        {r.status.replace("_", " ")}
                      </Badge>
                    </div>
                    <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-line/60 pt-3">
                      <AssignCaregiver
                        requestId={r.id}
                        currentId={r.caregiverId}
                        caregivers={caregivers.map((c) => ({ id: c.id, name: c.name }))}
                      />
                      <RequestStatusButtons requestId={r.id} status={r.status} />
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>

        <div className="space-y-6">
          {/* ------------------------------ users ------------------------------ */}
          <Card className="p-5 sm:p-6">
            <div className="mb-4">
              <SectionTitle kicker="Accounts" title="Circle members" />
            </div>
            <ul className="space-y-3">
              {profiles.map((p) => (
                <li key={p.id} className="flex items-center gap-3">
                  <Avatar name={p.name} accentKey={p.role === "admin" ? "clay" : p.role === "caregiver" ? "honey" : p.role === "family" ? "sky" : "pine"} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold text-pine-900">{p.name}</p>
                    <p className="truncate text-xs text-ink-soft">{p.email ?? p.phone ?? "—"}</p>
                  </div>
                  <Badge tone={ROLE_TONE[p.role]}>{p.role}</Badge>
                </li>
              ))}
            </ul>
          </Card>

          {/* ----------------------------- providers ---------------------------- */}
          <Card className="p-5 sm:p-6">
            <div className="mb-4">
              <SectionTitle kicker="Network" title="Medical providers" />
            </div>
            <ul className="space-y-3">
              {doctors.map((d) => (
                <li key={d.id} className="flex items-start gap-3">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-sky-100 text-sky-700">
                    <Stethoscope className="h-4 w-4" />
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold text-pine-900">Dr. {d.name}</p>
                    <p className="truncate text-xs text-ink-soft">
                      {d.specialty} · {d.clinic}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          </Card>

          {/* ------------------------------ system ----------------------------- */}
          <Card className="space-y-3 bg-pine-900 p-5 text-white sm:p-6">
            <SectionTitle kicker="Platform" title="System status" className="[&_h2]:text-white [&_p]:text-honey-300" />
            {[
              { icon: <Database className="h-4 w-4" />, label: "PostgreSQL database", ok: true },
              { icon: <Server className="h-4 w-4" />, label: "Application server", ok: true },
              { icon: <ShieldCheck className="h-4 w-4" />, label: "Row-level access rules", ok: true },
            ].map((s) => (
              <div key={s.label} className="flex items-center gap-3 text-sm">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/10 text-honey-300">
                  {s.icon}
                </span>
                <span className="flex-1 font-semibold text-pine-100/90">{s.label}</span>
                <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                  Operational
                </span>
              </div>
            ))}
            <p className="border-t border-white/10 pt-3 text-[11px] leading-relaxed text-pine-100/60">
              Demo build with seeded data. Switch roles from the sidebar to see each
              persona&apos;s view. <Link href="/" className="underline underline-offset-2">Back to site</Link>
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
