import type { ReactNode } from "react";
import { format, isToday, isTomorrow } from "date-fns";
import { CheckCircle2, CircleDashed, CirclePlay, ClipboardList } from "lucide-react";
import { Avatar, Badge, Card } from "@/components/ui";
import { TaskStatusControl } from "@/components/dashboard/widgets";
import { AddTaskDialog } from "@/components/dashboard/tasks-client";
import { getCaregivers, getCareTasks, getElders } from "@/lib/queries";
import { cn } from "@/lib/utils";

export const metadata = { title: "Care tasks" };
export const dynamic = "force-dynamic";

function whenLabel(d: Date) {
  if (isToday(d)) return "Today";
  if (isTomorrow(d)) return "Tomorrow";
  return format(d, "EEE, MMM d");
}

type TaskRow = Awaited<ReturnType<typeof getCareTasks>>[number];

function Column({
  title,
  icon,
  tasks,
  tone,
  emptyHint,
}: {
  title: string;
  icon: ReactNode;
  tasks: TaskRow[];
  tone: string;
  emptyHint: string;
}) {
  return (
    <section className="flex min-h-40 flex-col rounded-3xl border border-line/70 bg-paper-deep/50 p-4">
      <div className="mb-3 flex items-center gap-2 px-1">
        <span className={cn("flex h-8 w-8 items-center justify-center rounded-xl", tone)}>
          {icon}
        </span>
        <h3 className="font-display text-lg font-semibold text-pine-900">{title}</h3>
        <Badge tone="neutral" className="ml-auto">
          {tasks.length}
        </Badge>
      </div>
      <div className="flex-1 space-y-3">
        {tasks.length === 0 && (
          <p className="rounded-2xl border-2 border-dashed border-line px-4 py-6 text-center text-xs font-semibold text-ink-faint">
            {emptyHint}
          </p>
        )}
        {tasks.map((t) => (
          <Card key={t.id} className={cn("p-4", t.status === "skipped" && "opacity-60")}>
            <div className="flex items-start justify-between gap-2">
              <p className={cn("font-bold text-pine-900", t.status === "done" && "line-through opacity-70")}>
                {t.title}
              </p>
              {t.priority === "high" && t.status !== "done" && <Badge tone="clay">High</Badge>}
            </div>
            <p className="mt-1.5 flex flex-wrap items-center gap-x-2 text-xs text-ink-soft">
              <span className="font-semibold text-pine-700">{whenLabel(new Date(t.scheduledFor))}</span>
              <span aria-hidden>·</span>
              <span>{format(new Date(t.scheduledFor), "h:mm a")}</span>
              <span aria-hidden>·</span>
              <span className="capitalize">{t.category}</span>
            </p>
            <div className="mt-3 flex items-center justify-between gap-2">
              <span className="inline-flex items-center gap-1.5 text-xs font-bold text-pine-700">
                <Avatar name={t.elderName} accentKey={t.elderAccent} size="sm" className="h-6 w-6 text-[9px] ring-2" />
                {t.elderName.split(" ")[0]}
              </span>
              <span className="text-[11px] font-semibold text-ink-faint">
                {t.caregiverName ?? "Unassigned"}
              </span>
            </div>
            {t.notes && (
              <p className="mt-2.5 rounded-xl bg-paper px-3 py-2 text-xs leading-relaxed text-ink-soft">
                {t.notes}
              </p>
            )}
            <div className="mt-3 border-t border-line/60 pt-3">
              <TaskStatusControl taskId={t.id} status={t.status} />
            </div>
          </Card>
        ))}
      </div>
    </section>
  );
}

export default async function TasksPage() {
  const [tasks, elderList, caregiverList] = await Promise.all([
    getCareTasks(),
    getElders(),
    getCaregivers(),
  ]);

  const inWeek = tasks.filter(
    (t) => t.scheduledFor.getTime() < Date.now() + 7 * 864e5,
  );
  const pending = inWeek.filter((t) => t.status === "pending");
  const inProgress = inWeek.filter((t) => t.status === "in_progress");
  const finished = inWeek.filter((t) => t.status === "done" || t.status === "skipped");

  return (
    <div className="mx-auto max-w-6xl space-y-7">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-semibold text-ink-soft">
            {pending.length + inProgress.length} open tasks this week
          </p>
          <h2 className="mt-1 font-display text-3xl font-semibold tracking-tight text-pine-900 sm:text-4xl">
            Care task board
          </h2>
        </div>
        <AddTaskDialog
          elders={elderList.map((e) => ({ id: e.id, name: e.name }))}
          caregivers={caregiverList.map((c) => ({ id: c.id, name: c.name }))}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Column
          title="To do"
          icon={<CircleDashed className="h-4 w-4" />}
          tone="bg-honey-100 text-honey-600"
          tasks={pending}
          emptyHint="Nothing waiting — nicely organized."
        />
        <Column
          title="In progress"
          icon={<CirclePlay className="h-4 w-4" />}
          tone="bg-sky-100 text-sky-700"
          tasks={inProgress}
          emptyHint="Start a task and it moves here."
        />
        <Column
          title="Completed"
          icon={<CheckCircle2 className="h-4 w-4" />}
          tone="bg-emerald-100 text-emerald-600"
          tasks={finished}
          emptyHint="Finished tasks gather here."
        />
      </div>

      {inWeek.length === 0 && (
        <Card className="flex flex-col items-center gap-3 p-12 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-full bg-pine-100 text-pine-700">
            <ClipboardList className="h-7 w-7" />
          </span>
          <p className="font-display text-2xl font-semibold text-pine-900">The week is wide open</p>
          <p className="max-w-sm text-sm text-ink-soft">
            Schedule the first care task and assign it to a caregiver.
          </p>
        </Card>
      )}
    </div>
  );
}
