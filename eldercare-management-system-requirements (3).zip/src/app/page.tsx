import Link from "next/link";
import {
  ArrowRight,
  BellRing,
  CalendarCheck2,
  CheckCircle2,
  ClipboardList,
  HeartHandshake,
  HeartPulse,
  Pill,
  Quote,
  ShieldCheck,
  Siren,
  Sparkles,
  Star,
  Stethoscope,
  Users,
} from "lucide-react";
import { CountUp, Float, Reveal, Stagger, StaggerItem } from "@/components/motion";

const HERO_IMG =
  "https://images.pexels.com/photos/16364307/pexels-photo-16364307.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=880";
const GARDEN_IMG =
  "https://images.pexels.com/photos/3768131/pexels-photo-3768131.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200";
const VITALS_IMG =
  "https://images.pexels.com/photos/8088853/pexels-photo-8088853.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200";
const COMMUNITY_IMG =
  "https://images.pexels.com/photos/18429310/pexels-photo-18429310.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200";

const SERVICES = [
  "Medication reminders",
  "Doctor appointments",
  "Daily care tasks",
  "Health records",
  "Emergency assistance",
  "Family monitoring",
  "Caregiver coordination",
  "Meal & wellness check-ins",
];

const FEATURES = [
  {
    icon: <Users className="h-6 w-6" />,
    title: "Care coordination",
    body: "Elders, family members, and caregivers share one calm, up-to-date picture of daily care.",
    tone: "bg-pine-100 text-pine-700",
  },
  {
    icon: <Pill className="h-6 w-6" />,
    title: "Medicine schedules",
    body: "Clear dose times, gentle reminders, and a daily checklist that shows exactly what happened.",
    tone: "bg-honey-100 text-honey-600",
  },
  {
    icon: <CalendarCheck2 className="h-6 w-6" />,
    title: "Doctor appointments",
    body: "Book visits in a few taps and keep every upcoming appointment visible to the whole circle.",
    tone: "bg-sky-100 text-sky-700",
  },
  {
    icon: <HeartPulse className="h-6 w-6" />,
    title: "Health records",
    body: "Blood pressure, heart rate, glucose, and weight — recorded simply, shown as trends.",
    tone: "bg-clay-100 text-clay-500",
  },
  {
    icon: <Siren className="h-6 w-6" />,
    title: "Emergency assist",
    body: "One prominent button requests help instantly and notifies the care circle to respond.",
    tone: "bg-rose-100 text-rose-600",
  },
  {
    icon: <BellRing className="h-6 w-6" />,
    title: "Gentle visibility",
    body: "Families follow an activity feed — doses taken, visits completed — without hovering.",
    tone: "bg-emerald-100 text-emerald-700",
  },
];

const STEPS = [
  {
    n: "01",
    title: "Create a care profile",
    body: "Add your loved one's details, conditions, medications, and emergency contacts in minutes.",
  },
  {
    n: "02",
    title: "Build the care circle",
    body: "Invite family, assign verified caregivers, and connect doctors and clinics.",
  },
  {
    n: "03",
    title: "Let the day flow",
    body: "Doses, visits, and tasks surface when they matter. Everyone stays gently informed.",
  },
];

const PERSONAS = [
  {
    icon: <HeartHandshake className="h-5 w-5" />,
    role: "Elderly users",
    points: ["Large, readable text", "One-tap help button", "Simple daily checklist"],
  },
  {
    icon: <Users className="h-5 w-5" />,
    role: "Family members",
    points: ["Appointments & medications", "Live activity feed", "Caregiver updates"],
  },
  {
    icon: <Stethoscope className="h-5 w-5" />,
    role: "Caregivers",
    points: ["Structured daily tasks", "Assigned elders", "Vitals & care notes"],
  },
  {
    icon: <ShieldCheck className="h-5 w-5" />,
    role: "Administrators",
    points: ["Users & providers", "Service requests", "Operational oversight"],
  },
];

export default function LandingPage() {
  return (
    <main className="relative overflow-x-clip">
      {/* ------------------------------- nav ------------------------------- */}
      <header className="fixed inset-x-0 top-0 z-50">
        <div className="mx-auto mt-4 flex max-w-6xl items-center justify-between rounded-full border border-line/70 bg-card/85 px-5 py-3 shadow-soft backdrop-blur-xl sm:mx-4 lg:mx-auto">
          <Link href="/" className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-pine-700 text-white">
              <HeartHandshake className="h-5 w-5" />
            </span>
            <span className="font-display text-xl font-semibold tracking-tight text-pine-900">
              ElderCare
            </span>
          </Link>
          <nav className="hidden items-center gap-7 text-sm font-semibold text-ink-soft md:flex">
            <a href="#features" className="transition-colors hover:text-pine-900">Features</a>
            <a href="#how" className="transition-colors hover:text-pine-900">How it works</a>
            <a href="#roles" className="transition-colors hover:text-pine-900">Who it&apos;s for</a>
          </nav>
          <Link
            href="/dashboard"
            className="inline-flex h-11 items-center gap-2 rounded-full bg-pine-700 px-5 text-sm font-bold text-white shadow-[0_10px_24px_-10px_rgba(31,82,65,0.7)] transition-all hover:bg-pine-800 active:scale-[0.98]"
          >
            Open dashboard
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </header>

      {/* ------------------------------- hero ------------------------------- */}
      <section className="grain relative overflow-hidden bg-paper">
        <div
          aria-hidden
          className="absolute -top-40 right-[-10%] h-[560px] w-[560px] rounded-full bg-honey-200/50 blur-3xl"
        />
        <div
          aria-hidden
          className="absolute bottom-[-20%] left-[-8%] h-[480px] w-[480px] rounded-full bg-pine-200/60 blur-3xl"
        />

        <div className="relative mx-auto grid max-w-6xl gap-14 px-5 pt-36 pb-20 sm:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:pt-44 lg:pb-28">
          <div>
            <Reveal>
              <span className="inline-flex items-center gap-2 rounded-full border border-pine-200 bg-pine-50 px-4 py-1.5 text-xs font-bold tracking-wide text-pine-700">
                <Sparkles className="h-3.5 w-3.5" />
                ELDER-CARE, BEAUTIFULLY ORGANIZED
              </span>
            </Reveal>
            <Reveal delay={0.08}>
              <h1 className="mt-6 font-display text-[2.9rem] leading-[1.02] font-semibold tracking-tight text-pine-900 text-balance sm:text-6xl lg:text-[4.4rem]">
                Care that feels like{" "}
                <span className="relative inline-block text-pine-700 italic">
                  family
                  <svg
                    aria-hidden
                    viewBox="0 0 220 20"
                    className="absolute -bottom-2 left-0 w-full text-honey-400"
                    fill="none"
                  >
                    <path
                      d="M4 14C50 6 150 4 216 12"
                      stroke="currentColor"
                      strokeWidth="7"
                      strokeLinecap="round"
                    />
                  </svg>
                </span>
              </h1>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="mt-7 max-w-xl text-lg leading-relaxed text-ink-soft text-pretty">
                One calm place for elders, families, and caregivers — medicine
                schedules, doctor appointments, health records, and daily care,
                coordinated without the chaos.
              </p>
            </Reveal>
            <Reveal delay={0.24}>
              <div className="mt-9 flex flex-wrap items-center gap-4">
                <Link
                  href="/dashboard"
                  className="inline-flex h-14 items-center gap-2.5 rounded-full bg-pine-700 px-8 text-base font-bold text-white shadow-[0_14px_30px_-10px_rgba(31,82,65,0.6)] transition-all hover:-translate-y-0.5 hover:bg-pine-800 active:scale-[0.98]"
                >
                  Start coordinating
                  <ArrowRight className="h-5 w-5" />
                </Link>
                <a
                  href="#how"
                  className="inline-flex h-14 items-center gap-2 rounded-full border-2 border-pine-200 px-7 text-base font-bold text-pine-800 transition-colors hover:border-pine-400 hover:bg-pine-50"
                >
                  See how it works
                </a>
              </div>
            </Reveal>
            <Reveal delay={0.32}>
              <dl className="mt-12 flex flex-wrap gap-x-12 gap-y-6">
                {[
                  { v: 4200, s: "+", label: "Families caring together" },
                  { v: 380, s: "+", label: "Verified caregivers" },
                  { v: 98, s: "%", label: "Doses logged on time" },
                ].map((s) => (
                  <div key={s.label}>
                    <dt className="sr-only">{s.label}</dt>
                    <dd className="font-display text-3xl font-semibold text-pine-900">
                      <CountUp to={s.v} suffix={s.s} />
                    </dd>
                    <dd className="mt-1 text-[13px] font-medium text-ink-soft">{s.label}</dd>
                  </div>
                ))}
              </dl>
            </Reveal>
          </div>

          {/* hero collage */}
          <div className="relative mx-auto w-full max-w-md lg:max-w-none">
            <Reveal delay={0.15} y={40}>
              <div className="relative">
                <div className="overflow-hidden rounded-[2.5rem] border-8 border-card shadow-lift">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={HERO_IMG}
                    alt="A caregiver warmly helping an elderly woman with a cup of tea"
                    className="aspect-[4/5] w-full object-cover"
                  />
                </div>

                <Float className="absolute -left-6 top-10 sm:-left-10" delay={0.4}>
                  <div className="flex items-center gap-3 rounded-2xl border border-line/70 bg-card/95 p-3.5 pr-5 shadow-lift backdrop-blur">
                    <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-honey-100 text-honey-600">
                      <Pill className="h-5 w-5" />
                    </span>
                    <div>
                      <p className="text-[13px] font-bold text-pine-900">Donepezil 10&nbsp;mg</p>
                      <p className="text-xs font-medium text-emerald-600">
                        ✓ Taken at 8:00 AM
                      </p>
                    </div>
                  </div>
                </Float>

                <Float className="absolute -right-4 bottom-24 sm:-right-8" delay={1.6}>
                  <div className="flex items-center gap-3 rounded-2xl border border-line/70 bg-card/95 p-3.5 pr-5 shadow-lift backdrop-blur">
                    <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-pine-100 text-pine-700">
                      <CalendarCheck2 className="h-5 w-5" />
                    </span>
                    <div>
                      <p className="text-[13px] font-bold text-pine-900">Dr. Okafor · Cardiology</p>
                      <p className="text-xs font-medium text-ink-soft">Tomorrow, 10:30 AM</p>
                    </div>
                  </div>
                </Float>

                <div className="absolute -bottom-6 left-8 flex items-center gap-2.5 rounded-full border border-line/70 bg-pine-800 py-2.5 pr-5 pl-3 text-white shadow-lift">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-honey-400 text-pine-900">
                    <Star className="h-4 w-4 fill-current" />
                  </span>
                  <p className="text-[13px] font-bold">
                    4.9 · families&apos; peace-of-mind rating
                  </p>
                </div>
              </div>
            </Reveal>
          </div>
        </div>

        {/* marquee */}
        <div className="relative border-y border-line/80 bg-card py-5">
          <div className="flex overflow-hidden" aria-hidden>
            <div className="flex min-w-max animate-marquee items-center gap-8 pr-8">
              {[...SERVICES, ...SERVICES].map((s, i) => (
                <span
                  key={i}
                  className="flex items-center gap-3 text-sm font-bold tracking-wide whitespace-nowrap text-ink-soft"
                >
                  <span className="h-1.5 w-1.5 rounded-full bg-honey-400" />
                  {s}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ------------------------------ features ----------------------------- */}
      <section id="features" className="mx-auto max-w-6xl px-5 py-24 sm:px-8 lg:py-32">
        <Reveal>
          <p className="text-xs font-bold tracking-[0.24em] text-pine-500 uppercase">
            One platform, the whole circle
          </p>
          <h2 className="mt-4 max-w-2xl font-display text-4xl font-semibold tracking-tight text-pine-900 text-balance sm:text-5xl">
            Everything elder-care needs, nothing it doesn&apos;t
          </h2>
        </Reveal>
        <Stagger className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <StaggerItem key={f.title}>
              <article className="group h-full rounded-[1.75rem] border border-line/70 bg-card p-7 shadow-soft transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lift">
                <span
                  className={`inline-flex h-13 w-13 items-center justify-center rounded-2xl p-3 ${f.tone} transition-transform duration-300 group-hover:scale-110`}
                >
                  {f.icon}
                </span>
                <h3 className="mt-5 font-display text-[1.35rem] font-semibold text-pine-900">
                  {f.title}
                </h3>
                <p className="mt-2 text-[15px] leading-relaxed text-ink-soft">{f.body}</p>
              </article>
            </StaggerItem>
          ))}
        </Stagger>
      </section>

      {/* ---------------------------- photo + how --------------------------- */}
      <section id="how" className="relative overflow-hidden bg-pine-900 py-24 text-white lg:py-32">
        <div aria-hidden className="absolute top-0 right-0 h-96 w-96 rounded-full bg-pine-700/50 blur-3xl" />
        <div aria-hidden className="absolute bottom-0 left-0 h-80 w-80 rounded-full bg-honey-500/10 blur-3xl" />
        <div className="relative mx-auto grid max-w-6xl items-center gap-14 px-5 sm:px-8 lg:grid-cols-2">
          <Reveal>
            <div className="relative">
              <div className="overflow-hidden rounded-[2.5rem] shadow-lift">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={GARDEN_IMG}
                  alt="A daughter greeting her happy senior mother in the garden"
                  className="aspect-[5/4] w-full object-cover"
                />
              </div>
              <div className="absolute -right-5 -bottom-6 hidden w-44 rotate-3 overflow-hidden rounded-3xl border-4 border-white shadow-lift sm:block">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={VITALS_IMG}
                  alt="A caregiver measuring a senior's blood pressure"
                  className="aspect-square w-full object-cover"
                />
              </div>
            </div>
          </Reveal>
          <div>
            <Reveal>
              <p className="text-xs font-bold tracking-[0.24em] text-honey-300 uppercase">
                How it works
              </p>
              <h2 className="mt-4 font-display text-4xl font-semibold tracking-tight text-balance sm:text-5xl">
                Set up in an afternoon. Felt every day.
              </h2>
            </Reveal>
            <div className="mt-12 space-y-2">
              {STEPS.map((s, i) => (
                <Reveal key={s.n} delay={i * 0.1}>
                  <div className="group flex gap-6 rounded-3xl p-5 transition-colors hover:bg-white/5">
                    <span className="font-display text-4xl font-semibold text-honey-300/90">
                      {s.n}
                    </span>
                    <div>
                      <h3 className="text-xl font-bold">{s.title}</h3>
                      <p className="mt-1.5 max-w-md leading-relaxed text-pine-100/85">{s.body}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
            <Reveal delay={0.25}>
              <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3 pl-5 text-sm font-semibold text-pine-100/80">
                {["No training needed", "Works on any device", "Private by design"].map((t) => (
                  <span key={t} className="inline-flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-honey-300" />
                    {t}
                  </span>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ------------------------------- roles ------------------------------- */}
      <section id="roles" className="mx-auto max-w-6xl px-5 py-24 sm:px-8 lg:py-32">
        <div className="grid items-end gap-8 lg:grid-cols-[1fr_auto]">
          <Reveal>
            <p className="text-xs font-bold tracking-[0.24em] text-pine-500 uppercase">
              Who it&apos;s for
            </p>
            <h2 className="mt-4 max-w-xl font-display text-4xl font-semibold tracking-tight text-pine-900 text-balance sm:text-5xl">
              One home, four doorways
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="max-w-sm text-[15px] leading-relaxed text-ink-soft">
              Each person in the care circle gets a view shaped for them —
              simple for elders, insightful for families, structured for
              caregivers, clear for administrators.
            </p>
          </Reveal>
        </div>
        <Stagger className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {PERSONAS.map((p) => (
            <StaggerItem key={p.role}>
              <article className="flex h-full flex-col rounded-[1.75rem] border border-line/70 bg-card p-6 shadow-soft transition-all duration-300 hover:-translate-y-1.5 hover:shadow-lift">
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-pine-700 text-white">
                  {p.icon}
                </span>
                <h3 className="mt-4 font-display text-xl font-semibold text-pine-900">{p.role}</h3>
                <ul className="mt-3 space-y-2.5">
                  {p.points.map((pt) => (
                    <li key={pt} className="flex items-start gap-2.5 text-sm font-medium text-ink-soft">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-pine-500" />
                      {pt}
                    </li>
                  ))}
                </ul>
              </article>
            </StaggerItem>
          ))}
        </Stagger>
      </section>

      {/* ---------------------------- testimonial ---------------------------- */}
      <section className="relative overflow-hidden bg-honey-50 py-24 lg:py-28">
        <Quote
          aria-hidden
          className="absolute -top-6 left-8 h-40 w-40 rotate-180 text-honey-200"
        />
        <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-5 sm:px-8 lg:grid-cols-[0.9fr_1.1fr]">
          <Reveal>
            <div className="overflow-hidden rounded-[2.5rem] shadow-lift">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={COMMUNITY_IMG}
                alt="A caregiver having a warm conversation with an elderly woman"
                className="aspect-[4/3] w-full object-cover"
              />
            </div>
          </Reveal>
          <div>
            <Reveal>
              <blockquote className="font-display text-3xl leading-snug font-medium tracking-tight text-pine-900 text-balance sm:text-4xl">
                “For the first time, the whole family sees the same picture of
                Mum&apos;s day. The worry just… softened.”
              </blockquote>
            </Reveal>
            <Reveal delay={0.12}>
              <div className="mt-8 flex items-center gap-4">
                <span className="flex h-13 w-13 items-center justify-center rounded-full bg-pine-700 font-display text-lg font-semibold text-white">
                  RS
                </span>
                <div>
                  <p className="font-bold text-pine-900">Renata Sørensen</p>
                  <p className="text-sm text-ink-soft">
                    Daughter &amp; family coordinator, Copenhagen
                  </p>
                </div>
                <span className="ml-auto hidden items-center gap-1 rounded-full bg-white px-4 py-2 text-sm font-bold text-honey-600 sm:inline-flex">
                  <Star className="h-4 w-4 fill-current" /> 4.9
                </span>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* -------------------------------- CTA -------------------------------- */}
      <section className="mx-auto max-w-6xl px-5 py-24 sm:px-8">
        <Reveal>
          <div className="grain relative overflow-hidden rounded-[2.5rem] bg-pine-800 px-8 py-16 text-center text-white shadow-lift sm:px-16 sm:py-20">
            <div aria-hidden className="absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-honey-400/20 blur-3xl" />
            <h2 className="relative mx-auto max-w-2xl font-display text-4xl font-semibold tracking-tight text-balance sm:text-5xl">
              Bring everyone into the circle of care
            </h2>
            <p className="relative mx-auto mt-5 max-w-xl text-lg text-pine-100/85">
              Explore the live dashboard — switch between elder, family,
              caregiver, and admin views to see the whole system at work.
            </p>
            <div className="relative mt-10 flex flex-wrap items-center justify-center gap-4">
              <Link
                href="/dashboard"
                className="inline-flex h-14 items-center gap-2.5 rounded-full bg-honey-400 px-8 text-base font-bold text-pine-900 shadow-[0_14px_30px_-10px_rgba(232,172,62,0.7)] transition-all hover:-translate-y-0.5 hover:bg-honey-300 active:scale-[0.98]"
              >
                Open the dashboard
                <ArrowRight className="h-5 w-5" />
              </Link>
              <span className="inline-flex items-center gap-2 text-sm font-semibold text-pine-100/80">
                <ClipboardList className="h-4 w-4" />
                Demo data included — nothing to set up
              </span>
            </div>
          </div>
        </Reveal>
      </section>

      {/* ------------------------------- footer ------------------------------ */}
      <footer className="border-t border-line/80 bg-card">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-6 px-5 py-10 sm:flex-row sm:px-8">
          <div className="flex items-center gap-2.5">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-pine-700 text-white">
              <HeartHandshake className="h-4 w-4" />
            </span>
            <span className="font-display text-lg font-semibold text-pine-900">ElderCare</span>
          </div>
          <p className="max-w-md text-center text-xs leading-relaxed text-ink-faint sm:text-left">
            ElderCare supports care coordination. It does not diagnose, treat,
            or replace professional medical advice. In a life-threatening
            emergency, always call your local emergency number first.
          </p>
          <p className="text-xs font-semibold text-ink-soft">
            © {new Date().getFullYear()} ElderCare Management System
          </p>
        </div>
      </footer>
    </main>
  );
}
