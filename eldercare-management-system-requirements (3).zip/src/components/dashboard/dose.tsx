"use client";

import * as React from "react";
import { Check, X, Clock3, AlertCircle, CheckCircle2, MinusCircle } from "lucide-react";
import { logDose } from "@/lib/actions";
import { cn } from "@/lib/utils";
import { Spinner } from "@/components/ui";

export type DoseState = "taken" | "missed" | "skipped" | "due" | "upcoming";

export function DoseBadge({ state, large = false }: { state: DoseState; large?: boolean }) {
  const map: Record<DoseState, { cls: string; icon: React.ReactNode; label: string }> = {
    taken: {
      cls: "bg-emerald-100 text-emerald-700",
      icon: <CheckCircle2 className={large ? "h-5 w-5" : "h-3.5 w-3.5"} />,
      label: "Taken",
    },
    missed: {
      cls: "bg-clay-100 text-clay-600",
      icon: <AlertCircle className={large ? "h-5 w-5" : "h-3.5 w-3.5"} />,
      label: "Missed",
    },
    skipped: {
      cls: "bg-paper-deep text-ink-soft",
      icon: <MinusCircle className={large ? "h-5 w-5" : "h-3.5 w-3.5"} />,
      label: "Skipped",
    },
    due: {
      cls: "bg-honey-100 text-honey-700",
      icon: <Clock3 className={large ? "h-5 w-5" : "h-3.5 w-3.5"} />,
      label: "Due now",
    },
    upcoming: {
      cls: "bg-sky-100 text-sky-700",
      icon: <Clock3 className={large ? "h-5 w-5" : "h-3.5 w-3.5"} />,
      label: "Upcoming",
    },
  };
  const m = map[state];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full font-bold",
        large ? "px-4 py-2 text-sm" : "px-3 py-1 text-xs",
        m.cls,
      )}
    >
      {m.icon}
      {m.label}
    </span>
  );
}

export function DoseActions({
  medicationId,
  scheduledFor,
  state,
  large = false,
}: {
  medicationId: string;
  scheduledFor: string | Date;
  state: DoseState;
  large?: boolean;
}) {
  const [pending, setPending] = React.useState<"taken" | "missed" | null>(null);
  const iso = new Date(scheduledFor).toISOString();

  async function act(status: "taken" | "missed") {
    setPending(status);
    try {
      await logDose(medicationId, iso, status);
    } finally {
      setPending(null);
    }
  }

  if (state === "taken") {
    return (
      <span
        className={cn(
          "inline-flex items-center justify-center gap-2 rounded-full bg-emerald-600 font-bold text-white",
          large ? "h-14 px-7 text-base" : "h-10 px-5 text-sm",
        )}
      >
        <Check className={large ? "h-5 w-5" : "h-4 w-4"} />
        Taken
      </span>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <button
        onClick={() => act("taken")}
        disabled={pending !== null}
        className={cn(
          "inline-flex items-center justify-center gap-2 rounded-full bg-pine-700 font-bold text-white transition-all hover:bg-pine-800 active:scale-[0.97] disabled:opacity-60",
          large ? "h-14 px-7 text-base" : "h-10 px-5 text-sm",
        )}
      >
        {pending === "taken" ? (
          <Spinner className={large ? "h-5 w-5" : "h-4 w-4"} />
        ) : (
          <Check className={large ? "h-5 w-5" : "h-4 w-4"} />
        )}
        Mark taken
      </button>
      {state === "due" && (
        <button
          onClick={() => act("missed")}
          disabled={pending !== null}
          title="Mark as missed"
          className={cn(
            "inline-flex items-center justify-center rounded-full border-2 border-line text-ink-soft transition-colors hover:border-clay-100 hover:text-clay-500 disabled:opacity-60",
            large ? "h-14 w-14" : "h-10 w-10",
          )}
        >
          {pending === "missed" ? (
            <Spinner className={large ? "h-5 w-5" : "h-4 w-4"} />
          ) : (
            <X className={large ? "h-5 w-5" : "h-4 w-4"} />
          )}
        </button>
      )}
    </div>
  );
}
