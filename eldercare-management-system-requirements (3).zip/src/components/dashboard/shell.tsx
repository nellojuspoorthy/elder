"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  CalendarCheck2,
  ClipboardList,
  HeartHandshake,
  LayoutDashboard,
  Menu,
  Pill,
  ShieldCheck,
  Siren,
  Stethoscope,
  Users,
  X,
} from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { RoleProvider, useRole, type Role } from "@/components/role";
import { RoleSwitcher } from "@/components/role";
import { Button, Dialog, Select, Spinner, Badge } from "@/components/ui";
import { triggerAlert } from "@/lib/actions";

export type ElderOption = { id: string; name: string; accent: string | null };

const NAV: {
  href: string;
  label: string;
  icon: React.ReactNode;
  roles: Role[];
}[] = [
  { href: "/dashboard", label: "Overview", icon: <LayoutDashboard className="h-5 w-5" />, roles: ["elder", "family", "caregiver", "admin"] },
  { href: "/dashboard/elders", label: "Care profiles", icon: <Users className="h-5 w-5" />, roles: ["family", "caregiver", "admin"] },
  { href: "/dashboard/medications", label: "Medications", icon: <Pill className="h-5 w-5" />, roles: ["elder", "family", "caregiver", "admin"] },
  { href: "/dashboard/appointments", label: "Appointments", icon: <CalendarCheck2 className="h-5 w-5" />, roles: ["elder", "family", "caregiver", "admin"] },
  { href: "/dashboard/caregivers", label: "Caregivers", icon: <Stethoscope className="h-5 w-5" />, roles: ["elder", "family", "admin"] },
  { href: "/dashboard/tasks", label: "Care tasks", icon: <ClipboardList className="h-5 w-5" />, roles: ["family", "caregiver", "admin"] },
  { href: "/dashboard/admin", label: "Administration", icon: <ShieldCheck className="h-5 w-5" />, roles: ["admin"] },
];

function SOSPanel({ elders }: { elders: ElderOption[] }) {
  const [open, setOpen] = React.useState(false);
  const [elderId, setElderId] = React.useState(elders[0]?.id ?? "");
  const [type, setType] = React.useState("medical");
  const [pending, setPending] = React.useState(false);
  const [sent, setSent] = React.useState(false);

  async function send() {
    if (!elderId) return;
    setPending(true);
    try {
      await triggerAlert(elderId, type);
      setSent(true);
      setTimeout(() => {
        setSent(false);
        setOpen(false);
      }, 2200);
    } finally {
      setPending(false);
    }
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="flex w-full items-center gap-3 rounded-2xl bg-clay-500 px-4 py-3.5 text-left text-white shadow-[0_12px_28px_-10px_rgba(196,85,63,0.8)] transition-all hover:bg-clay-600 active:scale-[0.98]"
      >
        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-white/20 animate-pulse-ring">
          <Siren className="h-5 w-5" />
        </span>
        <span>
          <span className="block text-sm font-extrabold tracking-wide">Emergency assist</span>
          <span className="block text-xs text-white/80">Alert the care circle</span>
        </span>
      </button>

      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title="Request assistance"
        subtitle="The care circle and on-duty caregivers are notified immediately."
      >
        {sent ? (
          <div className="flex flex-col items-center py-8 text-center">
            <motion.span
              initial={{ scale: 0.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-600"
            >
              <Siren className="h-7 w-7" />
            </motion.span>
            <p className="mt-4 font-display text-2xl font-semibold text-pine-900">
              Help is on the way
            </p>
            <p className="mt-2 max-w-xs text-sm text-ink-soft">
              Your alert was sent to the care circle. In a life-threatening
              emergency, call your local emergency number too.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-semibold text-pine-900">
                Who needs help?
              </label>
              <Select value={elderId} onChange={(e) => setElderId(e.target.value)}>
                {elders.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-semibold text-pine-900">
                What&apos;s happening?
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { k: "medical", l: "Medical" },
                  { k: "fall", l: "Fall" },
                  { k: "other", l: "Other" },
                ].map((t) => (
                  <button
                    key={t.k}
                    onClick={() => setType(t.k)}
                    className={cn(
                      "rounded-2xl border-2 px-3 py-2.5 text-sm font-bold transition-colors",
                      type === t.k
                        ? "border-clay-500 bg-clay-50 text-clay-600"
                        : "border-line text-ink-soft hover:border-clay-100",
                    )}
                  >
                    {t.l}
                  </button>
                ))}
              </div>
            </div>
            <Button
              variant="danger"
              size="xl"
              className="w-full"
              onClick={send}
              disabled={pending || !elderId}
            >
              {pending ? <Spinner /> : <Siren className="h-5 w-5" />}
              Send alert now
            </Button>
            <p className="text-center text-xs text-ink-faint">
              For life-threatening emergencies, always call emergency services first.
            </p>
          </div>
        )}
      </Dialog>
    </>
  );
}

function SidebarContent({ elders, onNavigate }: { elders: ElderOption[]; onNavigate?: () => void }) {
  const pathname = usePathname();
  const { role } = useRole();
  const items = NAV.filter((n) => n.roles.includes(role));

  return (
    <div className="flex h-full flex-col gap-2 p-5">
      <Link href="/" onClick={onNavigate} className="mb-3 flex items-center gap-2.5 px-1">
        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-pine-700 text-white">
          <HeartHandshake className="h-5 w-5" />
        </span>
        <span>
          <span className="block font-display text-xl font-semibold tracking-tight text-pine-900">
            ElderCare
          </span>
          <span className="block text-[10px] font-bold tracking-[0.18em] text-ink-faint uppercase">
            Care coordination
          </span>
        </span>
      </Link>

      <nav className="flex flex-1 flex-col gap-1" aria-label="Primary">
        {items.map((item) => {
          const active =
            item.href === "/dashboard"
              ? pathname === "/dashboard"
              : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onNavigate}
              aria-current={active ? "page" : undefined}
              className={cn(
                "flex items-center gap-3 rounded-2xl px-4 py-3 text-[15px] font-semibold transition-all",
                active
                  ? "bg-pine-700 text-white shadow-[0_10px_20px_-10px_rgba(31,82,65,0.7)]"
                  : "text-ink-soft hover:bg-pine-50 hover:text-pine-900",
              )}
            >
              {item.icon}
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="space-y-3">
        <SOSPanel elders={elders} />
        <RoleSwitcher />
        <p className="px-1 text-[10px] leading-relaxed text-ink-faint">
          Not a medical device. In emergencies, call your local emergency number.
        </p>
      </div>
    </div>
  );
}

function ShellInner({
  elders,
  activeAlerts,
  children,
}: {
  elders: ElderOption[];
  activeAlerts: number;
  children: React.ReactNode;
}) {
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const pathname = usePathname();
  const current =
    [...NAV].reverse().find((n) =>
      n.href === "/dashboard" ? pathname === "/dashboard" : pathname.startsWith(n.href),
    ) ?? NAV[0];

  return (
    <div className="min-h-screen bg-paper lg:pl-[290px]">
      {/* desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[290px] border-r border-line/70 bg-card lg:block">
        <SidebarContent elders={elders} />
      </aside>

      {/* mobile sidebar */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            className="fixed inset-0 z-[80] lg:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div
              className="absolute inset-0 bg-pine-900/50 backdrop-blur-sm"
              onClick={() => setMobileOpen(false)}
            />
            <motion.aside
              initial={{ x: -320 }}
              animate={{ x: 0 }}
              exit={{ x: -320 }}
              transition={{ type: "spring", stiffness: 300, damping: 32 }}
              className="absolute inset-y-0 left-0 w-[290px] bg-card shadow-lift"
            >
              <button
                onClick={() => setMobileOpen(false)}
                aria-label="Close menu"
                className="absolute top-4 right-4 z-10 rounded-full p-2 text-ink-soft hover:bg-paper-deep"
              >
                <X className="h-5 w-5" />
              </button>
              <SidebarContent elders={elders} onNavigate={() => setMobileOpen(false)} />
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      {/* top bar */}
      <header className="sticky top-0 z-30 border-b border-line/60 bg-paper/85 backdrop-blur-xl">
        <div className="flex items-center gap-3 px-4 py-3.5 sm:px-8">
          <button
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
            className="rounded-xl border-2 border-line bg-card p-2.5 text-pine-800 lg:hidden"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="min-w-0 flex-1">
            <h1 className="truncate font-display text-xl font-semibold tracking-tight text-pine-900">
              {current.label}
            </h1>
          </div>
          {activeAlerts > 0 && (
            <Badge tone="clay" dot className="animate-pulse">
              {activeAlerts} active alert{activeAlerts > 1 ? "s" : ""}
            </Badge>
          )}
          <div className="hidden sm:block sm:w-52">
            <RoleSwitcher />
          </div>
        </div>
      </header>

      <main className="px-4 py-6 sm:px-8 sm:py-8">{children}</main>
    </div>
  );
}

export function DashboardShell({
  elders,
  activeAlerts,
  children,
}: {
  elders: ElderOption[];
  activeAlerts: number;
  children: React.ReactNode;
}) {
  return (
    <RoleProvider>
      <ShellInner elders={elders} activeAlerts={activeAlerts}>
        {children}
      </ShellInner>
    </RoleProvider>
  );
}
