"use client";

import * as React from "react";
import { Plus, Stethoscope, UserRoundPlus } from "lucide-react";
import { addCaregiver, addDoctor } from "@/lib/actions";
import {
  Button,
  Dialog,
  FieldError,
  Input,
  Label,
  Select,
  Spinner,
  Textarea,
} from "@/components/ui";

/* ------------------------------- add doctor -------------------------------- */

export function AddDoctorDialog() {
  const [open, setOpen] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [pending, setPending] = React.useState(false);
  const [values, setValues] = React.useState({ name: "", specialty: "", clinic: "", phone: "" });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setPending(true);
    try {
      await addDoctor(values);
      setValues({ name: "", specialty: "", clinic: "", phone: "" });
      setOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setPending(false);
    }
  }

  return (
    <>
      <Button variant="outline" onClick={() => setOpen(true)}>
        <Stethoscope className="h-4.5 w-4.5" />
        Add doctor
      </Button>
      <Dialog open={open} onClose={() => setOpen(false)} title="Add a doctor">
        <form onSubmit={submit} className="space-y-4">
          <div>
            <Label htmlFor="doc-name">Full name</Label>
            <Input
              id="doc-name"
              placeholder="e.g. Amara Okafor"
              value={values.name}
              onChange={(e) => setValues((s) => ({ ...s, name: e.target.value }))}
            />
            <FieldError message={!values.name && error ? "Name is required" : undefined} />
          </div>
          <div>
            <Label htmlFor="doc-spec">Specialty</Label>
            <Input
              id="doc-spec"
              placeholder="e.g. Cardiology"
              value={values.specialty}
              onChange={(e) => setValues((s) => ({ ...s, specialty: e.target.value }))}
            />
          </div>
          <div>
            <Label htmlFor="doc-clinic">Clinic</Label>
            <Input
              id="doc-clinic"
              placeholder="e.g. Riverside Heart Center"
              value={values.clinic}
              onChange={(e) => setValues((s) => ({ ...s, clinic: e.target.value }))}
            />
          </div>
          <div>
            <Label htmlFor="doc-phone">Phone (optional)</Label>
            <Input
              id="doc-phone"
              placeholder="+1…"
              value={values.phone}
              onChange={(e) => setValues((s) => ({ ...s, phone: e.target.value }))}
            />
          </div>
          {error && values.name && (
            <p className="rounded-2xl bg-clay-50 px-4 py-3 text-sm font-semibold text-clay-600">{error}</p>
          )}
          <div className="flex justify-end gap-3 pt-1">
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={pending}>
              {pending ? <Spinner /> : <Plus className="h-5 w-5" />}
              Save doctor
            </Button>
          </div>
        </form>
      </Dialog>
    </>
  );
}

/* ----------------------------- add caregiver ------------------------------- */

export function AddCaregiverDialog() {
  const [open, setOpen] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [pending, setPending] = React.useState(false);
  const [values, setValues] = React.useState({
    name: "",
    specialty: "",
    bio: "",
    phone: "",
    yearsExperience: "3",
    status: "available" as "available" | "on_shift" | "off_duty",
  });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setPending(true);
    try {
      await addCaregiver({ ...values, yearsExperience: Number(values.yearsExperience) });
      setValues({ name: "", specialty: "", bio: "", phone: "", yearsExperience: "3", status: "available" });
      setOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setPending(false);
    }
  }

  return (
    <>
      <Button variant="outline" onClick={() => setOpen(true)}>
        <UserRoundPlus className="h-4.5 w-4.5" />
        Add caregiver
      </Button>
      <Dialog open={open} onClose={() => setOpen(false)} title="Onboard a caregiver" wide>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="cg-name">Full name</Label>
              <Input
                id="cg-name"
                placeholder="e.g. Priya Raman"
                value={values.name}
                onChange={(e) => setValues((s) => ({ ...s, name: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="cg-spec">Specialty</Label>
              <Input
                id="cg-spec"
                placeholder="e.g. Dementia care"
                value={values.specialty}
                onChange={(e) => setValues((s) => ({ ...s, specialty: e.target.value }))}
              />
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="cg-years">Years of experience</Label>
              <Input
                id="cg-years"
                type="number"
                min={0}
                max={60}
                value={values.yearsExperience}
                onChange={(e) => setValues((s) => ({ ...s, yearsExperience: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="cg-status">Availability</Label>
              <Select
                id="cg-status"
                value={values.status}
                onChange={(e) => setValues((s) => ({ ...s, status: e.target.value as typeof s.status }))}
              >
                <option value="available">Available</option>
                <option value="on_shift">On shift</option>
                <option value="off_duty">Off duty</option>
              </Select>
            </div>
          </div>
          <div>
            <Label htmlFor="cg-bio">Short bio</Label>
            <Textarea
              id="cg-bio"
              placeholder="What should families know about them?"
              value={values.bio}
              onChange={(e) => setValues((s) => ({ ...s, bio: e.target.value }))}
            />
          </div>
          <div>
            <Label htmlFor="cg-phone">Phone (optional)</Label>
            <Input
              id="cg-phone"
              placeholder="+1…"
              value={values.phone}
              onChange={(e) => setValues((s) => ({ ...s, phone: e.target.value }))}
            />
          </div>
          {error && (
            <p className="rounded-2xl bg-clay-50 px-4 py-3 text-sm font-semibold text-clay-600">{error}</p>
          )}
          <div className="flex justify-end gap-3 pt-1">
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={pending}>
              {pending ? <Spinner /> : <Plus className="h-5 w-5" />}
              Save caregiver
            </Button>
          </div>
        </form>
      </Dialog>
    </>
  );
}
