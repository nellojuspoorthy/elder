"use client";

import * as React from "react";
import { ClipboardPlus, Plus } from "lucide-react";
import { z } from "zod";
import { format } from "date-fns";
import { addCareTask } from "@/lib/actions";
import {
  Button,
  Dialog,
  FieldError,
  Input,
  Label,
  Select,
  Spinner,
  Textarea,
} from "@/components/ui";

const CATEGORIES = [
  "Daily care",
  "Medication support",
  "Meals & nutrition",
  "Mobility & exercise",
  "Household",
  "Companionship",
  "Health check",
];

const hhmm = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Use HH:MM");
const formSchema = z.object({
  elderId: z.string().min(1, "Choose the elder"),
  caregiverId: z.string().optional(),
  title: z.string().min(3, "Task title is required"),
  category: z.string().min(2),
  date: z.string().min(1, "Pick a date"),
  time: hhmm,
  priority: z.string(),
  notes: z.string().optional(),
});

type FormValues = z.input<typeof formSchema>;

export function AddTaskDialog({
  elders,
  caregivers,
}: {
  elders: { id: string; name: string }[];
  caregivers: { id: string; name: string }[];
}) {
  const [open, setOpen] = React.useState(false);
  const [serverError, setServerError] = React.useState<string | null>(null);
  const [pending, setPending] = React.useState(false);
  const [errors, setErrors] = React.useState<Record<string, string>>({});
  const [values, setValues] = React.useState<FormValues>({
    elderId: elders[0]?.id ?? "",
    caregiverId: "",
    title: "",
    category: CATEGORIES[0],
    date: format(new Date(), "yyyy-MM-dd"),
    time: "09:00",
    priority: "normal",
    notes: "",
  });

  function set<K extends keyof FormValues>(k: K, v: FormValues[K]) {
    setValues((s) => ({ ...s, [k]: v }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setServerError(null);
    const parsed = formSchema.safeParse(values);
    if (!parsed.success) {
      const map: Record<string, string> = {};
      for (const issue of parsed.error.issues) map[String(issue.path[0])] = issue.message;
      setErrors(map);
      return;
    }
    setErrors({});
    setPending(true);
    try {
      const window_ = Number(parsed.data.time.split(":")[0]) < 12 ? "morning" : Number(parsed.data.time.split(":")[0]) < 17 ? "afternoon" : "evening";
      await addCareTask({
        elderId: parsed.data.elderId,
        caregiverId: parsed.data.caregiverId || "",
        title: parsed.data.title,
        category: parsed.data.category,
        date: parsed.data.date,
        time: parsed.data.time,
        window: window_,
        priority: parsed.data.priority,
        notes: parsed.data.notes ?? "",
      });
      setValues((s) => ({ ...s, title: "", notes: "" }));
      setOpen(false);
    } catch (err) {
      setServerError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setPending(false);
    }
  }

  return (
    <>
      <Button size="lg" onClick={() => setOpen(true)}>
        <Plus className="h-5 w-5" />
        New task
      </Button>
      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title="Schedule a care task"
        subtitle="Assigned caregivers see it on their board immediately."
        wide
      >
        <form onSubmit={submit} className="space-y-4">
          <div>
            <Label htmlFor="task-title">Task</Label>
            <Input
              id="task-title"
              placeholder="e.g. Morning walk around the garden"
              value={values.title}
              onChange={(e) => set("title", e.target.value)}
            />
            <FieldError message={errors.title} />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="task-elder">For</Label>
              <Select
                id="task-elder"
                value={values.elderId}
                onChange={(e) => set("elderId", e.target.value)}
              >
                {elders.map((el) => (
                  <option key={el.id} value={el.id}>
                    {el.name}
                  </option>
                ))}
              </Select>
              <FieldError message={errors.elderId} />
            </div>
            <div>
              <Label htmlFor="task-caregiver">Assign to (optional)</Label>
              <Select
                id="task-caregiver"
                value={values.caregiverId ?? ""}
                onChange={(e) => set("caregiverId", e.target.value)}
              >
                <option value="">Any available caregiver</option>
                {caregivers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </Select>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            <div>
              <Label htmlFor="task-date">Date</Label>
              <Input
                id="task-date"
                type="date"
                min={format(new Date(), "yyyy-MM-dd")}
                value={values.date}
                onChange={(e) => set("date", e.target.value)}
              />
              <FieldError message={errors.date} />
            </div>
            <div>
              <Label htmlFor="task-time">Time</Label>
              <Input
                id="task-time"
                type="time"
                value={values.time}
                onChange={(e) => set("time", e.target.value)}
              />
              <FieldError message={errors.time} />
            </div>
            <div>
              <Label htmlFor="task-priority">Priority</Label>
              <Select
                id="task-priority"
                value={values.priority}
                onChange={(e) => set("priority", e.target.value)}
              >
                <option value="normal">Normal</option>
                <option value="high">High</option>
                <option value="low">Low</option>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="task-category">Category</Label>
            <Select
              id="task-category"
              value={values.category}
              onChange={(e) => set("category", e.target.value)}
            >
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </Select>
          </div>

          <div>
            <Label htmlFor="task-notes">Notes (optional)</Label>
            <Textarea
              id="task-notes"
              placeholder="Helpful context for the caregiver"
              value={values.notes ?? ""}
              onChange={(e) => set("notes", e.target.value)}
            />
          </div>

          {serverError && (
            <p className="rounded-2xl bg-clay-50 px-4 py-3 text-sm font-semibold text-clay-600">
              {serverError}
            </p>
          )}

          <div className="flex justify-end gap-3 pt-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={pending}>
              {pending ? <Spinner /> : <ClipboardPlus className="h-5 w-5" />}
              Add task
            </Button>
          </div>
        </form>
      </Dialog>
    </>
  );
}
