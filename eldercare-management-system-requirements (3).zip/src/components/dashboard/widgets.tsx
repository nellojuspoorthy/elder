"use client";

import * as React from "react";
import {
  ArrowRight,
  CheckCircle2,
  CirclePlay,
  PhoneCall,
  SkipForward,
  Undo2,
} from "lucide-react";
import {
  acknowledgeAlert,
  resolveAlert,
  setAppointmentStatus,
  setRequestStatus,
  assignRequest,
  setTaskStatus,
} from "@/lib/actions";
import { Button, Spinner } from "@/components/ui";
import { cn } from "@/lib/utils";

/* ------------------------------ alert actions ------------------------------ */

export function AlertActions({
  alertId,
  status,
}: {
  alertId: string;
  status: "active" | "acknowledged" | "resolved";
}) {
  const [pending, setPending] = React.useState(false);
  if (status === "resolved") return null;

  async function run(fn: () => Promise<void>) {
    setPending(true);
    try {
      await fn();
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      {status === "active" && (
        <Button size="sm" variant="danger" disabled={pending} onClick={() => run(() => acknowledgeAlert(alertId))}>
          {pending ? <Spinner /> : <PhoneCall className="h-4 w-4" />}
          I&apos;m responding
        </Button>
      )}
      <Button
        size="sm"
        variant={status === "active" ? "outline" : "primary"}
        disabled={pending}
        onClick={() => run(() => resolveAlert(alertId))}
      >
        {pending ? <Spinner /> : <CheckCircle2 className="h-4 w-4" />}
        Resolve
      </Button>
    </div>
  );
}

/* ------------------------------ task controls ------------------------------ */

const TASK_FLOW: Record<string, { next: string; label: string; icon: React.ReactNode; variant: "primary" | "soft" }> = {
  pending: { next: "in_progress", label: "Start", icon: <CirclePlay className="h-4 w-4" />, variant: "primary" },
  in_progress: { next: "done", label: "Complete", icon: <CheckCircle2 className="h-4 w-4" />, variant: "primary" },
};

export function TaskStatusControl({
  taskId,
  status,
  compact = false,
}: {
  taskId: string;
  status: string;
  compact?: boolean;
}) {
  const [pending, setPending] = React.useState(false);
  const flow = TASK_FLOW[status];

  async function set(s: string) {
    setPending(true);
    try {
      await setTaskStatus(taskId, s as "pending" | "in_progress" | "done" | "skipped");
    } finally {
      setPending(false);
    }
  }

  if (status === "done") {
    return compact ? null : (
      <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-700">
        <CheckCircle2 className="h-3.5 w-3.5" /> Done
      </span>
    );
  }
  if (status === "skipped") {
    return (
      <button
        onClick={() => set("pending")}
        disabled={pending}
        className="inline-flex items-center gap-1.5 rounded-full bg-paper-deep px-3 py-1 text-xs font-bold text-ink-soft transition-colors hover:text-pine-700"
      >
        <Undo2 className="h-3.5 w-3.5" /> Reopen
      </button>
    );
  }

  return (
    <div className="flex items-center gap-1.5">
      {flow && (
        <Button size={compact ? "sm" : "sm"} variant={flow.variant} disabled={pending} onClick={() => set(flow.next)}>
          {pending ? <Spinner /> : flow.icon}
          {flow.label}
        </Button>
      )}
      {status === "pending" && !compact && (
        <Button size="sm" variant="ghost" disabled={pending} onClick={() => set("skipped")}>
          {pending ? <Spinner /> : <SkipForward className="h-4 w-4" />}
          Skip
        </Button>
      )}
    </div>
  );
}

/* --------------------------- appointment controls -------------------------- */

export function AppointmentControls({
  appointmentId,
  status,
}: {
  appointmentId: string;
  status: string;
}) {
  const [pending, setPending] = React.useState(false);
  if (status !== "scheduled") return null;

  async function set(s: "completed" | "cancelled") {
    setPending(true);
    try {
      await setAppointmentStatus(appointmentId, s);
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="flex items-center gap-1.5">
      <Button size="sm" variant="soft" disabled={pending} onClick={() => set("completed")}>
        {pending ? <Spinner /> : <CheckCircle2 className="h-4 w-4" />}
        Done
      </Button>
      <Button size="sm" variant="ghost" disabled={pending} onClick={() => set("cancelled")}>
        Cancel
      </Button>
    </div>
  );
}

/* ----------------------------- request controls ---------------------------- */

export function AssignCaregiver({
  requestId,
  caregivers,
  currentId,
}: {
  requestId: string;
  caregivers: { id: string; name: string }[];
  currentId: string | null;
}) {
  const [pending, setPending] = React.useState(false);

  return (
    <div className="relative">
      <select
        value={currentId ?? ""}
        disabled={pending}
        onChange={async (e) => {
          if (!e.target.value) return;
          setPending(true);
          try {
            await assignRequest(requestId, e.target.value);
          } finally {
            setPending(false);
          }
        }}
        className="h-10 appearance-none rounded-full border-2 border-line bg-white pr-9 pl-4 text-sm font-bold text-pine-800 transition-colors focus:border-pine-400 focus:outline-none"
        aria-label="Assign caregiver"
      >
        <option value="" disabled>
          Assign caregiver…
        </option>
        {caregivers.map((c) => (
          <option key={c.id} value={c.id}>
            {c.name}
          </option>
        ))}
      </select>
      <span className="pointer-events-none absolute top-1/2 right-3.5 -translate-y-1/2 text-ink-faint">
        {pending ? <Spinner className="h-4 w-4" /> : <ArrowRight className="h-4 w-4" />}
      </span>
    </div>
  );
}

export function RequestStatusButtons({
  requestId,
  status,
}: {
  requestId: string;
  status: string;
}) {
  const [pending, setPending] = React.useState(false);
  async function set(s: "in_progress" | "completed" | "cancelled") {
    setPending(true);
    try {
      await setRequestStatus(requestId, s);
    } finally {
      setPending(false);
    }
  }

  return (
    <div className={cn("flex items-center gap-1.5")}>
      {status === "assigned" && (
        <Button size="sm" variant="soft" disabled={pending} onClick={() => set("in_progress")}>
          {pending ? <Spinner /> : <CirclePlay className="h-4 w-4" />} Start
        </Button>
      )}
      {(status === "assigned" || status === "in_progress") && (
        <Button size="sm" variant="primary" disabled={pending} onClick={() => set("completed")}>
          {pending ? <Spinner /> : <CheckCircle2 className="h-4 w-4" />} Complete
        </Button>
      )}
      {status !== "completed" && status !== "cancelled" && (
        <Button size="sm" variant="ghost" disabled={pending} onClick={() => set("cancelled")}>
          Cancel
        </Button>
      )}
    </div>
  );
}

/* ------------------------------ toggle switch ------------------------------ */

export function MedicationToggle({
  medicationId,
  active,
  onToggle,
}: {
  medicationId: string;
  active: boolean;
  onToggle: (id: string, active: boolean) => Promise<void>;
}) {
  const [pending, setPending] = React.useState(false);
  return (
    <button
      role="switch"
      aria-checked={active}
      disabled={pending}
      onClick={async () => {
        setPending(true);
        try {
          await onToggle(medicationId, !active);
        } finally {
          setPending(false);
        }
      }}
      className={cn(
        "relative h-7 w-12 rounded-full transition-colors disabled:opacity-60",
        active ? "bg-pine-600" : "bg-line",
      )}
    >
      <span
        className={cn(
          "absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all",
          active ? "left-6" : "left-1",
        )}
      />
    </button>
  );
}

export function CaregiverStatusButton({
  caregiverId,
  status,
  onChange,
}: {
  caregiverId: string;
  status: string;
  onChange: (id: string, status: "available" | "on_shift" | "off_duty") => Promise<void>;
}) {
  const [pending, setPending] = React.useState(false);
  const options = [
    { k: "available", l: "Available" },
    { k: "on_shift", l: "On shift" },
    { k: "off_duty", l: "Off duty" },
  ] as const;
  return (
    <div className="inline-flex rounded-full bg-paper-deep p-1">
      {options.map((o) => (
        <button
          key={o.k}
          disabled={pending}
          onClick={async () => {
            setPending(true);
            try {
              await onChange(caregiverId, o.k);
            } finally {
              setPending(false);
            }
          }}
          className={cn(
            "rounded-full px-3 py-1.5 text-xs font-bold transition-all disabled:opacity-60",
            status === o.k ? "bg-pine-700 text-white shadow" : "text-ink-soft hover:text-pine-800",
          )}
        >
          {o.l}
        </button>
      ))}
    </div>
  );
}


