export function Sparkline({
  points,
  width = 240,
  height = 64,
  className = "",
  stroke = "var(--color-pine-600)",
  fill = "var(--color-pine-100)",
}: {
  points: number[];
  width?: number;
  height?: number;
  className?: string;
  stroke?: string;
  fill?: string;
}) {
  if (points.length === 0) {
    return (
      <div
        className={`flex items-center justify-center rounded-2xl bg-paper text-xs font-semibold text-ink-faint ${className}`}
        style={{ width, height }}
      >
        No readings yet
      </div>
    );
  }
  const min = Math.min(...points);
  const max = Math.max(...points);
  const range = max - min || 1;
  const pad = 6;
  const stepX = points.length > 1 ? (width - pad * 2) / (points.length - 1) : 0;
  const coords = points.map((p, i) => ({
    x: points.length > 1 ? pad + i * stepX : width / 2,
    y: pad + (1 - (p - min) / range) * (height - pad * 2),
  }));
  const line = coords.map((c) => `${c.x},${c.y}`).join(" ");
  const area = `${pad},${height - pad} ${line} ${width - pad},${height - pad}`;
  const last = coords[coords.length - 1];

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      className={className}
      role="img"
      aria-label="Trend chart"
    >
      <polygon points={area} fill={fill} opacity={0.55} />
      <polyline
        points={line}
        fill="none"
        stroke={stroke}
        strokeWidth={2.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {coords.map((c, i) => (
        <circle key={i} cx={c.x} cy={c.y} r={i === coords.length - 1 ? 4 : 2} fill={stroke} opacity={i === coords.length - 1 ? 1 : 0.5} />
      ))}
      <circle cx={last.x} cy={last.y} r={7} fill={stroke} opacity={0.18} />
    </svg>
  );
}
