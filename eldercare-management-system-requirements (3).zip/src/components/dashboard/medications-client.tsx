"use client";

import * as React from "react";
import { useFieldArray, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Clock3, Plus, Power, Sparkles, Trash2 } from "lucide-react";
import { z } from "zod";
import { addMedication, toggleMedication } from "@/lib/actions";
import { accent, cn } from "@/lib/utils";
import {
  Avatar,
  Badge,
  Button,
  Card,
  Dialog,
  FieldError,
  Input,
  Label,
  Select,
  Spinner,
  Textarea,
} from "@/components/ui";
import { MedicationToggle } from "@/components/dashboard/widgets";
import type { Medication } from "@/db/schema";

export type MedRow = Medication & { elderName: string; elderAccent: string | null };

const ACCENT_CHOICES = ["pine", "honey", "clay", "sky", "rose", "plum"] as const;

const hhmm = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Use HH:MM");
const medFormSchema = z.object({
  elderId: z.string().min(1, "Choose who this is for"),
  name: z.string().min(2, "Medication name is required"),
  dosage: z.string().min(1, "Dosage is required"),
  instructions: z.string().optional(),
  times: z.array(z.object({ value: hhmm })).min(1, "Add at least one time"),
  prescriber: z.string().optional(),
  accent: z.string().optional(),
});

type FormValues = z.input<typeof medFormSchema>;

function AddMedicationDialog({
  elders,
  open,
  onClose,
}: {
  elders: { id: string; name: string }[];
  open: boolean;
  onClose: () => void;
}) {
  const {
    register,
    control,
    handleSubmit,
    reset,
    watch,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(medFormSchema),
    defaultValues: {
      elderId: elders[0]?.id ?? "",
      name: "",
      dosage: "",
      instructions: "",
      times: [{ value: "08:00" }],
      prescriber: "",
      accent: "pine",
    },
  });
  const { fields, append, remove } = useFieldArray({ control, name: "times" });
  const [serverError, setServerError] = React.useState<string | null>(null);
  const accentValue = watch("accent");

  async function onSubmit(values: FormValues) {
    setServerError(null);
    try {
      await addMedication({
        elderId: values.elderId,
        name: values.name,
        dosage: values.dosage,
        instructions: values.instructions ?? "",
        times: values.times.map((t) => t.value),
        prescriber: values.prescriber ?? "",
        accent: values.accent ?? "pine",
      });
      reset();
      onClose();
    } catch (e) {
      setServerError(e instanceof Error ? e.message : "Something went wrong");
    }
  }

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title="Add medication"
      subtitle="It will appear on today's schedule at the times you set."
      wide
    >
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <Label htmlFor="med-elder">For</Label>
          <Select id="med-elder" {...register("elderId")}>
            {elders.map((e) => (
              <option key={e.id} value={e.id}>
                {e.name}
              </option>
            ))}
          </Select>
          <FieldError message={errors.elderId?.message} />
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <Label htmlFor="med-name">Medication</Label>
            <Input id="med-name" placeholder="e.g. Donepezil" {...register("name")} />
            <FieldError message={errors.name?.message} />
          </div>
          <div>
            <Label htmlFor="med-dosage">Dosage</Label>
            <Input id="med-dosage" placeholder="e.g. 10 mg · 1 tablet" {...register("dosage")} />
            <FieldError message={errors.dosage?.message} />
          </div>
        </div>

        <div>
          <Label>Dose times</Label>
          <div className="space-y-2">
            {fields.map((field, i) => (
              <div key={field.id} className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Clock3 className="pointer-events-none absolute top-1/2 left-4 h-4 w-4 -translate-y-1/2 text-ink-faint" />
                  <Input type="time" className="pl-11" {...register(`times.${i}.value`)} />
                </div>
                {fields.length > 1 && (
                  <button
                    type="button"
                    onClick={() => remove(i)}
                    aria-label="Remove time"
                    className="rounded-full p-2.5 text-ink-faint transition-colors hover:bg-clay-50 hover:text-clay-500"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
          {fields.length < 4 && (
            <button
              type="button"
              onClick={() => append({ value: "20:00" })}
              className="mt-2 inline-flex items-center gap-1.5 text-sm font-bold text-pine-700 hover:text-pine-900"
            >
              <Plus className="h-4 w-4" /> Add another time
            </button>
          )}
          <FieldError message={(errors.times as { message?: string } | undefined)?.message} />
        </div>

        <div>
          <Label htmlFor="med-instructions">Instructions</Label>
          <Textarea
            id="med-instructions"
            placeholder="e.g. Take with breakfast and a full glass of water"
            {...register("instructions")}
          />
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <Label htmlFor="med-prescriber">Prescriber (optional)</Label>
            <Input id="med-prescriber" placeholder="Dr. Okafor" {...register("prescriber")} />
          </div>
          <div>
            <Label>Label color</Label>
            <div className="flex gap-2 pt-1.5">
              {ACCENT_CHOICES.map((c) => {
                const a = accent(c);
                return (
                  <button
                    key={c}
                    type="button"
                    aria-label={c}
                    onClick={() => setValue("accent", c)}
                    className={cn(
                      "h-9 w-9 rounded-full transition-all",
                      a.bg,
                      accentValue === c ? "ring-4 ring-pine-200 scale-110" : "opacity-60 hover:opacity-100",
                    )}
                  />
                );
              })}
            </div>
          </div>
        </div>

        {serverError && (
          <p className="rounded-2xl bg-clay-50 px-4 py-3 text-sm font-semibold text-clay-600">
            {serverError}
          </p>
        )}

        <div className="flex justify-end gap-3 pt-2">
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? <Spinner /> : <Plus className="h-5 w-5" />}
            Add medication
          </Button>
        </div>
      </form>
    </Dialog>
  );
}

export function MedicationsHeader({
  elders,
  activeCount,
}: {
  elders: { id: string; name: string }[];
  activeCount: number;
}) {
  const [open, setOpen] = React.useState(false);
  return (
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className="text-sm font-semibold text-ink-soft">
          {activeCount} active medication{activeCount === 1 ? "" : "s"} across the care circle
        </p>
        <h2 className="mt-1 font-display text-3xl font-semibold tracking-tight text-pine-900 sm:text-4xl">
          Medications &amp; doses
        </h2>
      </div>
      <Button size="lg" onClick={() => setOpen(true)}>
        <Plus className="h-5 w-5" />
        Add medication
      </Button>
      <AddMedicationDialog elders={elders} open={open} onClose={() => setOpen(false)} />
    </div>
  );
}

export function MedicationCard({ med }: { med: MedRow }) {
  const a = accent(med.accent);
  return (
    <Card className={cn("p-5 transition-opacity", !med.active && "opacity-60")}>
      <div className="flex items-start gap-4">
        <span className={cn("flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl", a.soft, a.text)}>
          <Sparkles className="h-5 w-5" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="font-display text-lg font-semibold text-pine-900">{med.name}</h3>
            {!med.active && <Badge tone="neutral">Paused</Badge>}
          </div>
          <p className="mt-0.5 text-sm font-semibold text-ink-soft">{med.dosage}</p>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {(med.times as string[]).map((t) => (
              <span
                key={t}
                className="inline-flex items-center gap-1 rounded-full bg-paper-deep px-2.5 py-1 text-xs font-bold text-ink"
              >
                <Clock3 className="h-3 w-3" />
                {t}
              </span>
            ))}
          </div>
          {med.instructions && (
            <p className="mt-2.5 text-xs leading-relaxed text-ink-soft">{med.instructions}</p>
          )}
        </div>
        <MedicationToggle medicationId={med.id} active={med.active} onToggle={toggleMedication} />
      </div>
      <div className="mt-4 flex items-center justify-between border-t border-line/60 pt-3.5">
        <span className="inline-flex items-center gap-2 text-xs font-bold text-pine-700">
          <Avatar name={med.elderName} accentKey={med.elderAccent} size="sm" className="h-6 w-6 text-[9px] ring-2" />
          {med.elderName}
        </span>
        {med.prescriber ? (
          <span className="text-xs text-ink-faint">Rx · {med.prescriber}</span>
        ) : (
          <span className="inline-flex items-center gap-1 text-xs text-ink-faint">
            <Power className="h-3 w-3" /> Daily
          </span>
        )}
      </div>
    </Card>
  );
}
