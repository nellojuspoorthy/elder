"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { CalendarPlus, Plus } from "lucide-react";
import { z } from "zod";
import { addDays, format } from "date-fns";
import { bookAppointment } from "@/lib/actions";
import { appointmentSchema } from "@/lib/schemas";
import {
  Button,
  Dialog,
  FieldError,
  Input,
  Label,
  Select,
  Spinner,
  Textarea,
} from "@/components/ui";

type FormValues = z.input<typeof appointmentSchema>;

const TYPES = ["Checkup", "Follow-up", "Lab work", "Specialist", "Dental", "Vision", "Physiotherapy"];

export function BookAppointmentDialog({
  elders,
  doctors,
}: {
  elders: { id: string; name: string }[];
  doctors: { id: string; name: string; specialty: string; clinic: string }[];
}) {
  const [open, setOpen] = React.useState(false);
  const [serverError, setServerError] = React.useState<string | null>(null);
  const {
    register,
    handleSubmit,
    reset,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(appointmentSchema),
    defaultValues: {
      elderId: elders[0]?.id ?? "",
      doctorId: doctors[0]?.id ?? "",
      date: format(addDays(new Date(), 1), "yyyy-MM-dd"),
      time: "10:00",
      type: "Checkup",
      location: "",
      reason: "",
    },
  });

  const doctorId = watch("doctorId");
  const doctor = doctors.find((d) => d.id === doctorId);

  async function onSubmit(values: FormValues) {
    setServerError(null);
    try {
      await bookAppointment(values);
      reset();
      setOpen(false);
    } catch (e) {
      setServerError(
        e instanceof z.ZodError
          ? e.issues[0]?.message ?? "Please review the form"
          : e instanceof Error
            ? e.message
            : "Something went wrong",
      );
    }
  }

  return (
    <>
      <Button size="lg" onClick={() => setOpen(true)}>
        <Plus className="h-5 w-5" />
        Book appointment
      </Button>
      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title="Book an appointment"
        subtitle="The visit appears in everyone's schedule straight away."
        wide
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="appt-elder">Who is the visit for?</Label>
              <Select id="appt-elder" {...register("elderId")}>
                {elders.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name}
                  </option>
                ))}
              </Select>
              <FieldError message={errors.elderId?.message} />
            </div>
            <div>
              <Label htmlFor="appt-type">Visit type</Label>
              <Select id="appt-type" {...register("type")}>
                {TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </Select>
              <FieldError message={errors.type?.message} />
            </div>
          </div>

          <div>
            <Label htmlFor="appt-doctor">Doctor</Label>
            <Select id="appt-doctor" {...register("doctorId")}>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} — {d.specialty} · {d.clinic}
                </option>
              ))}
            </Select>
            <FieldError message={errors.doctorId?.message} />
            {doctor && (
              <Input
                className="mt-3"
                placeholder="Location / room (optional)"
                defaultValue={doctor.clinic}
                {...register("location")}
              />
            )}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="appt-date">Date</Label>
              <Input
                id="appt-date"
                type="date"
                min={format(new Date(), "yyyy-MM-dd")}
                {...register("date")}
              />
              <FieldError message={errors.date?.message} />
            </div>
            <div>
              <Label htmlFor="appt-time">Time</Label>
              <Input id="appt-time" type="time" {...register("time")} />
              <FieldError message={errors.time?.message} />
            </div>
          </div>

          <div>
            <Label htmlFor="appt-reason">Reason (optional)</Label>
            <Textarea
              id="appt-reason"
              placeholder="e.g. Annual heart review, bring medication list"
              {...register("reason")}
            />
          </div>

          {serverError && (
            <p className="rounded-2xl bg-clay-50 px-4 py-3 text-sm font-semibold text-clay-600">
              {serverError}
            </p>
          )}

          <div className="flex justify-end gap-3 pt-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? <Spinner /> : <CalendarPlus className="h-5 w-5" />}
              Confirm booking
            </Button>
          </div>
        </form>
      </Dialog>
    </>
  );
}
