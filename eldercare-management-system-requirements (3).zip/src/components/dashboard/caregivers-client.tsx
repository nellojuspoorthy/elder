"use client";

import * as React from "react";
import { HandHeart, Plus } from "lucide-react";
import { z } from "zod";
import { format, addDays } from "date-fns";
import { requestCare } from "@/lib/actions";
import {
  Button,
  Dialog,
  FieldError,
  Input,
  Label,
  Select,
  Spinner,
  Textarea,
} from "@/components/ui";

const SERVICES = [
  "Daily living assistance",
  "Companionship visit",
  "Meal preparation",
  "Mobility & walk support",
  "Medication supervision",
  "Housekeeping",
  "Transport to appointment",
  "Overnight care",
];

const hhmm = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Use HH:MM");
const formSchema = z.object({
  elderId: z.string().min(1, "Choose who the care is for"),
  serviceType: z.string().min(2, "Choose a service"),
  date: z.string().min(1, "Pick a date"),
  time: hhmm,
  details: z.string().optional(),
});

type FormValues = z.input<typeof formSchema>;

export function RequestCareDialog({
  elders,
  label = "Request care",
}: {
  elders: { id: string; name: string }[];
  label?: string;
}) {
  const [open, setOpen] = React.useState(false);
  const [serverError, setServerError] = React.useState<string | null>(null);
  const [values, setValues] = React.useState<FormValues>({
    elderId: elders[0]?.id ?? "",
    serviceType: SERVICES[0],
    date: format(addDays(new Date(), 1), "yyyy-MM-dd"),
    time: "09:00",
    details: "",
  });
  const [errors, setErrors] = React.useState<Record<string, string>>({});
  const [pending, setPending] = React.useState(false);

  function set<K extends keyof FormValues>(k: K, v: FormValues[K]) {
    setValues((s) => ({ ...s, [k]: v }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setServerError(null);
    const parsed = formSchema.safeParse(values);
    if (!parsed.success) {
      const map: Record<string, string> = {};
      for (const issue of parsed.error.issues) map[String(issue.path[0])] = issue.message;
      setErrors(map);
      return;
    }
    setErrors({});
    setPending(true);
    try {
      await requestCare({
        elderId: parsed.data.elderId,
        serviceType: parsed.data.serviceType,
        details: parsed.data.details ?? "",
        preferredAt: `${parsed.data.date}T${parsed.data.time}:00`,
      });
      setOpen(false);
    } catch (err) {
      setServerError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setPending(false);
    }
  }

  return (
    <>
      <Button size="lg" variant="honey" onClick={() => setOpen(true)}>
        <Plus className="h-5 w-5" />
        {label}
      </Button>
      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title="Request a care visit"
        subtitle="An administrator matches the request with the best-fit caregiver."
        wide
      >
        <form onSubmit={submit} className="space-y-4">
          <div>
            <Label htmlFor="req-elder">Who needs care?</Label>
            <Select
              id="req-elder"
              value={values.elderId}
              onChange={(e) => set("elderId", e.target.value)}
            >
              {elders.map((el) => (
                <option key={el.id} value={el.id}>
                  {el.name}
                </option>
              ))}
            </Select>
            <FieldError message={errors.elderId} />
          </div>

          <div>
            <Label htmlFor="req-service">Type of care</Label>
            <Select
              id="req-service"
              value={values.serviceType}
              onChange={(e) => set("serviceType", e.target.value)}
            >
              {SERVICES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </Select>
            <FieldError message={errors.serviceType} />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="req-date">Preferred date</Label>
              <Input
                id="req-date"
                type="date"
                min={format(new Date(), "yyyy-MM-dd")}
                value={values.date}
                onChange={(e) => set("date", e.target.value)}
              />
              <FieldError message={errors.date} />
            </div>
            <div>
              <Label htmlFor="req-time">Preferred time</Label>
              <Input
                id="req-time"
                type="time"
                value={values.time}
                onChange={(e) => set("time", e.target.value)}
              />
              <FieldError message={errors.time} />
            </div>
          </div>

          <div>
            <Label htmlFor="req-details">Anything we should know? (optional)</Label>
            <Textarea
              id="req-details"
              placeholder="e.g. Please bring the walker from the garage; Dad tires easily after lunch."
              value={values.details ?? ""}
              onChange={(e) => set("details", e.target.value)}
            />
          </div>

          {serverError && (
            <p className="rounded-2xl bg-clay-50 px-4 py-3 text-sm font-semibold text-clay-600">
              {serverError}
            </p>
          )}

          <div className="flex justify-end gap-3 pt-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={pending}>
              {pending ? <Spinner /> : <HandHeart className="h-5 w-5" />}
              Send request
            </Button>
          </div>
        </form>
      </Dialog>
    </>
  );
}
