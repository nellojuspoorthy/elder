"use client";

import * as React from "react";
import Link from "next/link";
import {
  Activity as ActivityIcon,
  ArrowRight,
  ArrowUpRight,
  CalendarCheck2,
  CheckCircle2,
  ClipboardList,
  Clock3,
  HeartHandshake,
  MapPin,
  Pill,
  Siren,
  Sparkles,
  Stethoscope,
} from "lucide-react";
import { format } from "date-fns";
import { accent, cn, timeOfDayLabel } from "@/lib/utils";
import { useRole } from "@/components/role";
import { Avatar, Badge, Card, SectionTitle } from "@/components/ui";
import { DoseActions, DoseBadge, type DoseState } from "@/components/dashboard/dose";
import { AlertActions, TaskStatusControl } from "@/components/dashboard/widgets";
import type {
  Activity,
  Caregiver,
  Elder,
} from "@/db/schema";
import type { TodayDose } from "@/lib/queries";

type Dose = TodayDose & { elderName?: string; elderAccent?: string | null };

type Appt = {
  id: string;
  scheduledAt: Date;
  type: string;
  location: string | null;
  status: string;
  elderId: string;
  elderName: string;
  elderAccent: string | null;
  doctorName: string;
  doctorSpecialty: string;
  clinic: string;
};

export type TaskRow = {
  id: string;
  title: string;
  category: string | null;
  scheduledFor: Date;
  window: string | null;
  priority: string | null;
  status: string;
  elderName: string;
  elderAccent: string | null;
  caregiverName: string | null;
};

export type AlertRow = {
  id: string;
  type: string;
  note: string | null;
  status: "active" | "acknowledged" | "resolved";
  createdAt: Date;
  elderName: string;
  elderAccent: string | null;
  emergencyContactName: string | null;
  emergencyContactPhone: string | null;
};

export type OverviewData = {
  elders: Elder[];
  todayDoses: Dose[];
  upcomingAppointments: Appt[];
  todaysTasks: TaskRow[];
  activeAlerts: AlertRow[];
  feed: Activity[];
  caregivers: Caregiver[];
  openRequestsCount: number;
};

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 18) return "Good afternoon";
  return "Good evening";
}

const KIND_STYLE: Record<string, { cls: string }> = {
  medication: { cls: "bg-honey-100 text-honey-600" },
  appointment: { cls: "bg-sky-100 text-sky-700" },
  alert: { cls: "bg-clay-100 text-clay-500" },
  task: { cls: "bg-pine-100 text-pine-700" },
  request: { cls: "bg-emerald-100 text-emerald-700" },
  health: { cls: "bg-rose-100 text-rose-600" },
  info: { cls: "bg-paper-deep text-ink-soft" },
};

/* ------------------------------ shared blocks ------------------------------ */

function AlertsPanel({ alerts }: { alerts: AlertRow[] }) {
  if (alerts.length === 0) return null;
  return (
    <section aria-label="Active alerts" className="space-y-3">
      {alerts.map((a) => (
        <div
          key={a.id}
          className={cn(
            "flex flex-col gap-4 rounded-3xl border-2 p-5 sm:flex-row sm:items-center",
            a.status === "active"
              ? "border-clay-500/60 bg-clay-50"
              : "border-honey-300/70 bg-honey-50",
          )}
        >
          <div className="flex min-w-0 flex-1 items-center gap-4">
            <span
              className={cn(
                "flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl text-white",
                a.status === "active" ? "bg-clay-500 animate-pulse-ring" : "bg-honey-500",
              )}
            >
              <Siren className="h-6 w-6" />
            </span>
            <div className="min-w-0">
              <p className="font-display text-lg leading-tight font-semibold text-pine-900">
                {a.elderName} needs assistance
                <span className="ml-2 align-middle">
                  <Badge tone={a.status === "active" ? "clay" : "honey"} dot>
                    {a.status === "active" ? "Active" : "Responding"}
                  </Badge>
                </span>
              </p>
              <p className="mt-0.5 text-sm text-ink-soft">
                {a.type === "fall" ? "Fall detected" : a.type === "medical" ? "Medical assistance" : "Assistance requested"}{" "}
                · {format(new Date(a.createdAt), "h:mm a")}
                {a.emergencyContactName && (
                  <> · Contact: {a.emergencyContactName} {a.emergencyContactPhone}</>
                )}
              </p>
            </div>
          </div>
          <AlertActions alertId={a.id} status={a.status} />
        </div>
      ))}
    </section>
  );
}

export function DoseList({
  doses,
  large = false,
  showElder = true,
}: {
  doses: Dose[];
  large?: boolean;
  showElder?: boolean;
}) {
  if (doses.length === 0) {
    return (
      <p className="rounded-2xl bg-pine-50 px-5 py-6 text-center text-sm font-semibold text-pine-700">
        <Sparkles className="mr-2 inline h-4 w-4" />
        No medication scheduled today.
      </p>
    );
  }
  return (
    <ul className="divide-y divide-line/70">
      {doses.map((d) => {
        const a = accent(d.medication.accent);
        return (
          <li
            key={d.key}
            className={cn(
              "flex items-center gap-4 py-4 first:pt-0 last:pb-0",
              large && "py-5",
            )}
          >
            <div
              className={cn(
                "flex shrink-0 flex-col items-center justify-center rounded-2xl font-bold",
                large ? "h-16 w-16" : "h-13 w-13",
                a.soft,
                a.text,
              )}
            >
              <span className={cn(large ? "text-lg" : "text-sm")}>{d.time}</span>
              <span className="text-[10px] tracking-wide uppercase opacity-70">
                {timeOfDayLabel(d.time).slice(0, 4)}
              </span>
            </div>
            <div className="min-w-0 flex-1">
              <p className={cn("truncate font-bold text-pine-900", large ? "text-xl" : "text-[15px]")}>
                {d.medication.name}
                <span className="ml-2 font-semibold text-ink-soft">{d.medication.dosage}</span>
              </p>
              <p className="mt-0.5 flex flex-wrap items-center gap-x-2 text-xs text-ink-soft">
                {showElder && d.elderName && (
                  <>
                    <span className="font-semibold text-pine-700">{d.elderName}</span>
                    <span aria-hidden>·</span>
                  </>
                )}
                <span className="truncate">{d.medication.instructions || "As prescribed"}</span>
              </p>
            </div>
            <div className="hidden sm:block">
              <DoseBadge state={d.state as DoseState} />
            </div>
            <DoseActions
              medicationId={d.medication.id}
              scheduledFor={d.scheduledFor}
              state={d.state as DoseState}
              large={large}
            />
          </li>
        );
      })}
    </ul>
  );
}

function TaskList({ tasks, showCaregiver = true }: { tasks: TaskRow[]; showCaregiver?: boolean }) {
  if (tasks.length === 0) {
    return (
      <p className="rounded-2xl bg-pine-50 px-5 py-6 text-center text-sm font-semibold text-pine-700">
        All clear — no tasks scheduled today.
      </p>
    );
  }
  return (
    <ul className="space-y-3">
      {tasks.map((t) => (
        <li
          key={t.id}
          className={cn(
            "flex flex-col gap-3 rounded-2xl border-2 p-4 transition-colors sm:flex-row sm:items-center",
            t.status === "done"
              ? "border-line/50 bg-paper opacity-70"
              : "border-line/70 bg-white",
          )}
        >
          <div className="flex min-w-0 flex-1 items-center gap-3.5">
            <span
              className={cn(
                "flex h-11 w-11 shrink-0 items-center justify-center rounded-xl",
                t.status === "done"
                  ? "bg-emerald-100 text-emerald-600"
                  : t.priority === "high"
                    ? "bg-clay-100 text-clay-500"
                    : "bg-pine-100 text-pine-700",
              )}
            >
              {t.status === "done" ? <CheckCircle2 className="h-5 w-5" /> : <ClipboardList className="h-5 w-5" />}
            </span>
            <div className="min-w-0">
              <p className={cn("truncate font-bold text-pine-900", t.status === "done" && "line-through")}>
                {t.title}
              </p>
              <p className="mt-0.5 flex flex-wrap items-center gap-x-2 text-xs text-ink-soft">
                <span className="font-semibold text-pine-700">{t.elderName}</span>
                <span aria-hidden>·</span>
                <span>{format(new Date(t.scheduledFor), "h:mm a")}</span>
                <span aria-hidden>·</span>
                <span className="capitalize">{t.category}</span>
                {showCaregiver && t.caregiverName && (
                  <>
                    <span aria-hidden>·</span>
                    <span className="inline-flex items-center gap-1">
                      <Stethoscope className="h-3 w-3" />
                      {t.caregiverName}
                    </span>
                  </>
                )}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 pl-14 sm:pl-0">
            {t.priority === "high" && t.status !== "done" && <Badge tone="clay">Priority</Badge>}
            <TaskStatusControl taskId={t.id} status={t.status} compact />
            {(t.status === "pending" || t.status === "in_progress") && (
              <TaskStatusControl taskId={t.id} status={t.status} />
            )}
          </div>
        </li>
      ))}
    </ul>
  );
}

export function AppointmentCards({ appts, limit }: { appts: Appt[]; limit?: number }) {
  const list = typeof limit === "number" ? appts.slice(0, limit) : appts;
  if (list.length === 0) {
    return (
      <p className="rounded-2xl bg-pine-50 px-5 py-6 text-center text-sm font-semibold text-pine-700">
        No upcoming appointments.
      </p>
    );
  }
  return (
    <ul className="space-y-4">
      {list.map((a) => (
        <li key={a.id} className="rounded-2xl border-2 border-line/70 bg-white p-4">
          <div className="flex items-start gap-3.5">
            <div className="flex h-13 w-13 shrink-0 flex-col items-center justify-center rounded-2xl bg-sky-100 font-bold text-sky-700">
              <span className="text-lg leading-none">{format(new Date(a.scheduledAt), "d")}</span>
              <span className="text-[10px] tracking-wide uppercase">{format(new Date(a.scheduledAt), "MMM")}</span>
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate font-bold text-pine-900">{a.doctorName}</p>
              <p className="text-xs font-semibold text-sky-700">{a.doctorSpecialty}</p>
              <p className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-ink-soft">
                <span className="inline-flex items-center gap-1 font-semibold text-pine-700">
                  <Avatar name={a.elderName} accentKey={a.elderAccent} size="sm" className="h-5 w-5 text-[8px] ring-2" />
                  {a.elderName}
                </span>
                <span className="inline-flex items-center gap-1">
                  <Clock3 className="h-3 w-3" />
                  {format(new Date(a.scheduledAt), "EEE · h:mm a")}
                </span>
              </p>
            </div>
          </div>
        </li>
      ))}
    </ul>
  );
}

function ActivityFeed({ feed }: { feed: Activity[] }) {
  return (
    <ul className="space-y-4">
      {feed.map((f) => {
        const style = KIND_STYLE[f.kind] ?? KIND_STYLE.info;
        return (
          <li key={f.id} className="flex gap-3">
            <span className={cn("mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full", style.cls)}>
              <ActivityIcon className="h-3.5 w-3.5" />
            </span>
            <div className="min-w-0">
              <p className="text-sm leading-snug font-medium text-ink">{f.summary}</p>
              <p className="mt-0.5 text-xs text-ink-faint">
                {f.actor} · {format(new Date(f.createdAt), "MMM d, h:mm a")}
              </p>
            </div>
          </li>
        );
      })}
    </ul>
  );
}

/* -------------------------------- elder view ------------------------------- */

function ElderView({ data }: { data: OverviewData }) {
  const me = data.elders[0];
  const myDoses = data.todayDoses.filter((d) => d.medication.elderId === me?.id);
  const myAppt = data.upcomingAppointments.find((a) => a.elderId === me?.id);
  const taken = myDoses.filter((d) => d.state === "taken").length;

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <Card className="relative overflow-hidden p-8 sm:p-10">
        <div aria-hidden className="absolute -top-16 -right-16 h-48 w-48 rounded-full bg-honey-100 blur-2xl" />
        <p className="text-lg font-semibold text-ink-soft">
          {format(new Date(), "EEEE, MMMM d")}
        </p>
        <h2 className="mt-2 font-display text-4xl font-semibold tracking-tight text-pine-900 sm:text-5xl">
          {greeting()}, {me?.name.split(" ")[0] ?? "there"}
        </h2>
        <p className="mt-4 max-w-md text-lg leading-relaxed text-ink-soft">
          {myDoses.length === 0
            ? "You have no medicine scheduled today. Enjoy your day!"
            : taken === myDoses.length && myDoses.length > 0
              ? "Wonderful — all of today's medicine is done."
              : `You have ${myDoses.length - taken} medicine${myDoses.length - taken === 1 ? "" : "s"} left to take today.`}
        </p>
        {myDoses.length > 0 && (
          <div className="mt-6 h-3 overflow-hidden rounded-full bg-paper-deep">
            <div
              className="h-full rounded-full bg-pine-600 transition-all duration-700"
              style={{ width: `${(taken / Math.max(1, myDoses.length)) * 100}%` }}
            />
          </div>
        )}
      </Card>

      <section>
        <h3 className="mb-4 flex items-center gap-2.5 font-display text-2xl font-semibold text-pine-900">
          <Pill className="h-6 w-6 text-honey-500" />
          Today&apos;s medicine
        </h3>
        <Card className="p-5 sm:p-7">
          <DoseList doses={myDoses} large showElder={false} />
        </Card>
      </section>

      {myAppt && (
        <section>
          <h3 className="mb-4 flex items-center gap-2.5 font-display text-2xl font-semibold text-pine-900">
            <CalendarCheck2 className="h-6 w-6 text-sky-500" />
            Your next visit
          </h3>
          <Card className="flex flex-col gap-5 p-6 sm:flex-row sm:items-center sm:p-7">
            <div className="flex h-20 w-20 shrink-0 flex-col items-center justify-center rounded-3xl bg-sky-100 font-bold text-sky-700">
              <span className="text-3xl leading-none">{format(new Date(myAppt.scheduledAt), "d")}</span>
              <span className="text-xs tracking-wide uppercase">{format(new Date(myAppt.scheduledAt), "MMM")}</span>
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-display text-2xl font-semibold text-pine-900">{myAppt.doctorName}</p>
              <p className="mt-0.5 font-semibold text-sky-700">{myAppt.doctorSpecialty} · {myAppt.type}</p>
              <p className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[15px] text-ink-soft">
                <span className="inline-flex items-center gap-1.5">
                  <Clock3 className="h-4 w-4" />
                  {format(new Date(myAppt.scheduledAt), "EEEE 'at' h:mm a")}
                </span>
                {myAppt.location && (
                  <span className="inline-flex items-center gap-1.5">
                    <MapPin className="h-4 w-4" />
                    {myAppt.location}
                  </span>
                )}
              </p>
            </div>
          </Card>
        </section>
      )}

      <Card className="flex items-center gap-5 border-clay-100 bg-clay-50 p-6 sm:p-7">
        <span className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-clay-500 text-white animate-pulse-ring">
          <Siren className="h-8 w-8" />
        </span>
        <div>
          <p className="font-display text-2xl font-semibold text-pine-900">Need help right away?</p>
          <p className="mt-1 text-[15px] leading-relaxed text-ink-soft">
            Press the red <strong className="text-clay-600">Emergency assist</strong> button in the menu.
            Your family and caregiver will be alerted immediately.
          </p>
        </div>
      </Card>
    </div>
  );
}

/* ----------------------------- monitoring view ----------------------------- */

function StatCard({
  icon,
  label,
  value,
  sub,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub?: string;
  tone: string;
}) {
  return (
    <Card className="flex items-center gap-4 p-5">
      <span className={cn("flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl", tone)}>
        {icon}
      </span>
      <div className="min-w-0">
        <p className="font-display text-2xl leading-none font-semibold text-pine-900">{value}</p>
        <p className="mt-1.5 truncate text-xs font-bold tracking-wide text-ink-soft uppercase">{label}</p>
        {sub && <p className="text-xs text-ink-faint">{sub}</p>}
      </div>
    </Card>
  );
}

function MonitorView({ data, roleLabel }: { data: OverviewData; roleLabel: string }) {
  const taken = data.todayDoses.filter((d) => d.state === "taken").length;
  const total = data.todayDoses.length;
  const openTasks = data.todaysTasks.filter((t) => t.status !== "done" && t.status !== "skipped").length;
  const caregiverFirst = roleLabel === "caregiver";

  return (
    <div className="mx-auto max-w-6xl space-y-7">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-semibold text-ink-soft">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
          <h2 className="mt-1 font-display text-3xl font-semibold tracking-tight text-pine-900 sm:text-4xl">
            {greeting()}
            {roleLabel === "family" && ", the circle is up to date"}
            {roleLabel === "caregiver" && ", here is today at a glance"}
            {roleLabel === "admin" && ", operations overview"}
          </h2>
        </div>
        <Link href="/dashboard/elders" className="inline-flex items-center gap-2 text-sm font-bold text-pine-700 hover:text-pine-900">
          View care profiles <ArrowRight className="h-4 w-4" />
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          icon={<Pill className="h-5 w-5" />}
          tone="bg-honey-100 text-honey-600"
          label="Doses today"
          value={`${taken}/${total}`}
          sub={total - taken > 0 ? `${total - taken} remaining` : "All done"}
        />
        <StatCard
          icon={<CalendarCheck2 className="h-5 w-5" />}
          tone="bg-sky-100 text-sky-700"
          label="Upcoming visits"
          value={String(data.upcomingAppointments.length)}
          sub="scheduled"
        />
        <StatCard
          icon={<ClipboardList className="h-5 w-5" />}
          tone="bg-pine-100 text-pine-700"
          label="Tasks today"
          value={String(data.todaysTasks.length)}
          sub={openTasks > 0 ? `${openTasks} open` : "All complete"}
        />
        <StatCard
          icon={<Siren className="h-5 w-5" />}
          tone={data.activeAlerts.length > 0 ? "bg-clay-100 text-clay-500" : "bg-emerald-100 text-emerald-600"}
          label="Active alerts"
          value={String(data.activeAlerts.length)}
          sub={data.activeAlerts.length ? "Needs attention" : "All calm"}
        />
      </div>

      <AlertsPanel alerts={data.activeAlerts} />

      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <div className="space-y-6">
          {!caregiverFirst && (
            <Card className="p-5 sm:p-6">
              <div className="mb-4 flex items-center justify-between">
                <SectionTitle kicker="Today" title="Medication schedule" />
                <Link href="/dashboard/medications" className="inline-flex items-center gap-1 text-xs font-bold text-pine-700 hover:text-pine-900">
                  All medications <ArrowUpRight className="h-3.5 w-3.5" />
                </Link>
              </div>
              <DoseList doses={data.todayDoses} />
            </Card>
          )}

          <Card className="p-5 sm:p-6">
            <div className="mb-4 flex items-center justify-between">
              <SectionTitle kicker="Today" title="Care tasks" />
              <Link href="/dashboard/tasks" className="inline-flex items-center gap-1 text-xs font-bold text-pine-700 hover:text-pine-900">
                Task board <ArrowUpRight className="h-3.5 w-3.5" />
              </Link>
            </div>
            <TaskList tasks={data.todaysTasks} />
          </Card>

          {caregiverFirst && (
            <Card className="p-5 sm:p-6">
              <div className="mb-4 flex items-center justify-between">
                <SectionTitle kicker="Today" title="Medication schedule" />
                <Link href="/dashboard/medications" className="inline-flex items-center gap-1 text-xs font-bold text-pine-700 hover:text-pine-900">
                  All medications <ArrowUpRight className="h-3.5 w-3.5" />
                </Link>
              </div>
              <DoseList doses={data.todayDoses} />
            </Card>
          )}
        </div>

        <div className="space-y-6">
          <Card className="p-5 sm:p-6">
            <div className="mb-4 flex items-center justify-between">
              <SectionTitle kicker="Coming up" title="Appointments" />
              <Link href="/dashboard/appointments" className="inline-flex items-center gap-1 text-xs font-bold text-pine-700 hover:text-pine-900">
                Book <ArrowUpRight className="h-3.5 w-3.5" />
              </Link>
            </div>
            <AppointmentCards appts={data.upcomingAppointments} limit={3} />
          </Card>

          <Card className="p-5 sm:p-6">
            <div className="mb-4 flex items-center justify-between">
              <SectionTitle kicker="Live" title="Care circle activity" />
              <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-600">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
                </span>
                Live
              </span>
            </div>
            <ActivityFeed feed={data.feed.slice(0, 7)} />
          </Card>

          <Card className="flex items-center gap-4 bg-pine-800 p-5 text-white sm:p-6">
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white/10">
              <HeartHandshake className="h-6 w-6 text-honey-300" />
            </span>
            <div>
              <p className="font-display text-lg font-semibold">
                {data.elders.length} loved ones · {data.caregivers.length} caregivers
              </p>
              <p className="text-sm text-pine-100/75">
                {data.openRequestsCount} service request{data.openRequestsCount === 1 ? "" : "s"} in progress
              </p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

export function OverviewClient({ data }: { data: OverviewData }) {
  const { role } = useRole();
  if (role === "elder") return <ElderView data={data} />;
  return <MonitorView data={data} roleLabel={role} />;
}
