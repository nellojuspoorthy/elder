"use client";

import * as React from "react";
import { Activity, Plus, UserPlus } from "lucide-react";
import { z } from "zod";
import { addElder, addVital } from "@/lib/actions";
import {
  Button,
  Dialog,
  FieldError,
  Input,
  Label,
  Select,
  Spinner,
  Textarea,
} from "@/components/ui";
import { cn } from "@/lib/utils";

/* ------------------------------ add elder ---------------------------------- */

const elderFormSchema = z.object({
  name: z.string().min(2, "Name is required"),
  age: z.coerce.number().int().min(50, "Age must be 50 or above").max(120),
  gender: z.string(),
  address: z.string().optional(),
  conditions: z.string().optional(),
  allergies: z.string().optional(),
  bloodType: z.string().optional(),
  mobility: z.string(),
  emergencyContactName: z.string().optional(),
  emergencyContactPhone: z.string().optional(),
  notes: z.string().optional(),
});

type ElderFormValues = z.input<typeof elderFormSchema>;

const ACCENTS = ["pine", "honey", "clay", "sky", "rose", "plum"] as const;
const ACCENT_BG: Record<string, string> = {
  pine: "bg-pine-700",
  honey: "bg-honey-500",
  clay: "bg-clay-500",
  sky: "bg-sky-500",
  rose: "bg-rose-500",
  plum: "bg-purple-600",
};

export function AddElderDialog() {
  const [open, setOpen] = React.useState(false);
  const [serverError, setServerError] = React.useState<string | null>(null);
  const [pending, setPending] = React.useState(false);
  const [errors, setErrors] = React.useState<Record<string, string>>({});
  const [accentChoice, setAccentChoice] = React.useState<string>("pine");
  const [values, setValues] = React.useState<ElderFormValues>({
    name: "",
    age: 78,
    gender: "female",
    address: "",
    conditions: "",
    allergies: "",
    bloodType: "",
    mobility: "independent",
    emergencyContactName: "",
    emergencyContactPhone: "",
    notes: "",
  });

  function set<K extends keyof ElderFormValues>(k: K, v: ElderFormValues[K]) {
    setValues((s) => ({ ...s, [k]: v }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setServerError(null);
    const parsed = elderFormSchema.safeParse(values);
    if (!parsed.success) {
      const map: Record<string, string> = {};
      for (const issue of parsed.error.issues) map[String(issue.path[0])] = issue.message;
      setErrors(map);
      return;
    }
    setErrors({});
    setPending(true);
    try {
      await addElder({ ...parsed.data, mobility: parsed.data.mobility ?? "independent", accent: accentChoice });
      setOpen(false);
      setValues((s) => ({ ...s, name: "", conditions: "", allergies: "", address: "", notes: "" }));
    } catch (err) {
      setServerError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setPending(false);
    }
  }

  return (
    <>
      <Button size="lg" onClick={() => setOpen(true)}>
        <UserPlus className="h-5 w-5" />
        New care profile
      </Button>
      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title="Create a care profile"
        subtitle="The foundation for schedules, medications, and visits."
        wide
      >
        <form onSubmit={submit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-[1fr_120px]">
            <div>
              <Label htmlFor="elder-name">Full name</Label>
              <Input
                id="elder-name"
                placeholder="e.g. Margaret Ellis"
                value={values.name}
                onChange={(e) => set("name", e.target.value)}
              />
              <FieldError message={errors.name} />
            </div>
            <div>
              <Label htmlFor="elder-age">Age</Label>
              <Input
                id="elder-age"
                type="number"
                min={50}
                max={120}
                value={String(values.age)}
                onChange={(e) => set("age", Number(e.target.value))}
              />
              <FieldError message={errors.age} />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="elder-gender">Gender</Label>
              <Select id="elder-gender" value={values.gender} onChange={(e) => set("gender", e.target.value)}>
                <option value="female">Female</option>
                <option value="male">Male</option>
                <option value="other">Other</option>
              </Select>
            </div>
            <div>
              <Label htmlFor="elder-mobility">Mobility</Label>
              <Select id="elder-mobility" value={values.mobility} onChange={(e) => set("mobility", e.target.value)}>
                <option value="independent">Independent</option>
                <option value="walking aid">Walking aid</option>
                <option value="wheelchair">Wheelchair</option>
                <option value="bed-bound">Bed-bound</option>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="elder-address">Address</Label>
            <Input
              id="elder-address"
              placeholder="Street, city"
              value={values.address ?? ""}
              onChange={(e) => set("address", e.target.value)}
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="elder-conditions">Conditions (comma separated)</Label>
              <Input
                id="elder-conditions"
                placeholder="e.g. Hypertension, Arthritis"
                value={values.conditions ?? ""}
                onChange={(e) => set("conditions", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="elder-allergies">Allergies</Label>
              <Input
                id="elder-allergies"
                placeholder="e.g. Penicillin"
                value={values.allergies ?? ""}
                onChange={(e) => set("allergies", e.target.value)}
              />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            <div>
              <Label htmlFor="elder-blood">Blood type</Label>
              <Select id="elder-blood" value={values.bloodType ?? ""} onChange={(e) => set("bloodType", e.target.value)}>
                <option value="">Unknown</option>
                {["A+", "A−", "B+", "B−", "AB+", "AB−", "O+", "O−"].map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label htmlFor="elder-ec-name">Emergency contact</Label>
              <Input
                id="elder-ec-name"
                placeholder="Name"
                value={values.emergencyContactName ?? ""}
                onChange={(e) => set("emergencyContactName", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="elder-ec-phone">Contact phone</Label>
              <Input
                id="elder-ec-phone"
                placeholder="+1…"
                value={values.emergencyContactPhone ?? ""}
                onChange={(e) => set("emergencyContactPhone", e.target.value)}
              />
            </div>
          </div>

          <div>
            <Label>Profile color</Label>
            <div className="flex gap-2 pt-1.5">
              {ACCENTS.map((c) => (
                <button
                  key={c}
                  type="button"
                  aria-label={c}
                  onClick={() => setAccentChoice(c)}
                  className={cn(
                    "h-9 w-9 rounded-full transition-all",
                    ACCENT_BG[c],
                    accentChoice === c ? "scale-110 ring-4 ring-pine-200" : "opacity-60 hover:opacity-100",
                  )}
                />
              ))}
            </div>
          </div>

          {serverError && (
            <p className="rounded-2xl bg-clay-50 px-4 py-3 text-sm font-semibold text-clay-600">
              {serverError}
            </p>
          )}

          <div className="flex justify-end gap-3 pt-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={pending}>
              {pending ? <Spinner /> : <UserPlus className="h-5 w-5" />}
              Create profile
            </Button>
          </div>
        </form>
      </Dialog>
    </>
  );
}

/* ------------------------------ add vital ---------------------------------- */

const VITAL_OPTIONS = [
  { type: "blood_pressure", label: "Blood pressure", unit: "mmHg", placeholder: "e.g. 128/82" },
  { type: "heart_rate", label: "Heart rate", unit: "bpm", placeholder: "e.g. 72" },
  { type: "glucose", label: "Blood glucose", unit: "mg/dL", placeholder: "e.g. 105" },
  { type: "weight", label: "Weight", unit: "kg", placeholder: "e.g. 68.4" },
  { type: "oxygen", label: "Oxygen saturation", unit: "%", placeholder: "e.g. 97" },
  { type: "temperature", label: "Temperature", unit: "°C", placeholder: "e.g. 36.6" },
] as const;

export function AddVitalDialog({ elderId, elderName }: { elderId: string; elderName: string }) {
  const [open, setOpen] = React.useState(false);
  const [type, setType] = React.useState<(typeof VITAL_OPTIONS)[number]["type"]>("blood_pressure");
  const [value, setValue] = React.useState("");
  const [notes, setNotes] = React.useState("");
  const [error, setError] = React.useState<string | null>(null);
  const [pending, setPending] = React.useState(false);

  const current = VITAL_OPTIONS.find((v) => v.type === type)!;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!value.trim()) {
      setError("Enter a reading");
      return;
    }
    setPending(true);
    try {
      await addVital({ elderId, type, value: value.trim(), unit: current.unit, notes });
      setValue("");
      setNotes("");
      setOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setPending(false);
    }
  }

  return (
    <>
      <Button onClick={() => setOpen(true)}>
        <Activity className="h-5 w-5" />
        Record a reading
      </Button>
      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title={`Record a reading`}
        subtitle={`For ${elderName} · saved to the shared health record`}
      >
        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {VITAL_OPTIONS.map((v) => (
              <button
                key={v.type}
                type="button"
                onClick={() => setType(v.type)}
                className={cn(
                  "rounded-2xl border-2 px-3 py-3 text-left text-sm font-bold transition-colors",
                  type === v.type
                    ? "border-pine-600 bg-pine-50 text-pine-800"
                    : "border-line text-ink-soft hover:border-pine-200",
                )}
              >
                {v.label}
                <span className="block text-[11px] font-semibold text-ink-faint">{v.unit}</span>
              </button>
            ))}
          </div>
          <div>
            <Label htmlFor="vital-value">{current.label} ({current.unit})</Label>
            <Input
              id="vital-value"
              placeholder={current.placeholder}
              value={value}
              onChange={(e) => setValue(e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="vital-notes">Notes (optional)</Label>
            <Input
              id="vital-notes"
              placeholder="e.g. Measured after breakfast"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>
          {error && (
            <p className="rounded-2xl bg-clay-50 px-4 py-3 text-sm font-semibold text-clay-600">{error}</p>
          )}
          <div className="flex justify-end gap-3 pt-1">
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={pending}>
              {pending ? <Spinner /> : <Plus className="h-5 w-5" />}
              Save reading
            </Button>
          </div>
        </form>
      </Dialog>
    </>
  );
}
