"use client";

import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { cn, initials, accent } from "@/lib/utils";

/* --------------------------------- button ---------------------------------- */

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full font-semibold transition-all duration-200 select-none disabled:pointer-events-none disabled:opacity-50 active:scale-[0.98] cursor-pointer",
  {
    variants: {
      variant: {
        primary:
          "bg-pine-700 text-white shadow-[0_10px_24px_-10px_rgba(31,82,65,0.7)] hover:bg-pine-800",
        honey:
          "bg-honey-400 text-pine-900 shadow-[0_10px_24px_-10px_rgba(232,172,62,0.8)] hover:bg-honey-300",
        danger:
          "bg-clay-500 text-white shadow-[0_10px_24px_-10px_rgba(196,85,63,0.8)] hover:bg-clay-600",
        outline:
          "border-2 border-pine-200 bg-transparent text-pine-800 hover:border-pine-400 hover:bg-pine-50",
        ghost: "text-pine-800 hover:bg-pine-100/70",
        soft: "bg-pine-100 text-pine-800 hover:bg-pine-200",
        white: "bg-white text-pine-900 shadow-soft hover:bg-paper",
      },
      size: {
        sm: "h-9 px-4 text-sm",
        md: "h-11 px-6 text-[15px]",
        lg: "h-14 px-8 text-base",
        xl: "h-16 px-9 text-lg",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, type = "button", ...props }, ref) => (
    <button
      ref={ref}
      type={type}
      className={cn(buttonVariants({ variant, size }), className)}
      {...props}
    />
  ),
);
Button.displayName = "Button";

/* ---------------------------------- card ----------------------------------- */

export function Card({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "rounded-3xl border border-line/70 bg-card shadow-soft",
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
}

export function SectionTitle({
  kicker,
  title,
  className,
}: {
  kicker?: string;
  title: string;
  className?: string;
}) {
  return (
    <div className={className}>
      {kicker && (
        <p className="text-[11px] font-bold tracking-[0.2em] text-pine-500 uppercase">
          {kicker}
        </p>
      )}
      <h2 className="mt-1 font-display text-2xl font-semibold tracking-tight text-pine-900">
        {title}
      </h2>
    </div>
  );
}

/* ---------------------------------- badge ---------------------------------- */

const badgeVariants = cva(
  "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold tracking-wide",
  {
    variants: {
      tone: {
        pine: "bg-pine-100 text-pine-700",
        honey: "bg-honey-100 text-honey-700",
        clay: "bg-clay-100 text-clay-600",
        sky: "bg-sky-100 text-sky-700",
        neutral: "bg-paper-deep text-ink-soft",
        green: "bg-emerald-100 text-emerald-700",
        rose: "bg-rose-100 text-rose-700",
        outline: "border border-line text-ink-soft",
      },
    },
    defaultVariants: { tone: "neutral" },
  },
);

export function Badge({
  className,
  tone,
  dot = false,
  children,
}: {
  className?: string;
  tone?: VariantProps<typeof badgeVariants>["tone"];
  dot?: boolean;
  children: React.ReactNode;
}) {
  return (
    <span className={cn(badgeVariants({ tone }), className)}>
      {dot && <span className="h-1.5 w-1.5 rounded-full bg-current" />}
      {children}
    </span>
  );
}

/* --------------------------------- avatar ---------------------------------- */

export function Avatar({
  name,
  accentKey = "pine",
  size = "md",
  className,
}: {
  name: string;
  accentKey?: string | null;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}) {
  const a = accent(accentKey);
  const sizes = {
    sm: "h-8 w-8 text-[11px]",
    md: "h-11 w-11 text-sm",
    lg: "h-14 w-14 text-base",
    xl: "h-20 w-20 text-2xl",
  };
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center justify-center rounded-full font-bold text-white ring-4",
        a.bg,
        a.ring,
        sizes[size],
        className,
      )}
      aria-hidden
    >
      {initials(name)}
    </span>
  );
}

/* ---------------------------------- field ----------------------------------- */

export function Label({
  className,
  ...props
}: React.LabelHTMLAttributes<HTMLLabelElement>) {
  return (
    <label
      className={cn("mb-1.5 block text-sm font-semibold text-pine-900", className)}
      {...props}
    />
  );
}

export const Input = React.forwardRef<
  HTMLInputElement,
  React.InputHTMLAttributes<HTMLInputElement>
>(({ className, ...props }, ref) => (
  <input
    ref={ref}
    className={cn(
      "h-12 w-full rounded-2xl border-2 border-line bg-white px-4 text-[15px] text-ink placeholder:text-ink-faint transition-colors focus:border-pine-400 focus:outline-none",
      className,
    )}
    {...props}
  />
));
Input.displayName = "Input";

export const Textarea = React.forwardRef<
  HTMLTextAreaElement,
  React.TextareaHTMLAttributes<HTMLTextAreaElement>
>(({ className, ...props }, ref) => (
  <textarea
    ref={ref}
    rows={3}
    className={cn(
      "w-full rounded-2xl border-2 border-line bg-white px-4 py-3 text-[15px] text-ink placeholder:text-ink-faint transition-colors focus:border-pine-400 focus:outline-none",
      className,
    )}
    {...props}
  />
));
Textarea.displayName = "Textarea";

export const Select = React.forwardRef<
  HTMLSelectElement,
  React.SelectHTMLAttributes<HTMLSelectElement>
>(({ className, children, ...props }, ref) => (
  <select
    ref={ref}
    className={cn(
      "h-12 w-full appearance-none rounded-2xl border-2 border-line bg-white px-4 text-[15px] font-medium text-ink transition-colors focus:border-pine-400 focus:outline-none",
      className,
    )}
    {...props}
  >
    {children}
  </select>
));
Select.displayName = "Select";

export function FieldError({ message }: { message?: string }) {
  if (!message) return null;
  return <p className="mt-1 text-xs font-semibold text-clay-500">{message}</p>;
}

/* --------------------------------- dialog ---------------------------------- */

export function Dialog({
  open,
  onClose,
  title,
  subtitle,
  children,
  wide = false,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  wide?: boolean;
}) {
  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    if (open) {
      document.addEventListener("keydown", onKey);
      document.body.style.overflow = "hidden";
    }
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[90] flex items-end justify-center p-0 sm:items-center sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          role="dialog"
          aria-modal="true"
          aria-label={title}
        >
          <div
            className="absolute inset-0 bg-pine-900/50 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ y: 48, opacity: 0, scale: 0.98 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 32, opacity: 0, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 320, damping: 30 }}
            className={cn(
              "relative max-h-[90vh] w-full overflow-y-auto rounded-t-[2rem] bg-card p-6 shadow-lift sm:rounded-[2rem] sm:p-8",
              wide ? "max-w-2xl" : "max-w-lg",
            )}
          >
            <div className="mb-5 flex items-start justify-between gap-4">
              <div>
                <h3 className="font-display text-2xl font-semibold text-pine-900">
                  {title}
                </h3>
                {subtitle && (
                  <p className="mt-1 text-sm text-ink-soft">{subtitle}</p>
                )}
              </div>
              <button
                onClick={onClose}
                aria-label="Close dialog"
                className="rounded-full p-2 text-ink-soft transition-colors hover:bg-paper-deep hover:text-ink"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ---------------------------------- misc ------------------------------------ */

export function Empty({
  icon,
  title,
  hint,
}: {
  icon: React.ReactNode;
  title: string;
  hint?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-3xl border-2 border-dashed border-line px-6 py-12 text-center">
      <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-paper-deep text-ink-faint">
        {icon}
      </div>
      <p className="font-semibold text-ink">{title}</p>
      {hint && <p className="mt-1 max-w-xs text-sm text-ink-soft">{hint}</p>}
    </div>
  );
}

export function Spinner({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent",
        className,
      )}
      aria-label="Loading"
    />
  );
}
