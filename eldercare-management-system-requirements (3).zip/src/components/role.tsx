"use client";

import * as React from "react";
import { Check, ChevronDown, HeartHandshake, ShieldCheck, Stethoscope, Users } from "lucide-react";
import { cn } from "@/lib/utils";

export type Role = "elder" | "family" | "caregiver" | "admin";

export const ROLES: {
  key: Role;
  label: string;
  blurb: string;
  icon: React.ReactNode;
}[] = [
  {
    key: "elder",
    label: "Elder",
    blurb: "Simple, large-text daily view",
    icon: <HeartHandshake className="h-4 w-4" />,
  },
  {
    key: "family",
    label: "Family",
    blurb: "Monitor care & stay in the loop",
    icon: <Users className="h-4 w-4" />,
  },
  {
    key: "caregiver",
    label: "Caregiver",
    blurb: "Tasks, schedules & care notes",
    icon: <Stethoscope className="h-4 w-4" />,
  },
  {
    key: "admin",
    label: "Admin",
    blurb: "Operations & management",
    icon: <ShieldCheck className="h-4 w-4" />,
  },
];

const RoleContext = React.createContext<{
  role: Role;
  setRole: (r: Role) => void;
}>({ role: "family", setRole: () => {} });

export function RoleProvider({ children }: { children: React.ReactNode }) {
  const [role, setRoleState] = React.useState<Role>("family");

  React.useEffect(() => {
    const saved = window.localStorage.getItem("eldercare-role") as Role | null;
    if (saved && ROLES.some((r) => r.key === saved)) setRoleState(saved);
  }, []);

  const setRole = React.useCallback((r: Role) => {
    setRoleState(r);
    window.localStorage.setItem("eldercare-role", r);
  }, []);

  return (
    <RoleContext.Provider value={{ role, setRole }}>{children}</RoleContext.Provider>
  );
}

export function useRole() {
  return React.useContext(RoleContext);
}

export function RoleSwitcher({ className }: { className?: string }) {
  const { role, setRole } = useRole();
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef<HTMLDivElement>(null);
  const current = ROLES.find((r) => r.key === role)!;

  React.useEffect(() => {
    const close = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  return (
    <div ref={ref} className={cn("relative", className)}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center gap-2.5 rounded-2xl border-2 border-line bg-white px-3.5 py-2.5 text-left transition-colors hover:border-pine-300"
        aria-haspopup="listbox"
        aria-expanded={open}
      >
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-pine-100 text-pine-700">
          {current.icon}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block text-[10px] font-bold tracking-[0.14em] text-ink-faint uppercase">
            Viewing as
          </span>
          <span className="block truncate text-sm font-bold text-pine-900">
            {current.label}
          </span>
        </span>
        <ChevronDown
          className={cn("h-4 w-4 text-ink-faint transition-transform", open && "rotate-180")}
        />
      </button>

      {open && (
        <div className="absolute right-0 z-50 mt-2 w-64 overflow-hidden rounded-2xl border border-line bg-white shadow-lift">
          {ROLES.map((r) => (
            <button
              key={r.key}
              onClick={() => {
                setRole(r.key);
                setOpen(false);
              }}
              className={cn(
                "flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-pine-50",
                r.key === role && "bg-pine-50/70",
              )}
              role="option"
              aria-selected={r.key === role}
            >
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-pine-100 text-pine-700">
                {r.icon}
              </span>
              <span className="flex-1">
                <span className="block text-sm font-bold text-pine-900">{r.label}</span>
                <span className="block text-xs text-ink-soft">{r.blurb}</span>
              </span>
              {r.key === role && <Check className="h-4 w-4 text-pine-600" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
